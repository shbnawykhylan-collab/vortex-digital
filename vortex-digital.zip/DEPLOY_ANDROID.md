# دليل تشغيل ونشر موقع VORTEX DIGITAL من هاتف Android فقط

هذا المشروع يعمل كخادم متكامل (Frontend + Backend + قاعدة بيانات SQLite حقيقية بدون الحاجة إلى إعدادات خارجية معقدة أو أدوات بناء C++).

---

## أولاً: إعدادات الأمان قبل النشر
قم بإنشاء ملف `.env` (بنسخ `.env.example`) وتغيير القيم التالية:
```env
SESSION_SECRET="ضع-هنا-سلسلة-عشوائية-طويلة-من-64-حرفاً"
ADMIN_EMAIL="your-admin@email.com"
ADMIN_PASSWORD="كلمة-مرور-قوية-جداً"
DATABASE_PATH="./data/vortex.db"
PORT="3000"
```
**تنبيه مهم:**
- لا تضع أي مفاتيح سرية داخل مجلد `src/`.
- بعد أول تسجيل دخول في `/admin/login`، يمكنك تغيير كلمة المرور فوراً من تبويب **الأمان** داخل لوحة التحكم.

---

## ثانياً: التشغيل محلياً على هاتف Android عبر Termux
1. ثبّت تطبيق **Termux** من F-Droid أو GitHub Releases (تجنب نسخة متجر Play القديمة).
2. افتح Termux ونفّذ الأوامر التالية بالترتيب:
```bash
pkg update && pkg upgrade -y
pkg install nodejs git unzip -y
```
3. فك ضغط ملف المشروع `vortex-digital-project.zip` داخل مجلد في هاتفك ثم انتقل إليه:
```bash
mkdir -p ~/vortex && cd ~/vortex
unzip /sdcard/Download/vortex-digital-project.zip
```
4. ثبّت الحزم وابنِ الواجهة وشغّل الخادم:
```bash
npm install
npm run build
NODE_ENV=production node server.ts
```
5. افتح متصفح Chrome على هاتفك وادخل إلى:
`http://localhost:3000`

---

## ثالثاً: النشر المجاني على الإنترنت من هاتف Android فقط (Render / Railway / Koyeb)
1. أنشئ حساباً مجانياً على **GitHub** من متصفح الهاتف، وارفع مجلد المشروع إلى مستودع خاص (Private Repository) — يمكنك فك الضغط ورفعه عبر Termux بأوامر `git` أو عبر واجهة GitHub على المتصفح.
2. أنشئ حساباً مجانياً على **Render.com** (أو **Koyeb.com**) وسجّل الدخول بحساب GitHub.
3. اختر **New Web Service** وحدد مستودع المشروع:
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `NODE_ENV=production node server.ts`
4. من قسم **Environment Variables** في Render أضف:
   - `NODE_ENV` = `production`
   - `SESSION_SECRET` = (نص عشوائي طويل)
   - `ADMIN_EMAIL` = بريدك الإداري
   - `ADMIN_PASSWORD` = كلمة مرور قوية
5. اضغط **Deploy**؛ خلال دقائق سيصبح الموقع متاحاً على رابط HTTPS مجاني يعمل 24 ساعة من أي جهاز!
   *(ملاحظة: في الخطة المجانية لـ Render التي لا تدعم قرصاً دائماً، يُنصح بترقية التخزين لاحقاً إلى Supabase باستخدام ملف `supabase/schema.sql` المرفق أو تفعيل Render Persistent Disk لضمان بقاء الطلبات عند إعادة التشغيل).*
