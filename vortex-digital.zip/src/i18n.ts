import type { Lang, OrderStatus, ServiceCategoryKey } from './types';

export const STATUS_META: Record<
  OrderStatus,
  { ar: string; en: string; colorClass: string; stepIndex: number }
> = {
  received: {
    ar: 'تم استلام الطلب',
    en: 'Order Received',
    colorClass: 'text-zinc-200 border-zinc-600/60 bg-zinc-800/60',
    stepIndex: 0,
  },
  reviewing: {
    ar: 'قيد المراجعة',
    en: 'Under Review',
    colorClass: 'text-violet-300 border-violet-500/40 bg-violet-950/50',
    stepIndex: 1,
  },
  awaiting_approval: {
    ar: 'بانتظار موافقة العميل',
    en: 'Awaiting Client Approval',
    colorClass: 'text-amber-300 border-amber-500/40 bg-amber-950/40',
    stepIndex: 2,
  },
  in_progress: {
    ar: 'قيد التنفيذ',
    en: 'In Progress',
    colorClass: 'text-indigo-300 border-indigo-500/40 bg-indigo-950/50',
    stepIndex: 3,
  },
  completed: {
    ar: 'مكتمل',
    en: 'Completed',
    colorClass: 'text-emerald-300 border-emerald-500/40 bg-emerald-950/40',
    stepIndex: 4,
  },
  rejected: {
    ar: 'مرفوض',
    en: 'Rejected',
    colorClass: 'text-rose-300 border-rose-500/40 bg-rose-950/40',
    stepIndex: -1,
  },
};

export const SERVICE_CATEGORIES: Record<
  ServiceCategoryKey,
  {
    indexLabel: string;
    titleAr: string;
    titleEn: string;
    descAr: string;
    descEn: string;
    subItemsAr: string[];
    subItemsEn: string[];
    image: string;
  }
> = {
  'design-identity': {
    indexLabel: '01',
    titleAr: 'التصميم والهوية البصرية',
    titleEn: 'Design & Visual Identity',
    descAr: 'صياغة حضور بصري متفرد يرسخ العلامة التجارية في أذهان الجمهور عبر تصاميم دقيقة ومتسقة.',
    descEn: 'Precision brand systems and digital graphics crafted for instant recognition and commercial authority.',
    subItemsAr: [
      'تصميم الشعارات',
      'تصميم الهويات التجارية',
      'أغلفة وتصاميم Discord',
      'الإعلانات والمنشورات',
      'تصاميم السوشيال ميديا',
    ],
    subItemsEn: [
      'Logo Design',
      'Brand Identity Systems',
      'Discord Covers & Server Design',
      'Promotional Ads & Posts',
      'Social Media Graphics',
    ],
    image: '/src/assets/images/service_brand_identity_1794765376372.jpg',
  },
  'web-design': {
    indexLabel: '02',
    titleAr: 'تصميم المواقع',
    titleEn: 'Website Design',
    descAr: 'واجهات رقمية فائقة السرعة متوافقة مع كافة الأجهزة وتجمع بين الفخامة وسهولة الاستخدام.',
    descEn: 'Responsive, high-contrast web experiences engineered for speed, clarity, and conversion across all devices.',
    subItemsAr: [
      'مواقع الشركات',
      'المتاجر الإلكترونية',
      'صفحات الهبوط',
      'المواقع التعريفية',
    ],
    subItemsEn: [
      'Corporate Websites',
      'E-Commerce Storefronts',
      'High-Converting Landing Pages',
      'Portfolio & Profile Sites',
    ],
    image: '/src/assets/images/service_web_engineering_1794765377359.jpg',
  },
  'programming-solutions': {
    indexLabel: '03',
    titleAr: 'البرمجة والحلول الرقمية',
    titleEn: 'Programming & Digital Solutions',
    descAr: 'بناء أنظمة ومواقع مخصصة بقواعد بيانات حقيقية، أمان متقدم، ولوحات تحكم عملية.',
    descEn: 'Full-stack web software, relational databases, internal workflow tools, and custom operational systems.',
    subItemsAr: [
      'برمجة المواقع',
      'تطوير الأنظمة',
      'أدوات تنظيم وإدارة المشاريع',
      'حلول رقمية حسب الطلب',
    ],
    subItemsEn: [
      'Custom Website Engineering',
      'Systems & Portal Development',
      'Project Organization & Management Tools',
      'Tailored Digital Solutions',
    ],
    image: '/src/assets/images/service_digital_systems_1794765376079.jpg',
  },
  'content-social': {
    indexLabel: '04',
    titleAr: 'المحتوى والتواصل الاجتماعي',
    titleEn: 'Content & Social Media',
    descAr: 'تجهيز وإدارة الحضور الرقمي بصياغة تسويقية واضحة وتصاميم منشورات متناسقة.',
    descEn: 'Structured digital presence setup, persuasive copywriting, and consistent visual social publishing.',
    subItemsAr: [
      'صناعة المحتوى',
      'تصميم المنشورات',
      'إدارة المحتوى',
      'تجهيز الهوية الرقمية',
    ],
    subItemsEn: [
      'Content Creation',
      'Post Design',
      'Content Management',
      'Digital Identity Setup',
    ],
    image: '/src/assets/images/service_brand_identity_1794765376372.jpg',
  },
};

export function t(lang: Lang, ar: string, en: string): string {
  return lang === 'ar' ? ar : en;
}
