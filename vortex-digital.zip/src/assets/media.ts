import heroVortexStudio from './images/hero_vortex_studio_1794765373970.jpg';
import serviceBrandIdentity from './images/service_brand_identity_1794765376372.jpg';
import serviceWebEngineering from './images/service_web_engineering_1794765377359.jpg';
import serviceDigitalSystems from './images/service_digital_systems_1794765376079.jpg';

const MEDIA_MAP: Record<string, string> = {
  '/src/assets/images/hero_vortex_studio_1794765373970.jpg': heroVortexStudio,
  '/src/assets/images/service_brand_identity_1794765376372.jpg': serviceBrandIdentity,
  '/src/assets/images/service_web_engineering_1794765377359.jpg': serviceWebEngineering,
  '/src/assets/images/service_digital_systems_1794765376079.jpg': serviceDigitalSystems,
};

export function resolveMediaUrl(pathOrUrl: string): string {
  return MEDIA_MAP[pathOrUrl] || pathOrUrl;
}
