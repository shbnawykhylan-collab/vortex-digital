import React, { useEffect, useState } from 'react';
import { CheckCircle2, Copy, FileText, Paperclip, Trash2, Upload } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { t } from '../i18n';

export function OrderPage() {
  const { lang, services, packages, searchParams, navigate } = useApp();

  const preselectedServiceId = searchParams.get('service') || '';
  const preselectedPackageId = searchParams.get('package') || '';

  const [clientName, setClientName] = useState('');
  const [contactMethod, setContactMethod] = useState<'Discord' | 'WhatsApp' | 'Email' | 'Telegram'>('Discord');
  const [contactValue, setContactValue] = useState('');
  const [serviceId, setServiceId] = useState(preselectedServiceId);
  const [packageId, setPackageId] = useState(preselectedPackageId);
  const [projectDescription, setProjectDescription] = useState('');
  const [budget, setBudget] = useState('');
  const [deadline, setDeadline] = useState('');
  const [files, setFiles] = useState<File[]>([]);

  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [createdOrder, setCreatedOrder] = useState<{
    orderCode: string;
    serviceTitle: string;
    contactValue: string;
  } | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (preselectedServiceId) setServiceId(preselectedServiceId);
  }, [preselectedServiceId]);

  useEffect(() => {
    if (preselectedPackageId) setPackageId(preselectedPackageId);
  }, [preselectedPackageId]);

  useEffect(() => {
    if (!serviceId && services.length > 0 && !preselectedPackageId) {
      setServiceId(String(services[0].id));
    }
  }, [services, serviceId, preselectedPackageId]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = Array.from(e.target.files || []);
    const combined = [...files, ...selected].slice(0, 5);
    setFiles(combined);
    e.target.value = '';
  };

  const removeFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (clientName.trim().length < 2) {
      setErrorMsg(t(lang, 'يرجى إدخال اسمك الكامل.', 'Please enter your full name.'));
      return;
    }
    if (contactValue.trim().length < 3) {
      setErrorMsg(t(lang, 'يرجى إدخال وسيلة التواصل الخاصة بك بدقة.', 'Please enter your contact details.'));
      return;
    }
    if (!serviceId && !packageId) {
      setErrorMsg(t(lang, 'يرجى اختيار الخدمة المطلوبة.', 'Please select a service.'));
      return;
    }
    if (projectDescription.trim().length < 10) {
      setErrorMsg(t(lang, 'يرجى كتابة وصف واضح للمشروع (10 أحرف على الأقل).', 'Please enter a clear project description (at least 10 characters).'));
      return;
    }

    setSubmitting(true);
    try {
      const formData = new FormData();
      formData.append('clientName', clientName.trim());
      formData.append('contactMethod', contactMethod);
      formData.append('contactValue', contactValue.trim());
      if (serviceId) {
        formData.append('serviceId', serviceId);
      } else if (packageId) {
        const pkg = packages.find((p) => String(p.id) === packageId);
        formData.append('customServiceTitle', pkg ? `${pkg.name_ar} (${pkg.name_en})` : 'باقة مخصصة');
      }
      if (packageId) formData.append('packageId', packageId);
      formData.append('projectDescription', projectDescription.trim());
      formData.append('budget', budget.trim() || t(lang, 'يحدد بعد المراجعة', 'TBD after review'));
      formData.append('deadline', deadline.trim() || t(lang, 'مرن', 'Flexible'));
      for (const file of files) {
        formData.append('attachments', file);
      }

      const res = await fetch('/api/orders', {
        method: 'POST',
        body: formData,
      });
      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(lang === 'ar' ? data.messageAr || data.error : data.error || 'Submission failed');
        return;
      }

      setCreatedOrder({
        orderCode: data.orderCode,
        serviceTitle: data.serviceTitle,
        contactValue: contactValue.trim(),
      });
    } catch {
      setErrorMsg(t(lang, 'تعذر الاتصال بالخادم، يرجى المحاولة لاحقاً.', 'Connection error. Please try again.'));
    } finally {
      setSubmitting(false);
    }
  };

  const copyOrderCode = async () => {
    if (!createdOrder) return;
    try {
      await navigator.clipboard.writeText(createdOrder.orderCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // ignore clipboard errors
    }
  };

  if (createdOrder) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
        <div className="rounded-xl border border-emerald-500/35 bg-[#0E0E14] p-7 sm:p-10">
          <div className="flex items-center gap-3 text-emerald-400 mb-4">
            <CheckCircle2 className="h-7 w-7 shrink-0" />
            <h1 className="text-xl sm:text-2xl font-semibold text-white">
              {t(lang, 'تم استلام طلبك وحفظه بنجاح', 'Order Received & Saved Successfully')}
            </h1>
          </div>

          <p className="text-sm text-zinc-300 leading-relaxed">
            {t(
              lang,
              'احتفظ برقم الطلب الفريد التالي مع بيانات التواصل الخاصة بك لمتابعة حالة التنفيذ وملاحظات الفريق بسرية تامة.',
              'Keep your unique order ID and contact details below to privately track project milestones and updates.'
            )}
          </p>

          <div className="mt-6 rounded-xl border border-white/10 bg-[#07070A] p-5 space-y-3">
            <div className="flex items-center justify-between gap-3">
              <span className="text-xs text-zinc-400">{t(lang, 'رقم الطلب الفريد', 'Unique Order ID')}</span>
              <button
                type="button"
                onClick={copyOrderCode}
                className="inline-flex items-center gap-1.5 text-xs text-violet-300 hover:text-violet-200 cursor-pointer"
              >
                <Copy className="h-3.5 w-3.5" />
                <span>{copied ? t(lang, 'تم النسخ', 'Copied') : t(lang, 'نسخ الرقم', 'Copy ID')}</span>
              </button>
            </div>
            <div className="font-mono-tabular text-2xl sm:text-3xl font-bold tracking-wider text-white">
              {createdOrder.orderCode}
            </div>
            <div className="pt-3 border-t border-white/10 text-xs text-zinc-400 space-y-1">
              <div>
                <span className="text-zinc-500">{t(lang, 'الخدمة:', 'Service:')} </span>
                <span className="text-zinc-200">{createdOrder.serviceTitle}</span>
              </div>
              <div>
                <span className="text-zinc-500">{t(lang, 'بيانات التحقق للمتابعة:', 'Verification Contact:')} </span>
                <span className="text-zinc-200 font-mono-tabular">{createdOrder.contactValue}</span>
              </div>
            </div>
          </div>

          <div className="mt-7 flex flex-wrap gap-3">
            <button
              type="button"
              onClick={() =>
                navigate(
                  `/track?code=${encodeURIComponent(createdOrder.orderCode)}&contact=${encodeURIComponent(
                    createdOrder.contactValue
                  )}`
                )
              }
              className="rounded-lg bg-[#7C3AED] px-5 py-2.5 text-sm font-medium text-white hover:bg-[#6D28D9] cursor-pointer"
            >
              {t(lang, 'متابعة حالة الطلب الآن', 'Track Order Now')}
            </button>
            <button
              type="button"
              onClick={() => {
                setCreatedOrder(null);
                setProjectDescription('');
                setFiles([]);
              }}
              className="rounded-lg border border-white/15 bg-[#0E0E14] px-5 py-2.5 text-sm font-medium text-zinc-200 hover:border-white/30 cursor-pointer"
            >
              {t(lang, 'تقديم طلب آخر', 'Submit Another Order')}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-12 sm:py-16">
      <div className="mx-auto max-w-3xl px-4 sm:px-6">
        <div className="mb-8">
          <p className="text-xs font-medium text-violet-400 mb-2">
            {t(lang, 'نموذج طلب خدمة', 'Service Request')}
          </p>
          <h1 className="text-3xl sm:text-4xl font-bold text-white">
            {t(lang, 'اطلب خدمتك من VORTEX DIGITAL', 'Request a Service from VORTEX DIGITAL')}
          </h1>
          <p className="mt-2.5 text-sm sm:text-base text-zinc-400 leading-relaxed">
            {t(
              lang,
              'املأ تفاصيل مشروعك وأرفق أي ملفات أو أمثلة مرجعية، وسيتم إنشاء رقم طلب فريد لك فوراً.',
              'Provide your project brief and attach any reference files to receive your private tracking ID immediately.'
            )}
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="rounded-xl border border-white/10 bg-[#0E0E14] p-6 sm:p-8 space-y-6"
        >
          {errorMsg && (
            <div
              role="alert"
              className="rounded-lg border border-rose-500/40 bg-rose-950/40 px-4 py-3 text-sm text-rose-200"
            >
              {errorMsg}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-medium text-zinc-300 mb-2">
                {t(lang, 'اسم العميل أو الجهة *', 'Client / Brand Name *')}
              </label>
              <input
                type="text"
                required
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                placeholder={t(lang, 'مثال: أحمد العتيبي', 'e.g. Alex Mercer')}
                className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3.5 py-2.5 text-sm text-white placeholder-zinc-600 focus:border-violet-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-zinc-300 mb-2">
                {t(lang, 'وسيلة التواصل المفضلة *', 'Preferred Contact Method *')}
              </label>
              <select
                value={contactMethod}
                onChange={(e) => setContactMethod(e.target.value as 'Discord' | 'WhatsApp' | 'Email' | 'Telegram')}
                className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3.5 py-2.5 text-sm text-white focus:border-violet-500 focus:outline-none"
              >
                <option value="Discord">Discord</option>
                <option value="WhatsApp">WhatsApp</option>
                <option value="Email">Email</option>
                <option value="Telegram">Telegram</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-zinc-300 mb-2">
              {t(
                lang,
                'معرّف التواصل (يوزر Discord / رقم WhatsApp / البريد) *',
                'Contact Handle (Discord Username / WhatsApp / Email) *'
              )}
            </label>
            <input
              type="text"
              required
              value={contactValue}
              onChange={(e) => setContactValue(e.target.value)}
              placeholder={
                contactMethod === 'Email'
                  ? 'name@domain.com'
                  : contactMethod === 'Discord'
                    ? 'username'
                    : '+966 5X XXX XXXX'
              }
              className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3.5 py-2.5 text-sm text-white placeholder-zinc-600 focus:border-violet-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-medium text-zinc-300 mb-2">
                {t(lang, 'الخدمة المطلوبة *', 'Requested Service *')}
              </label>
              <select
                value={serviceId}
                onChange={(e) => setServiceId(e.target.value)}
                className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3.5 py-2.5 text-sm text-white focus:border-violet-500 focus:outline-none"
              >
                <option value="">{t(lang, '-- اختر الخدمة --', '-- Select Service --')}</option>
                {services.map((s) => (
                  <option key={s.id} value={s.id}>
                    {lang === 'ar'
                      ? `${s.title_ar} (${s.price_label_ar})`
                      : `${s.title_en} (${s.price_label_en})`}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-zinc-300 mb-2">
                {t(lang, 'الباقة (اختياري)', 'Package (Optional)')}
              </label>
              <select
                value={packageId}
                onChange={(e) => setPackageId(e.target.value)}
                className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3.5 py-2.5 text-sm text-white focus:border-violet-500 focus:outline-none"
              >
                <option value="">{t(lang, 'بدون باقة محددة', 'No specific package')}</option>
                {packages.map((p) => (
                  <option key={p.id} value={p.id}>
                    {lang === 'ar' ? p.name_ar : p.name_en}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-medium text-zinc-300 mb-2">
                {t(lang, 'الميزانية المتوقعة (بالدولار)', 'Estimated Budget (USD)')}
              </label>
              <input
                type="text"
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
                placeholder={t(lang, 'مثال: $25 - $60 أو حسب المراجعة', 'e.g. $50 - $120')}
                className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3.5 py-2.5 text-sm text-white placeholder-zinc-600 focus:border-violet-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-zinc-300 mb-2">
                {t(lang, 'الموعد المطلوب للتسليم', 'Requested Delivery Date')}
              </label>
              <input
                type="date"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3.5 py-2.5 text-sm text-white focus:border-violet-500 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-zinc-300 mb-2">
              {t(lang, 'وصف المشروع والتفاصيل المطلوبة *', 'Project Description & Requirements *')}
            </label>
            <textarea
              required
              rows={5}
              value={projectDescription}
              onChange={(e) => setProjectDescription(e.target.value)}
              placeholder={t(
                lang,
                'اشرح فكرتك، الألوان المفضلة، الصفحات أو المزايا المطلوبة، وأي روابط مرجعية...',
                'Describe your goals, preferred aesthetic, required pages/features, and any reference links...'
              )}
              className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3.5 py-2.5 text-sm text-white placeholder-zinc-600 focus:border-violet-500 focus:outline-none leading-relaxed"
            />
          </div>

          {/* File & Image Attachments */}
          <div>
            <label className="block text-xs font-medium text-zinc-300 mb-2">
              {t(
                lang,
                'إرفاق صور أو ملفات مرجعية (اختياري — بحد أقصى 5 ملفات)',
                'Attach Reference Images or Files (Optional — up to 5 files)'
              )}
            </label>

            <label className="flex flex-col items-center justify-center rounded-xl border border-dashed border-white/20 bg-[#07070A] p-5 text-center cursor-pointer hover:border-violet-500/50 transition-colors">
              <Upload className="h-5 w-5 text-violet-400 mb-2" />
              <span className="text-xs sm:text-sm text-zinc-300">
                {t(lang, 'اضغط لاختيار الصور أو الملفات (PNG, JPG, PDF, ZIP)', 'Click to attach PNG, JPG, PDF, ZIP (max 5MB each)')}
              </span>
              <input
                type="file"
                multiple
                accept=".png,.jpg,.jpeg,.webp,.gif,.svg,.pdf,.zip,.txt,.doc,.docx"
                onChange={handleFileChange}
                className="hidden"
              />
            </label>

            {files.length > 0 && (
              <ul className="mt-3 space-y-2">
                {files.map((file, idx) => (
                  <li
                    key={`${file.name}-${idx}`}
                    className="flex items-center justify-between gap-3 rounded-lg border border-white/10 bg-[#07070A] px-3.5 py-2 text-xs text-zinc-300"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <Paperclip className="h-3.5 w-3.5 text-violet-400 shrink-0" />
                      <span className="truncate">{file.name}</span>
                      <span className="font-mono-tabular text-zinc-500 shrink-0">
                        ({(file.size / 1024).toFixed(0)} KB)
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeFile(idx)}
                      aria-label={t(lang, 'حذف المرفق', 'Remove file')}
                      className="text-zinc-400 hover:text-rose-400 cursor-pointer"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <p className="text-xs text-zinc-500 flex items-center gap-1.5">
              <FileText className="h-3.5 w-3.5" />
              <span>
                {t(lang, 'يتم حفظ بياناتك بسرية تامة داخل قاعدة البيانات.', 'Your submission is encrypted in transit and privately isolated.')}
              </span>
            </p>
            <button
              type="submit"
              disabled={submitting}
              className="rounded-lg bg-[#7C3AED] px-7 py-3 text-sm font-medium text-white hover:bg-[#6D28D9] disabled:opacity-50 transition-colors cursor-pointer whitespace-nowrap"
            >
              {submitting
                ? t(lang, 'جاري إرسال الطلب...', 'Submitting Order...')
                : t(lang, 'إرسال الطلب الآن', 'Submit Order')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
