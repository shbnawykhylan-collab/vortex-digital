import React, { useEffect, useState } from 'react';
import { Lock } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { t } from '../i18n';
import { VortexLogoMark } from '../components/VortexLogo';

export function AdminLoginPage() {
  const { lang, navigate } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [checkingSession, setCheckingSession] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    fetch('/api/admin/me')
      .then((res) => {
        if (res.ok) navigate('/admin');
      })
      .finally(() => setCheckingSession(false));
  }, [navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(lang === 'ar' ? data.messageAr || data.error : data.error || 'Login failed');
        return;
      }
      navigate('/admin');
    } catch {
      setErrorMsg(t(lang, 'تعذر الاتصال بالخادم.', 'Unable to reach server.'));
    } finally {
      setLoading(false);
    }
  };

  if (checkingSession) {
    return (
      <div className="mx-auto max-w-md px-4 py-24 text-center text-sm text-zinc-400">
        {t(lang, 'جاري التحقق من الجلسة...', 'Verifying session...')}
      </div>
    );
  }

  return (
    <div className="py-16 sm:py-24 px-4">
      <div className="mx-auto max-w-md rounded-xl border border-white/10 bg-[#0E0E14] p-7 sm:p-8">
        <div className="flex flex-col items-center text-center mb-7">
          <VortexLogoMark size={40} />
          <h1 className="mt-4 text-xl font-semibold text-white">
            {t(lang, 'تسجيل دخول الإدارة', 'Admin Portal Sign In')}
          </h1>
          <p className="mt-1.5 text-xs text-zinc-400">
            {t(
              lang,
              'منطقة محمية خاصة بفريق إدارة VORTEX DIGITAL فقط.',
              'Restricted area for authorized VORTEX DIGITAL administrators.'
            )}
          </p>
        </div>

        {errorMsg && (
          <div
            role="alert"
            className="mb-5 rounded-lg border border-rose-500/40 bg-rose-950/40 px-4 py-2.5 text-xs sm:text-sm text-rose-200"
          >
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-zinc-300 mb-1.5">
              {t(lang, 'البريد الإلكتروني أو اسم المستخدم', 'Email or Username')}
            </label>
            <input
              type="text"
              required
              autoComplete="username"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@vortexdigital.agency"
              className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3.5 py-2.5 text-sm text-white placeholder-zinc-600 focus:border-violet-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-zinc-300 mb-1.5">
              {t(lang, 'كلمة المرور', 'Password')}
            </label>
            <input
              type="password"
              required
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3.5 py-2.5 text-sm text-white placeholder-zinc-600 focus:border-violet-500 focus:outline-none"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[#7C3AED] px-5 py-2.5 text-sm font-medium text-white hover:bg-[#6D28D9] disabled:opacity-50 cursor-pointer"
          >
            <Lock className="h-4 w-4" />
            <span>{loading ? t(lang, 'جاري الدخول...', 'Signing in...') : t(lang, 'دخول إلى لوحة الإدارة', 'Sign In')}</span>
          </button>
        </form>
      </div>
    </div>
  );
}
