import { ArrowLeft, ArrowRight, Check } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { t } from '../i18n';
import { PriceListSection } from '../components/PriceListSection';

export function PackagesPage() {
  const { lang, packages, navigate, loadingBootstrap } = useApp();
  const ArrowIcon = lang === 'ar' ? ArrowLeft : ArrowRight;

  return (
    <div>
      <section className="py-12 sm:py-16">
        <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
          <div className="max-w-2xl mb-12">
            <p className="text-xs font-medium text-violet-400 mb-2">
              {t(lang, 'الباقات والأسعار', 'Packages & Rates')}
            </p>
            <h1 className="text-3xl sm:text-5xl font-bold text-white text-balance">
              {t(lang, 'باقات مصممة حسب حجم مشروعك', 'Agency Packages Built Around Your Scope')}
            </h1>
            <p className="mt-3 text-base text-zinc-400 leading-relaxed">
              {t(
                lang,
                'جميع الباقات مرنة وقابلة للتعديل، ويتم اعتماد التسعير النهائي بعد مراجعة متطلباتك لضمان العدالة والدقة.',
                'All packages are customizable, with pricing tailored to your exact project requirements after brief review.'
              )}
            </p>
          </div>

          {loadingBootstrap && packages.length === 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-80 rounded-xl border border-white/10 bg-[#0E0E14] animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
              {packages.map((pkg) => {
                const features = lang === 'ar' ? pkg.features_ar : pkg.features_en;
                return (
                  <div
                    key={pkg.id}
                    className={`flex flex-col justify-between rounded-xl border p-6 ${
                      pkg.is_featured
                        ? 'border-violet-500/50 bg-[#12101C]'
                        : 'border-white/10 bg-[#0E0E14]'
                    }`}
                  >
                    <div>
                      <h2 className="text-xl font-semibold text-white">
                        {lang === 'ar' ? pkg.name_ar : pkg.name_en}
                      </h2>
                      <p className="mt-2 text-xs sm:text-sm text-zinc-400 leading-relaxed">
                        {lang === 'ar' ? pkg.subtitle_ar : pkg.subtitle_en}
                      </p>

                      <div className="mt-5 py-4 border-y border-white/10">
                        <p className="text-sm font-semibold text-violet-300">
                          {lang === 'ar' ? pkg.price_display_ar : pkg.price_display_en}
                        </p>
                      </div>

                      <ul className="mt-5 space-y-3 text-sm text-zinc-300">
                        {features.map((feat) => (
                          <li key={feat} className="flex items-start gap-2.5">
                            <Check className="h-4 w-4 text-violet-400 mt-0.5 shrink-0" />
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <button
                      type="button"
                      onClick={() => navigate(`/order?package=${pkg.id}`)}
                      className={`mt-7 inline-flex w-full items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium transition-colors cursor-pointer ${
                        pkg.is_featured
                          ? 'bg-[#7C3AED] text-white hover:bg-[#6D28D9]'
                          : 'border border-white/15 bg-white/[0.04] text-zinc-100 hover:bg-white/[0.09]'
                      }`}
                    >
                      <span>{t(lang, 'طلب هذه الباقة', 'Request Package')}</span>
                      <ArrowIcon className="h-4 w-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      <PriceListSection />
    </div>
  );
}
