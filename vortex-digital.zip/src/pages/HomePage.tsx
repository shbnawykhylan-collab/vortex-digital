import { ArrowLeft, ArrowRight, Check, ExternalLink, Layers, Lock, Sparkles, Zap } from 'lucide-react';
import { motion } from 'motion/react';
import { useApp } from '../context/AppContext';
import { SERVICE_CATEGORIES, t } from '../i18n';
import type { ServiceCategoryKey } from '../types';
import { SafeImage } from '../components/SafeImage';
import { PriceListSection } from '../components/PriceListSection';
import { VortexLogoMark } from '../components/VortexLogo';

export function HomePage() {
  const { lang, settings, packages, navigate, discordUrl } = useApp();
  const ArrowIcon = lang === 'ar' ? ArrowLeft : ArrowRight;

  const advantages = [
    {
      num: '01',
      icon: Layers,
      title: t(lang, 'تصميم وهندسة تحت سقف واحد', 'Design & Engineering Under One Roof'),
      desc: t(
        lang,
        'تكامل تام بين الهوية البصرية وتطوير الموقع والأنظمة البرمجية دون تشتت بين فرق متعددة.',
        'Seamless alignment from visual identity to production code and backend systems.'
      ),
    },
    {
      num: '02',
      icon: Lock,
      title: t(lang, 'أمان وخصوصية بيانات حقيقية', 'Verified Security & Data Privacy'),
      desc: t(
        lang,
        'تشفير كلمات المرور، حماية المدخلات، وعزل بيانات العملاء عبر صلاحيات خادم دقيقة.',
        'Hashed credentials, validated inputs, and isolated client order tracking on the server.'
      ),
    },
    {
      num: '03',
      icon: Zap,
      title: t(lang, 'تجاوب فائق وسرعة أداء', 'Responsive Performance Everywhere'),
      desc: t(
        lang,
        'واجهات مختبرة على هواتف Android و iPhone والأجهزة اللوحية وشاشات الكمبيوتر.',
        'Interfaces tuned for Android, iPhone, tablets, and wide desktop screens.'
      ),
    },
    {
      num: '04',
      icon: Sparkles,
      title: t(lang, 'متابعة شفافة لكل مرحلة', 'Transparent Milestone Tracking'),
      desc: t(
        lang,
        'رقم طلب فريد يتيح لك متابعة حالة مشروعك خطوة بخطوة من الاستلام حتى التسليم.',
        'Every client receives a private order ID to track each stage from review to delivery.'
      ),
    },
  ];

  const workflowSteps = [
    {
      step: '01',
      title: t(lang, 'تقديم الطلب وتحديد المتطلبات', 'Submit Brief & Scope'),
      desc: t(
        lang,
        'اختر الخدمة أو الباقة، وأرفق ملفاتك أو أمثلتك المرجعية عبر نموذج الطلب.',
        'Select your service or package and upload references via our structured request form.'
      ),
    },
    {
      step: '02',
      title: t(lang, 'المراجعة وتحديد العرض الدقيق', 'Technical Review & Confirmation'),
      desc: t(
        lang,
        'يراجع الفريق التفاصيل ويحدد التكلفة النهائية والجدول الزمني بوضوح قبل البدء.',
        'Our team evaluates the scope, confirms final pricing, and awaits your approval.'
      ),
    },
    {
      step: '03',
      title: t(lang, 'التصميم والبرمجة المرحلية', 'Iterative Design & Build'),
      desc: t(
        lang,
        'نبدأ التنفيذ مع تحديث حالة الطلب وإتاحة الملاحظات المباشرة عبر لوحة المتابعة.',
        'We execute design and engineering milestones while updating your live order timeline.'
      ),
    },
    {
      step: '04',
      title: t(lang, 'الاختبار والتسليم الكامل', 'QA Testing & Handover'),
      desc: t(
        lang,
        'مراجعة شاملة على الجوال والكمبيوتر وتسليم جميع الملفات المصدرية والنظام جاهزاً.',
        'Cross-device testing followed by complete source file and deployment handover.'
      ),
    },
  ];

  const categoryKeys: ServiceCategoryKey[] = [
    'design-identity',
    'web-design',
    'programming-solutions',
    'content-social',
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative overflow-hidden border-b border-white/10">
        {/* Subtle animated tech grid & violet ambient glow */}
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 vortex-grid-bg opacity-65" />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -top-40 start-1/2 -translate-x-1/2 h-[480px] w-[760px] rounded-full bg-violet-700/20 blur-[130px] vortex-ambient-glow"
        />

        <div className="relative mx-auto max-w-[1200px] px-4 py-14 sm:px-6 sm:py-20 lg:py-24">
          <div className="grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12">
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
              className="flex flex-col justify-center lg:col-span-6"
            >
              <div className="flex items-center gap-3 mb-5">
                <VortexLogoMark size={36} />
                <span className="font-display text-sm font-semibold tracking-wider text-zinc-300">
                  VORTEX DIGITAL
                </span>
              </div>

              <h1 className="text-[clamp(2.1rem,4vw,3.65rem)] font-bold leading-[1.15] tracking-tight text-white text-balance">
                <span className="vortex-silver-text">
                  {lang === 'ar' ? settings.hero_tagline?.ar : settings.hero_tagline?.en}
                </span>
              </h1>

              <p className="mt-5 max-w-xl text-base sm:text-lg leading-relaxed text-zinc-300">
                {lang === 'ar' ? settings.hero_description?.ar : settings.hero_description?.en}
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-3.5">
                <button
                  type="button"
                  onClick={() => navigate('/order')}
                  className="inline-flex items-center justify-center gap-2 rounded-lg bg-[#7C3AED] px-6 py-3 text-sm sm:text-base font-medium text-white transition-colors duration-150 hover:bg-[#6D28D9] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-400 cursor-pointer whitespace-nowrap"
                >
                  <span>{t(lang, 'اطلب خدمتك', 'Request Service')}</span>
                  <ArrowIcon className="h-4 w-4" />
                </button>

                <button
                  type="button"
                  onClick={() => navigate('/services')}
                  className="inline-flex items-center justify-center gap-2 rounded-lg border border-white/15 bg-[#0E0E14] px-6 py-3 text-sm sm:text-base font-medium text-zinc-100 transition-colors duration-150 hover:border-white/30 hover:bg-[#14141D] cursor-pointer whitespace-nowrap"
                >
                  <span>{t(lang, 'استكشف خدماتنا', 'Explore Services')}</span>
                </button>
              </div>

              <div className="mt-8 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-zinc-400">
                <span>{t(lang, 'الهويات البصرية', 'Brand Identities')}</span>
                <span aria-hidden="true">·</span>
                <span>{t(lang, 'تصميم وبرمجة المواقع', 'Web Engineering')}</span>
                <span aria-hidden="true">·</span>
                <span>{t(lang, 'الأنظمة الرقمية', 'Digital Systems')}</span>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.55, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
              className="lg:col-span-6"
            >
              <div className="relative h-full min-h-[260px] sm:min-h-[340px] overflow-hidden rounded-xl border border-white/10 bg-[#0E0E14]">
                <SafeImage
                  src="/src/assets/images/hero_vortex_studio_1794765373970.jpg"
                  alt={t(lang, 'استوديو VORTEX DIGITAL للتصميم والبرمجة', 'VORTEX DIGITAL Studio Artwork')}
                  className="h-full w-full object-cover lg:h-full"
                />
                <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#07070A]/80 via-transparent to-transparent" />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Agency Advantages & How We Work */}
      <section className="py-16 sm:py-24 bg-[#07070A]">
        <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
          <div className="max-w-2xl mb-12">
            <p className="text-xs font-medium text-violet-400 mb-2">
              {t(lang, 'لماذا VORTEX DIGITAL', 'Why VORTEX DIGITAL')}
            </p>
            <h2 className="text-2xl sm:text-4xl font-semibold tracking-tight text-white text-balance">
              {t(lang, 'معايير هندسية وإبداعية تبني الثقة', 'Engineering & Design Standards Built for Reliability')}
            </h2>
          </div>

          <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-4">
            {advantages.map((item) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.num}
                  className="rounded-xl border border-white/10 bg-[#0E0E14] p-6 transition-colors hover:border-violet-500/35"
                >
                  <div className="flex items-center justify-between mb-4">
                    <span className="font-mono-tabular text-xs text-zinc-500">{item.num}</span>
                    <Icon className="h-5 w-5 text-violet-400" />
                  </div>
                  <h3 className="text-base font-semibold text-white">{item.title}</h3>
                  <p className="mt-2.5 text-sm leading-relaxed text-zinc-400">{item.desc}</p>
                </div>
              );
            })}
          </div>

          {/* 4-Step Methodology */}
          <div className="mt-16 pt-14 border-t border-white/10">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
              <div>
                <p className="text-xs font-medium text-violet-400 mb-2">
                  {t(lang, 'منهجية العمل', 'Workflow')}
                </p>
                <h2 className="text-xl sm:text-3xl font-semibold text-white">
                  {t(lang, 'كيف ننفذ مشروعك من الفكرة إلى الإطلاق', 'How We Deliver From Brief to Launch')}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => navigate('/track')}
                className="text-sm font-medium text-violet-300 hover:text-violet-200 transition-colors text-start cursor-pointer whitespace-nowrap"
              >
                {t(lang, 'تابع طلبك الحالي', 'Track Existing Order')} →
              </button>
            </div>

            <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
              {workflowSteps.map((w) => (
                <div key={w.step} className="space-y-2 border-t border-white/15 pt-4">
                  <span className="font-mono-tabular text-xs font-semibold text-violet-400">
                    {w.step}
                  </span>
                  <h3 className="text-base font-semibold text-white">{w.title}</h3>
                  <p className="text-sm text-zinc-400 leading-relaxed">{w.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Core 4 Services Showcase (Asymmetric Bento Grid) */}
      <section className="py-16 sm:py-24 border-t border-white/10 bg-[#09090E]">
        <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-12">
            <div className="max-w-xl">
              <p className="text-xs font-medium text-violet-400 mb-2">
                {t(lang, 'مجالات التخصص', 'Core Capabilities')}
              </p>
              <h2 className="text-2xl sm:text-4xl font-semibold tracking-tight text-white text-balance">
                {t(lang, 'خدمات رقمية متكاملة لكل مرحلة من نمو مشروعك', 'Comprehensive Digital Services')}
              </h2>
            </div>

            <button
              type="button"
              onClick={() => navigate('/services')}
              className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-[#0E0E14] px-4 py-2 text-sm font-medium text-zinc-100 hover:border-white/30 cursor-pointer whitespace-nowrap shrink-0"
            >
              <span>{t(lang, 'عرض جميع الخدمات', 'View All Services')}</span>
              <ArrowIcon className="h-4 w-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
            {categoryKeys.map((key, idx) => {
              const cat = SERVICE_CATEGORIES[key];
              const colSpan = idx === 0 || idx === 3 ? 'lg:col-span-7' : 'lg:col-span-5';
              const items = lang === 'ar' ? cat.subItemsAr : cat.subItemsEn;
              return (
                <div
                  key={key}
                  className={`${colSpan} group flex flex-col justify-between overflow-hidden rounded-xl border border-white/10 bg-[#0E0E14] transition-colors hover:border-violet-500/40`}
                >
                  <div className="p-6 sm:p-7">
                    <div className="flex items-center justify-between gap-4 mb-3">
                      <span className="font-mono-tabular text-xs text-violet-400">
                        {cat.indexLabel}
                      </span>
                      <button
                        type="button"
                        onClick={() => navigate(`/services?category=${key}`)}
                        className="text-xs font-medium text-zinc-400 hover:text-white transition-colors cursor-pointer"
                      >
                        {t(lang, 'التفاصيل', 'Explore')} →
                      </button>
                    </div>
                    <h3 className="text-xl font-semibold text-white">
                      {lang === 'ar' ? cat.titleAr : cat.titleEn}
                    </h3>
                    <p className="mt-2 text-sm text-zinc-400 leading-relaxed">
                      {lang === 'ar' ? cat.descAr : cat.descEn}
                    </p>

                    <div className="mt-5 flex flex-wrap gap-x-4 gap-y-2 text-xs text-zinc-300">
                      {items.map((sub, sIdx) => (
                        <span key={sub} className="inline-flex items-center gap-2">
                          <span>{sub}</span>
                          {sIdx < items.length - 1 && (
                            <span aria-hidden="true" className="text-zinc-600">·</span>
                          )}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="h-44 sm:h-48 overflow-hidden border-t border-white/10">
                    <SafeImage
                      src={cat.image}
                      alt={lang === 'ar' ? cat.titleAr : cat.titleEn}
                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Public Price List Section (Required by #13) */}
      <PriceListSection />

      {/* Packages Preview & Discord Community CTA */}
      <section className="py-16 sm:py-24 border-t border-white/10 bg-[#07070A]">
        <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
            <div>
              <p className="text-xs font-medium text-violet-400 mb-2">
                {t(lang, 'باقات مرنة', 'Agency Packages')}
              </p>
              <h2 className="text-2xl sm:text-4xl font-semibold tracking-tight text-white">
                {t(lang, 'اختر الباقة المناسبة لمشروعك', 'Structured Packages for Every Stage')}
              </h2>
            </div>
            <button
              type="button"
              onClick={() => navigate('/packages')}
              className="text-sm font-medium text-zinc-300 hover:text-white cursor-pointer whitespace-nowrap"
            >
              {t(lang, 'مقارنة كل الباقات', 'Compare All Packages')} →
            </button>
          </div>

          <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-4">
            {packages.map((pkg) => {
              const features = lang === 'ar' ? pkg.features_ar : pkg.features_en;
              return (
                <div
                  key={pkg.id}
                  className={`flex flex-col justify-between rounded-xl border p-6 ${
                    pkg.is_featured
                      ? 'border-violet-500/50 bg-[#12101C]'
                      : 'border-white/10 bg-[#0E0E14]'
                  }`}
                >
                  <div>
                    <h3 className="text-lg font-semibold text-white">
                      {lang === 'ar' ? pkg.name_ar : pkg.name_en}
                    </h3>
                    <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">
                      {lang === 'ar' ? pkg.subtitle_ar : pkg.subtitle_en}
                    </p>

                    <div className="mt-4 pt-4 border-t border-white/10">
                      <p className="text-sm font-medium text-violet-300">
                        {lang === 'ar' ? pkg.price_display_ar : pkg.price_display_en}
                      </p>
                    </div>

                    <ul className="mt-4 space-y-2.5 text-xs text-zinc-300">
                      {features.map((feat) => (
                        <li key={feat} className="flex items-start gap-2">
                          <Check className="h-3.5 w-3.5 text-violet-400 mt-0.5 shrink-0" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <button
                    type="button"
                    onClick={() => navigate(`/order?package=${pkg.id}`)}
                    className={`mt-6 w-full rounded-lg px-4 py-2.5 text-xs font-medium transition-colors cursor-pointer ${
                      pkg.is_featured
                        ? 'bg-[#7C3AED] text-white hover:bg-[#6D28D9]'
                        : 'border border-white/15 bg-white/[0.03] text-zinc-100 hover:bg-white/[0.08]'
                    }`}
                  >
                    {t(lang, 'اطلب هذه الباقة', 'Select Package')}
                  </button>
                </div>
              );
            })}
          </div>

          {/* Discord Banner */}
          <div className="mt-16 rounded-xl border border-violet-500/30 bg-gradient-to-br from-[#12101C] via-[#0E0E14] to-[#0B0B10] p-8 sm:p-10">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
              <div className="max-w-2xl">
                <h2 className="text-xl sm:text-3xl font-semibold text-white text-balance">
                  {t(
                    lang,
                    'هل لديك فكرة جاهزة أو استفسار قبل البدء؟',
                    'Have an Idea Ready or Need Technical Guidance?'
                  )}
                </h2>
                <p className="mt-2.5 text-sm sm:text-base text-zinc-300 leading-relaxed">
                  {t(
                    lang,
                    'انضم إلى مجتمعنا على Discord للتواصل المباشر مع فريق VORTEX DIGITAL أو قدّم طلب مشروعك مباشرة خلال دقائق.',
                    'Join our official Discord community to speak directly with the VORTEX DIGITAL team or submit your project brief online.'
                  )}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3 shrink-0">
                <a
                  href={discordUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 rounded-lg border border-violet-400/40 bg-violet-950/50 px-5 py-3 text-sm font-medium text-white hover:bg-violet-900/60 transition-colors whitespace-nowrap"
                >
                  <span>{t(lang, 'انضم إلى مجتمعنا على Discord', 'Join Our Discord Community')}</span>
                  <ExternalLink className="h-4 w-4 text-violet-300" />
                </a>

                <button
                  type="button"
                  onClick={() => navigate('/order')}
                  className="inline-flex items-center gap-2 rounded-lg bg-[#7C3AED] px-5 py-3 text-sm font-medium text-white hover:bg-[#6D28D9] transition-colors whitespace-nowrap cursor-pointer"
                >
                  <span>{t(lang, 'ابدأ طلبك الآن', 'Start a Project')}</span>
                  <ArrowIcon className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
