import { useState } from 'react';
import { ArrowLeft, ArrowRight, Check } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { SERVICE_CATEGORIES, t } from '../i18n';
import type { ServiceCategoryKey } from '../types';
import { SafeImage } from '../components/SafeImage';

export function ServicesPage() {
  const { lang, services, searchParams, navigate } = useApp();
  const initialCat = searchParams.get('category') as ServiceCategoryKey | null;
  const [selectedCategory, setSelectedCategory] = useState<'all' | ServiceCategoryKey>(
    initialCat && initialCat in SERVICE_CATEGORIES ? initialCat : 'all'
  );

  const ArrowIcon = lang === 'ar' ? ArrowLeft : ArrowRight;

  const categories: Array<{ key: 'all' | ServiceCategoryKey; label: string }> = [
    { key: 'all', label: t(lang, 'الكل', 'All') },
    { key: 'design-identity', label: t(lang, 'التصميم والهوية', 'Design & Identity') },
    { key: 'web-design', label: t(lang, 'تصميم المواقع', 'Web Design') },
    { key: 'programming-solutions', label: t(lang, 'البرمجة والأنظمة', 'Programming & Systems') },
    { key: 'content-social', label: t(lang, 'المحتوى والسوشيال', 'Content & Social') },
  ];

  const categoryKeysToShow: ServiceCategoryKey[] =
    selectedCategory === 'all'
      ? ['design-identity', 'web-design', 'programming-solutions', 'content-social']
      : [selectedCategory];

  return (
    <div className="py-12 sm:py-16">
      <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
        <div className="max-w-2xl mb-10">
          <p className="text-xs font-medium text-violet-400 mb-2">
            {t(lang, 'دليل الخدمات الكامل', 'Full Service Catalog')}
          </p>
          <h1 className="text-3xl sm:text-5xl font-bold text-white text-balance">
            {t(lang, 'خدمات VORTEX DIGITAL', 'VORTEX DIGITAL Services')}
          </h1>
          <p className="mt-3 text-base text-zinc-400 leading-relaxed">
            {t(
              lang,
              'استعرض أقسامنا الأربعة المتخصصة واختر الخدمة المناسبة لعرض التفاصيل أو بدء طلبك مباشرة.',
              'Explore our four specialized divisions and select any service to review deliverables or start an order.'
            )}
          </p>
        </div>

        {/* Interactive Filter Tabs */}
        <div className="flex flex-wrap items-center gap-2 p-1.5 rounded-xl border border-white/10 bg-[#0E0E14] w-fit mb-12">
          {categories.map((cat) => (
            <button
              key={cat.key}
              type="button"
              onClick={() => setSelectedCategory(cat.key)}
              className={`px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                selectedCategory === cat.key
                  ? 'bg-[#7C3AED] text-white'
                  : 'text-zinc-400 hover:text-zinc-100'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Sections for each selected Category Pillar + its DB Services */}
        <div className="space-y-16">
          {categoryKeysToShow.map((catKey) => {
            const cat = SERVICE_CATEGORIES[catKey];
            const catServices = services.filter((s) => s.category_key === catKey);
            const subItems = lang === 'ar' ? cat.subItemsAr : cat.subItemsEn;

            return (
              <section
                key={catKey}
                className="rounded-xl border border-white/10 bg-[#0B0B10] overflow-hidden"
              >
                <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch border-b border-white/10">
                  <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-center">
                    <span className="font-mono-tabular text-xs font-semibold text-violet-400 mb-2">
                      {cat.indexLabel}
                    </span>
                    <h2 className="text-2xl sm:text-3xl font-semibold text-white">
                      {lang === 'ar' ? cat.titleAr : cat.titleEn}
                    </h2>
                    <p className="mt-3 text-sm sm:text-base text-zinc-300 leading-relaxed">
                      {lang === 'ar' ? cat.descAr : cat.descEn}
                    </p>

                    <ul className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-sm text-zinc-300">
                      {subItems.map((sub) => (
                        <li key={sub} className="flex items-center gap-2">
                          <Check className="h-4 w-4 text-violet-400 shrink-0" />
                          <span>{sub}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="lg:col-span-5 min-h-[220px]">
                    <SafeImage
                      src={cat.image}
                      alt={lang === 'ar' ? cat.titleAr : cat.titleEn}
                      className="h-full w-full object-cover"
                    />
                  </div>
                </div>

                {/* Individual DB-backed Services inside this Pillar */}
                {catServices.length > 0 && (
                  <div className="p-6 sm:p-8 grid grid-cols-1 md:grid-cols-2 gap-5">
                    {catServices.map((svc) => (
                      <div
                        key={svc.id}
                        className="flex flex-col justify-between rounded-xl border border-white/10 bg-[#0E0E14] p-5 hover:border-violet-500/40 transition-colors"
                      >
                        <div>
                          <div className="flex items-start justify-between gap-3">
                            <h3 className="text-lg font-semibold text-white">
                              {lang === 'ar' ? svc.title_ar : svc.title_en}
                            </h3>
                            <span className="font-mono-tabular text-xs sm:text-sm font-semibold text-violet-300 whitespace-nowrap shrink-0">
                              {lang === 'ar' ? svc.price_label_ar : svc.price_label_en}
                            </span>
                          </div>
                          <p className="mt-2 text-sm text-zinc-400 leading-relaxed">
                            {lang === 'ar' ? svc.short_desc_ar : svc.short_desc_en}
                          </p>
                        </div>

                        <div className="mt-5 pt-4 border-t border-white/[0.07] flex items-center justify-between gap-3">
                          <button
                            type="button"
                            onClick={() => navigate(`/services/${svc.slug}`)}
                            className="text-xs sm:text-sm font-medium text-zinc-300 hover:text-white cursor-pointer"
                          >
                            {t(lang, 'عرض التفاصيل', 'View Details')}
                          </button>

                          <button
                            type="button"
                            onClick={() => navigate(`/order?service=${svc.id}`)}
                            className="inline-flex items-center gap-1.5 rounded-lg bg-[#7C3AED] px-3.5 py-2 text-xs font-medium text-white hover:bg-[#6D28D9] cursor-pointer whitespace-nowrap"
                          >
                            <span>{t(lang, 'اطلب هذه الخدمة', 'Order This Service')}</span>
                            <ArrowIcon className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </section>
            );
          })}
        </div>
      </div>
    </div>
  );
}
