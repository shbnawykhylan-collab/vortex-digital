import React, { useCallback, useEffect, useState } from 'react';
import {
  Archive,
  Check,
  Download,
  Eye,
  FileText,
  Globe,
  KeyRound,
  LayoutDashboard,
  LogOut,
  Mail,
  Package,
  Plus,
  Search,
  Settings,
  ShoppingBag,
  Trash2,
  Users,
  X,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { STATUS_META, t } from '../i18n';
import type {
  AdminOrder,
  AdminStats,
  ClientRecord,
  ContactMessage,
  OrderStatus,
  PackageItem,
  ServiceCategoryKey,
  ServiceItem,
  SiteSettings,
} from '../types';

type AdminTab =
  | 'overview'
  | 'orders'
  | 'clients'
  | 'services'
  | 'packages'
  | 'cms'
  | 'messages'
  | 'security';

const ALL_STATUSES: OrderStatus[] = [
  'received',
  'reviewing',
  'awaiting_approval',
  'in_progress',
  'completed',
  'rejected',
];

export function AdminDashboardPage() {
  const { lang, toggleLang, navigate, refreshBootstrap } = useApp();
  const [authChecked, setAuthChecked] = useState(false);
  const [adminEmail, setAdminEmail] = useState('');
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');

  const [stats, setStats] = useState<AdminStats | null>(null);
  const [orders, setOrders] = useState<AdminOrder[]>([]);
  const [clients, setClients] = useState<ClientRecord[]>([]);
  const [adminServices, setAdminServices] = useState<ServiceItem[]>([]);
  const [adminPackages, setAdminPackages] = useState<PackageItem[]>([]);
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [cmsSettings, setCmsSettings] = useState<SiteSettings>({});

  const [orderSearch, setOrderSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<'all' | OrderStatus>('all');
  const [selectedOrder, setSelectedOrder] = useState<AdminOrder | null>(null);
  const [editOrderStatus, setEditOrderStatus] = useState<OrderStatus>('received');
  const [editAdminNotes, setEditAdminNotes] = useState('');
  const [editClientNote, setEditClientNote] = useState('');
  const [deleteConfirmId, setDeleteConfirmId] = useState<number | null>(null);

  const [editingService, setEditingService] = useState<ServiceItem | null>(null);
  const [creatingService, setCreatingService] = useState(false);
  const [newService, setNewService] = useState({
    category_key: 'design-identity' as ServiceCategoryKey,
    title_ar: '',
    title_en: '',
    short_desc_ar: '',
    short_desc_en: '',
    starting_price: '',
    price_label_ar: '',
    price_label_en: '',
    show_in_pricelist: true,
  });

  const [editingPackage, setEditingPackage] = useState<PackageItem | null>(null);

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [toastMsg, setToastMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const notify = (type: 'ok' | 'err', text: string) => {
    setToastMsg({ type, text });
    setTimeout(() => setToastMsg(null), 3500);
  };

  const loadAllAdminData = useCallback(async () => {
    try {
      const [statsRes, ordersRes, clientsRes, svcRes, pkgRes, msgRes, bootRes] = await Promise.all([
        fetch('/api/admin/stats'),
        fetch('/api/admin/orders'),
        fetch('/api/admin/clients'),
        fetch('/api/admin/services'),
        fetch('/api/admin/packages'),
        fetch('/api/admin/messages'),
        fetch('/api/bootstrap'),
      ]);

      if (statsRes.ok) setStats(await statsRes.json());
      if (ordersRes.ok) {
        const d = await ordersRes.json();
        setOrders(d.orders || []);
      }
      if (clientsRes.ok) {
        const d = await clientsRes.json();
        setClients(d.clients || []);
      }
      if (svcRes.ok) {
        const d = await svcRes.json();
        setAdminServices(d.services || []);
      }
      if (pkgRes.ok) {
        const d = await pkgRes.json();
        setAdminPackages(d.packages || []);
      }
      if (msgRes.ok) {
        const d = await msgRes.json();
        setMessages(d.messages || []);
      }
      if (bootRes.ok) {
        const d = await bootRes.json();
        setCmsSettings(d.settings || {});
      }
    } catch {
      // handled gracefully
    }
  }, []);

  useEffect(() => {
    fetch('/api/admin/me')
      .then(async (res) => {
        if (!res.ok) {
          navigate('/admin/login');
          return;
        }
        const data = await res.json();
        setAdminEmail(data.admin?.email || 'Admin');
        setAuthChecked(true);
        await loadAllAdminData();
      })
      .catch(() => navigate('/admin/login'));
  }, [navigate, loadAllAdminData]);

  const fetchFilteredOrders = async (searchVal: string, statusVal: string) => {
    const params = new URLSearchParams();
    if (searchVal.trim()) params.set('search', searchVal.trim());
    if (statusVal !== 'all') params.set('status', statusVal);
    const res = await fetch(`/api/admin/orders?${params.toString()}`);
    if (res.ok) {
      const d = await res.json();
      setOrders(d.orders || []);
    }
  };

  const openOrderModal = (order: AdminOrder) => {
    setSelectedOrder(order);
    setEditOrderStatus(order.status);
    setEditAdminNotes(order.admin_notes || '');
    setEditClientNote(order.client_visible_note || '');
  };

  const saveOrderChanges = async () => {
    if (!selectedOrder) return;
    const res = await fetch(`/api/admin/orders/${selectedOrder.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        status: editOrderStatus,
        adminNotes: editAdminNotes,
        clientVisibleNote: editClientNote,
      }),
    });
    if (res.ok) {
      notify('ok', t(lang, 'تم تحديث حالة الطلب والملاحظات بنجاح.', 'Order updated successfully.'));
      setSelectedOrder(null);
      await loadAllAdminData();
      if (orderSearch || orderStatusFilter !== 'all') {
        await fetchFilteredOrders(orderSearch, orderStatusFilter);
      }
    } else {
      notify('err', t(lang, 'فشل تحديث الطلب.', 'Failed to update order.'));
    }
  };

  const confirmDeleteOrder = async (id: number) => {
    const res = await fetch(`/api/admin/orders/${id}`, { method: 'DELETE' });
    if (res.ok) {
      setDeleteConfirmId(null);
      setSelectedOrder(null);
      notify('ok', t(lang, 'تم حذف الطلب نهائياً.', 'Order deleted.'));
      await loadAllAdminData();
      if (orderSearch || orderStatusFilter !== 'all') {
        await fetchFilteredOrders(orderSearch, orderStatusFilter);
      }
    } else {
      notify('err', t(lang, 'تعذر حذف الطلب.', 'Failed to delete order.'));
    }
  };

  const saveClientNote = async (clientId: number, notes: string) => {
    const res = await fetch(`/api/admin/clients/${clientId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ notes }),
    });
    if (res.ok) {
      notify('ok', t(lang, 'تم حفظ ملاحظة العميل.', 'Client note saved.'));
    }
  };

  const saveServiceEdit = async () => {
    if (!editingService) return;
    const res = await fetch(`/api/admin/services/${editingService.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(editingService),
    });
    if (res.ok) {
      notify('ok', t(lang, 'تم تحديث الخدمة والسعر بنجاح.', 'Service updated.'));
      setEditingService(null);
      await loadAllAdminData();
      await refreshBootstrap();
    } else {
      notify('err', t(lang, 'فشل تحديث الخدمة.', 'Failed to update service.'));
    }
  };

  const createNewService = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/admin/services', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...newService,
        starting_price: newService.starting_price === '' ? null : Number(newService.starting_price),
      }),
    });
    if (res.ok) {
      notify('ok', t(lang, 'تمت إضافة الخدمة الجديدة.', 'New service created.'));
      setCreatingService(false);
      setNewService({
        category_key: 'design-identity',
        title_ar: '',
        title_en: '',
        short_desc_ar: '',
        short_desc_en: '',
        starting_price: '',
        price_label_ar: '',
        price_label_en: '',
        show_in_pricelist: true,
      });
      await loadAllAdminData();
      await refreshBootstrap();
    } else {
      notify('err', t(lang, 'تأكد من تعبئة العناوين.', 'Please provide AR & EN titles.'));
    }
  };

  const deleteService = async (id: number) => {
    const res = await fetch(`/api/admin/services/${id}`, { method: 'DELETE' });
    if (res.ok) {
      notify('ok', t(lang, 'تم حذف الخدمة.', 'Service deleted.'));
      await loadAllAdminData();
      await refreshBootstrap();
    }
  };

  const savePackageEdit = async () => {
    if (!editingPackage) return;
    const res = await fetch(`/api/admin/packages/${editingPackage.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(editingPackage),
    });
    if (res.ok) {
      notify('ok', t(lang, 'تم تحديث الباقة بنجاح.', 'Package updated.'));
      setEditingPackage(null);
      await loadAllAdminData();
      await refreshBootstrap();
    } else {
      notify('err', t(lang, 'فشل تحديث الباقة.', 'Failed to update package.'));
    }
  };

  const saveCmsSettings = async () => {
    const res = await fetch('/api/admin/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ settings: cmsSettings }),
    });
    if (res.ok) {
      notify('ok', t(lang, 'تم حفظ محتوى الموقع بنجاح.', 'Site content saved.'));
      await refreshBootstrap();
    } else {
      notify('err', t(lang, 'فشل حفظ المحتوى.', 'Failed to save settings.'));
    }
  };

  const markMessageRead = async (id: number) => {
    await fetch(`/api/admin/messages/${id}/read`, { method: 'PATCH' });
    await loadAllAdminData();
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/admin/change-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ currentPassword, newPassword }),
    });
    const d = await res.json();
    if (res.ok) {
      notify('ok', t(lang, 'تم تغيير كلمة المرور بنجاح.', 'Password changed successfully.'));
      setCurrentPassword('');
      setNewPassword('');
    } else {
      notify('err', lang === 'ar' ? d.messageAr || d.error : d.error);
    }
  };

  const handleLogout = async () => {
    await fetch('/api/admin/logout', { method: 'POST' });
    navigate('/admin/login');
  };

  if (!authChecked) {
    return (
      <div className="min-h-screen bg-[#07070A] flex items-center justify-center text-sm text-zinc-400">
        {t(lang, 'جاري التحقق من صلاحيات الإدارة...', 'Verifying administrator session...')}
      </div>
    );
  }

  const navTabs: Array<{ id: AdminTab; label: string; icon: React.ComponentType<{ className?: string }> }> = [
    { id: 'overview', label: t(lang, 'نظرة عامة', 'Overview'), icon: LayoutDashboard },
    { id: 'orders', label: t(lang, 'الطلبات', 'Orders'), icon: ShoppingBag },
    { id: 'clients', label: t(lang, 'العملاء', 'Clients'), icon: Users },
    { id: 'services', label: t(lang, 'الخدمات والأسعار', 'Services & Prices'), icon: FileText },
    { id: 'packages', label: t(lang, 'الباقات', 'Packages'), icon: Package },
    { id: 'cms', label: t(lang, 'محتوى الموقع', 'Site Content'), icon: Settings },
    { id: 'messages', label: t(lang, 'الرسائل', 'Messages'), icon: Mail },
    { id: 'security', label: t(lang, 'الأمان والتصدير', 'Security & Export'), icon: KeyRound },
  ];

  return (
    <div className="min-h-screen bg-[#07070A] text-zinc-100 flex flex-col lg:flex-row">
      {/* Sidebar */}
      <aside className="lg:w-64 shrink-0 border-b lg:border-b-0 lg:border-e border-white/10 bg-[#0B0B10] p-4 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between gap-2 pb-4 mb-4 border-b border-white/10">
            <div>
              <div className="font-display text-sm font-bold text-white">VORTEX ADMIN</div>
              <div className="text-[11px] text-zinc-400 truncate max-w-[180px]">{adminEmail}</div>
            </div>
            <button
              type="button"
              onClick={toggleLang}
              title={t(lang, 'تبديل اللغة', 'Switch Language')}
              className="rounded-md border border-white/10 bg-[#07070A] p-1.5 text-zinc-300 hover:text-white cursor-pointer"
            >
              <Globe className="h-4 w-4" />
            </button>
          </div>

          <nav className="flex lg:flex-col gap-1 overflow-x-auto pb-2 lg:pb-0">
            {navTabs.map((tab) => {
              const Icon = tab.icon;
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2.5 rounded-lg px-3 py-2 text-xs sm:text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? 'bg-[#7C3AED] text-white'
                      : 'text-zinc-400 hover:bg-white/[0.04] hover:text-zinc-100'
                  }`}
                >
                  <Icon className="h-4 w-4 shrink-0" />
                  <span>{tab.label}</span>
                  {tab.id === 'messages' && (stats?.unreadMessages ?? 0) > 0 && (
                    <span className="ms-auto font-mono-tabular text-[11px] text-violet-300">
                      {stats?.unreadMessages}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="hidden lg:flex flex-col gap-2 pt-4 border-t border-white/10">
          <button
            type="button"
            onClick={() => navigate('/')}
            className="rounded-lg border border-white/10 bg-[#07070A] px-3 py-2 text-xs text-zinc-300 hover:text-white cursor-pointer text-start"
          >
            {t(lang, 'معاينة الموقع العام', 'View Public Site')}
          </button>
          <button
            type="button"
            onClick={handleLogout}
            className="inline-flex items-center gap-2 rounded-lg border border-rose-500/25 bg-rose-950/20 px-3 py-2 text-xs text-rose-300 hover:bg-rose-950/40 cursor-pointer"
          >
            <LogOut className="h-3.5 w-3.5" />
            <span>{t(lang, 'تسجيل الخروج', 'Sign Out')}</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-full overflow-x-hidden">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-white/10">
          <div className="text-xs text-zinc-400">
            <span>VORTEX DIGITAL</span>
            <span className="mx-2">/</span>
            <span className="text-white font-medium">
              {navTabs.find((n) => n.id === activeTab)?.label}
            </span>
          </div>

          <div className="flex items-center gap-2 lg:hidden">
            <button
              type="button"
              onClick={() => navigate('/')}
              className="rounded-lg border border-white/10 px-3 py-1.5 text-xs text-zinc-300"
            >
              {t(lang, 'الموقع', 'Site')}
            </button>
            <button
              type="button"
              onClick={handleLogout}
              className="rounded-lg border border-rose-500/30 px-3 py-1.5 text-xs text-rose-300"
            >
              {t(lang, 'خروج', 'Logout')}
            </button>
          </div>
        </div>

        {toastMsg && (
          <div
            className={`mb-5 rounded-lg border px-4 py-2.5 text-xs sm:text-sm ${
              toastMsg.type === 'ok'
                ? 'border-emerald-500/40 bg-emerald-950/35 text-emerald-200'
                : 'border-rose-500/40 bg-rose-950/35 text-rose-200'
            }`}
          >
            {toastMsg.text}
          </div>
        )}

        {/* TAB 1: OVERVIEW */}
        {activeTab === 'overview' && stats && (
          <div className="space-y-8">
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
              {[
                { label: t(lang, 'إجمالي العملاء', 'Total Clients'), value: stats.totalClients },
                { label: t(lang, 'إجمالي الطلبات', 'Total Orders'), value: stats.totalOrders },
                { label: t(lang, 'الطلبات الجديدة', 'New Orders'), value: stats.newOrders },
                { label: t(lang, 'قيد التنفيذ', 'In Progress'), value: stats.inProgressOrders },
                { label: t(lang, 'الطلبات المكتملة', 'Completed'), value: stats.completedOrders },
                { label: t(lang, 'الطلبات المرفوضة', 'Rejected'), value: stats.rejectedOrders },
              ].map((kpi) => (
                <div key={kpi.label} className="rounded-xl border border-white/10 bg-[#0E0E14] p-4">
                  <div className="text-xs text-zinc-400">{kpi.label}</div>
                  <div className="mt-2 font-mono-tabular text-2xl font-bold text-white">
                    {kpi.value}
                  </div>
                </div>
              ))}
            </div>

            <div className="rounded-xl border border-white/10 bg-[#0E0E14] overflow-hidden">
              <div className="flex items-center justify-between px-5 py-4 border-b border-white/10">
                <h2 className="text-sm font-semibold text-white">
                  {t(lang, 'أحدث الطلبات الواردة', 'Latest Orders')}
                </h2>
                <button
                  type="button"
                  onClick={() => setActiveTab('orders')}
                  className="text-xs text-violet-300 hover:text-violet-200 cursor-pointer"
                >
                  {t(lang, 'إدارة جميع الطلبات', 'Manage All Orders')} →
                </button>
              </div>
              {orders.length === 0 ? (
                <div className="p-8 text-center text-sm text-zinc-400">
                  {t(lang, 'لا توجد طلبات مسجلة حتى الآن.', 'No orders recorded yet.')}
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-start text-xs">
                    <thead className="border-b border-white/10 text-zinc-400">
                      <tr>
                        <th className="px-4 py-3 text-start">{t(lang, 'رقم الطلب', 'Order ID')}</th>
                        <th className="px-4 py-3 text-start">{t(lang, 'العميل', 'Client')}</th>
                        <th className="px-4 py-3 text-start">{t(lang, 'الخدمة', 'Service')}</th>
                        <th className="px-4 py-3 text-start">{t(lang, 'الحالة', 'Status')}</th>
                        <th className="px-4 py-3 text-start">{t(lang, 'التاريخ', 'Date')}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/[0.06]">
                      {orders.slice(0, 6).map((o) => {
                        const meta = STATUS_META[o.status];
                        return (
                          <tr key={o.id} className="hover:bg-white/[0.02]">
                            <td className="px-4 py-3 font-mono-tabular font-semibold text-white">
                              {o.order_code}
                            </td>
                            <td className="px-4 py-3 text-zinc-200">{o.client_name}</td>
                            <td className="px-4 py-3 text-zinc-300">{o.service_title_snapshot}</td>
                            <td className="px-4 py-3">
                              <span className={`inline-block rounded border px-2 py-0.5 text-[11px] ${meta.colorClass}`}>
                                {lang === 'ar' ? meta.ar : meta.en}
                              </span>
                            </td>
                            <td className="px-4 py-3 font-mono-tabular text-zinc-400">
                              {o.created_at.slice(0, 10)}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: ORDERS */}
        {activeTab === 'orders' && (
          <div className="space-y-5">
            <div className="flex flex-col sm:flex-row gap-3 justify-between">
              <div className="relative flex-1 max-w-md">
                <Search className="h-4 w-4 text-zinc-500 absolute top-1/2 -translate-y-1/2 start-3" />
                <input
                  type="text"
                  value={orderSearch}
                  onChange={(e) => {
                    setOrderSearch(e.target.value);
                    fetchFilteredOrders(e.target.value, orderStatusFilter);
                  }}
                  placeholder={t(lang, 'بحث برقم الطلب أو اسم العميل...', 'Search by order code, client, or contact...')}
                  className="w-full rounded-lg border border-white/15 bg-[#0E0E14] ps-9 pe-3.5 py-2 text-sm text-white focus:border-violet-500 focus:outline-none"
                />
              </div>

              <select
                value={orderStatusFilter}
                onChange={(e) => {
                  const val = e.target.value as 'all' | OrderStatus;
                  setOrderStatusFilter(val);
                  fetchFilteredOrders(orderSearch, val);
                }}
                className="rounded-lg border border-white/15 bg-[#0E0E14] px-3.5 py-2 text-sm text-white focus:border-violet-500 focus:outline-none"
              >
                <option value="all">{t(lang, 'جميع الحالات', 'All Statuses')}</option>
                {ALL_STATUSES.map((st) => (
                  <option key={st} value={st}>
                    {lang === 'ar' ? STATUS_META[st].ar : STATUS_META[st].en}
                  </option>
                ))}
              </select>
            </div>

            <div className="rounded-xl border border-white/10 bg-[#0E0E14] overflow-hidden">
              {orders.length === 0 ? (
                <div className="p-10 text-center text-sm text-zinc-400">
                  {t(lang, 'لا توجد طلبات مطابقة للبحث.', 'No matching orders found.')}
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-start text-xs">
                    <thead className="border-b border-white/10 text-zinc-400">
                      <tr>
                        <th className="px-4 py-3 text-start">{t(lang, 'رقم الطلب', 'Order ID')}</th>
                        <th className="px-4 py-3 text-start">{t(lang, 'العميل', 'Client')}</th>
                        <th className="px-4 py-3 text-start">{t(lang, 'التواصل', 'Contact')}</th>
                        <th className="px-4 py-3 text-start">{t(lang, 'الخدمة', 'Service')}</th>
                        <th className="px-4 py-3 text-start">{t(lang, 'الميزانية', 'Budget')}</th>
                        <th className="px-4 py-3 text-start">{t(lang, 'الحالة', 'Status')}</th>
                        <th className="px-4 py-3 text-end">{t(lang, 'إجراءات', 'Actions')}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/[0.06]">
                      {orders.map((o) => {
                        const meta = STATUS_META[o.status];
                        return (
                          <tr key={o.id} className="hover:bg-white/[0.02]">
                            <td className="px-4 py-3 font-mono-tabular font-semibold text-white whitespace-nowrap">
                              {o.order_code}
                            </td>
                            <td className="px-4 py-3 text-zinc-200">{o.client_name}</td>
                            <td className="px-4 py-3 text-zinc-400">
                              {o.contact_method}: <span className="text-zinc-200">{o.contact_value}</span>
                            </td>
                            <td className="px-4 py-3 text-zinc-300">{o.service_title_snapshot}</td>
                            <td className="px-4 py-3 font-mono-tabular text-zinc-300">{o.budget}</td>
                            <td className="px-4 py-3">
                              <span className={`inline-block rounded border px-2 py-0.5 text-[11px] whitespace-nowrap ${meta.colorClass}`}>
                                {lang === 'ar' ? meta.ar : meta.en}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-end whitespace-nowrap">
                              <button
                                type="button"
                                onClick={() => openOrderModal(o)}
                                className="inline-flex items-center gap-1 rounded border border-white/15 px-2.5 py-1 text-xs text-zinc-200 hover:border-violet-400 me-2 cursor-pointer"
                              >
                                <Eye className="h-3.5 w-3.5" />
                                <span>{t(lang, 'التفاصيل', 'Manage')}</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeleteConfirmId(o.id)}
                                className="inline-flex items-center rounded border border-rose-500/30 p-1 text-rose-300 hover:bg-rose-950/40 cursor-pointer"
                                aria-label={t(lang, 'حذف الطلب', 'Delete order')}
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 3: CLIENTS */}
        {activeTab === 'clients' && (
          <div className="rounded-xl border border-white/10 bg-[#0E0E14] overflow-hidden">
            {clients.length === 0 ? (
              <div className="p-10 text-center text-sm text-zinc-400">
                {t(lang, 'لا يوجد عملاء مسجلون بعد.', 'No clients recorded yet.')}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-start text-xs">
                  <thead className="border-b border-white/10 text-zinc-400">
                    <tr>
                      <th className="px-4 py-3 text-start">{t(lang, 'الاسم', 'Name')}</th>
                      <th className="px-4 py-3 text-start">{t(lang, 'وسيلة التواصل', 'Contact')}</th>
                      <th className="px-4 py-3 text-start">{t(lang, 'عدد الطلبات', 'Orders')}</th>
                      <th className="px-4 py-3 text-start">{t(lang, 'ملاحظات إدارية', 'Internal Notes')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/[0.06]">
                    {clients.map((c) => (
                      <tr key={c.id}>
                        <td className="px-4 py-3 font-medium text-white">{c.name}</td>
                        <td className="px-4 py-3 text-zinc-300">
                          {c.contact_method} · <span className="font-mono-tabular">{c.contact_value}</span>
                        </td>
                        <td className="px-4 py-3 font-mono-tabular text-zinc-200">{c.orders_count}</td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <input
                              type="text"
                              defaultValue={c.notes}
                              onBlur={(e) => saveClientNote(c.id, e.target.value)}
                              placeholder={t(lang, 'أضف ملاحظة ثم اضغط خارج الحقل...', 'Add note...')}
                              className="w-full max-w-xs rounded border border-white/10 bg-[#07070A] px-2.5 py-1 text-xs text-zinc-200 focus:border-violet-500 focus:outline-none"
                            />
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* TAB 4: SERVICES & PRICE LIST */}
        {activeTab === 'services' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-white">
                {t(lang, 'إدارة الخدمات وقائمة الأسعار', 'Manage Services & Price List')}
              </h2>
              <button
                type="button"
                onClick={() => setCreatingService((prev) => !prev)}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#7C3AED] px-4 py-2 text-xs font-medium text-white hover:bg-[#6D28D9] cursor-pointer"
              >
                <Plus className="h-4 w-4" />
                <span>{t(lang, 'إضافة خدمة جديدة', 'Add Service')}</span>
              </button>
            </div>

            {creatingService && (
              <form
                onSubmit={createNewService}
                className="rounded-xl border border-violet-500/40 bg-[#0E0E14] p-5 space-y-4"
              >
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <input
                    required
                    placeholder={t(lang, 'اسم الخدمة بالعربية *', 'Title (AR) *')}
                    value={newService.title_ar}
                    onChange={(e) => setNewService({ ...newService, title_ar: e.target.value })}
                    className="rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                  />
                  <input
                    required
                    placeholder={t(lang, 'اسم الخدمة بالإنجليزية *', 'Title (EN) *')}
                    value={newService.title_en}
                    onChange={(e) => setNewService({ ...newService, title_en: e.target.value })}
                    className="rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                  />
                  <select
                    value={newService.category_key}
                    onChange={(e) =>
                      setNewService({ ...newService, category_key: e.target.value as ServiceCategoryKey })
                    }
                    className="rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                  >
                    <option value="design-identity">{t(lang, 'التصميم والهوية', 'Design & Identity')}</option>
                    <option value="web-design">{t(lang, 'تصميم المواقع', 'Web Design')}</option>
                    <option value="programming-solutions">{t(lang, 'البرمجة والأنظمة', 'Programming')}</option>
                    <option value="content-social">{t(lang, 'المحتوى والسوشيال', 'Content & Social')}</option>
                  </select>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <input
                    type="number"
                    min="0"
                    placeholder={t(lang, 'سعر البداية بالدولار (اختياري)', 'Starting USD (blank = custom)')}
                    value={newService.starting_price}
                    onChange={(e) => setNewService({ ...newService, starting_price: e.target.value })}
                    className="rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                  />
                  <input
                    placeholder={t(lang, 'نص السعر بالعربية (مثال: يبدأ من $10)', 'Price Label (AR)')}
                    value={newService.price_label_ar}
                    onChange={(e) => setNewService({ ...newService, price_label_ar: e.target.value })}
                    className="rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                  />
                  <input
                    placeholder={t(lang, 'نص السعر بالإنجليزية (e.g. Starts at $10)', 'Price Label (EN)')}
                    value={newService.price_label_en}
                    onChange={(e) => setNewService({ ...newService, price_label_en: e.target.value })}
                    className="rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <input
                    placeholder={t(lang, 'وصف مختصر بالعربية', 'Short Description (AR)')}
                    value={newService.short_desc_ar}
                    onChange={(e) => setNewService({ ...newService, short_desc_ar: e.target.value })}
                    className="rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                  />
                  <input
                    placeholder={t(lang, 'وصف مختصر بالإنجليزية', 'Short Description (EN)')}
                    value={newService.short_desc_en}
                    onChange={(e) => setNewService({ ...newService, short_desc_en: e.target.value })}
                    className="rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <label className="inline-flex items-center gap-2 text-xs text-zinc-300">
                    <input
                      type="checkbox"
                      checked={newService.show_in_pricelist}
                      onChange={(e) => setNewService({ ...newService, show_in_pricelist: e.target.checked })}
                    />
                    <span>{t(lang, 'إظهار في قائمة الأسعار العامة', 'Show in Public Price List')}</span>
                  </label>
                  <button
                    type="submit"
                    className="rounded-lg bg-[#7C3AED] px-4 py-2 text-xs font-medium text-white cursor-pointer"
                  >
                    {t(lang, 'حفظ الخدمة', 'Create Service')}
                  </button>
                </div>
              </form>
            )}

            <div className="rounded-xl border border-white/10 bg-[#0E0E14] overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-start text-xs">
                  <thead className="border-b border-white/10 text-zinc-400">
                    <tr>
                      <th className="px-4 py-3 text-start">{t(lang, 'الخدمة', 'Service')}</th>
                      <th className="px-4 py-3 text-start">{t(lang, 'السعر المعروض', 'Displayed Price')}</th>
                      <th className="px-4 py-3 text-start">{t(lang, 'قائمة الأسعار', 'In Price List')}</th>
                      <th className="px-4 py-3 text-start">{t(lang, 'الحالة', 'Active')}</th>
                      <th className="px-4 py-3 text-end">{t(lang, 'تعديل', 'Edit')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/[0.06]">
                    {adminServices.map((svc) => (
                      <tr key={svc.id}>
                        <td className="px-4 py-3">
                          <div className="font-medium text-white">{svc.title_ar}</div>
                          <div className="text-zinc-500">{svc.title_en}</div>
                        </td>
                        <td className="px-4 py-3 font-mono-tabular text-violet-300">
                          {lang === 'ar' ? svc.price_label_ar : svc.price_label_en}
                        </td>
                        <td className="px-4 py-3 text-zinc-300">
                          {svc.show_in_pricelist ? t(lang, 'ظاهر', 'Yes') : t(lang, 'مخفي', 'No')}
                        </td>
                        <td className="px-4 py-3 text-zinc-300">
                          {svc.is_active ? t(lang, 'مفعّل', 'Active') : t(lang, 'معطّل', 'Disabled')}
                        </td>
                        <td className="px-4 py-3 text-end whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => setEditingService(svc)}
                            className="rounded border border-white/15 px-2.5 py-1 text-xs text-zinc-200 hover:border-violet-400 me-2 cursor-pointer"
                          >
                            {t(lang, 'تعديل السعر/التفاصيل', 'Edit')}
                          </button>
                          <button
                            type="button"
                            onClick={() => deleteService(svc.id)}
                            className="rounded border border-rose-500/30 p-1 text-rose-300 hover:bg-rose-950/40 cursor-pointer"
                            aria-label="Delete service"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: PACKAGES */}
        {activeTab === 'packages' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {adminPackages.map((pkg) => (
              <div key={pkg.id} className="rounded-xl border border-white/10 bg-[#0E0E14] p-5 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="text-base font-semibold text-white">{pkg.name_ar} / {pkg.name_en}</h3>
                    <p className="text-xs text-violet-300 mt-1">{pkg.price_display_ar}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setEditingPackage(pkg)}
                    className="rounded border border-white/15 px-3 py-1 text-xs text-zinc-200 hover:border-violet-400 cursor-pointer"
                  >
                    {t(lang, 'تعديل الباقة', 'Edit Package')}
                  </button>
                </div>
                <p className="text-xs text-zinc-400">{pkg.subtitle_ar}</p>
              </div>
            ))}
          </div>
        )}

        {/* TAB 6: SITE CMS CONTENT */}
        {activeTab === 'cms' && (
          <div className="rounded-xl border border-white/10 bg-[#0E0E14] p-6 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-white">
                {t(lang, 'إدارة محتوى الموقع والروابط', 'Manage Site Content & Links')}
              </h2>
              <button
                type="button"
                onClick={saveCmsSettings}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#7C3AED] px-5 py-2 text-xs font-medium text-white hover:bg-[#6D28D9] cursor-pointer"
              >
                <Check className="h-4 w-4" />
                <span>{t(lang, 'حفظ التغييرات', 'Save Content')}</span>
              </button>
            </div>

            <div className="space-y-5">
              {Object.entries(cmsSettings).map(([key, val]) => (
                <div key={key} className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-4 border-b border-white/[0.06]">
                  <div>
                    <label className="block text-xs font-mono-tabular text-zinc-400 mb-1.5">
                      {key} (AR)
                    </label>
                    <textarea
                      rows={2}
                      value={val.ar}
                      onChange={(e) =>
                        setCmsSettings({
                          ...cmsSettings,
                          [key]: { ...val, ar: e.target.value },
                        })
                      }
                      className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono-tabular text-zinc-400 mb-1.5">
                      {key} (EN)
                    </label>
                    <textarea
                      rows={2}
                      value={val.en}
                      onChange={(e) =>
                        setCmsSettings({
                          ...cmsSettings,
                          [key]: { ...val, en: e.target.value },
                        })
                      }
                      className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 7: MESSAGES */}
        {activeTab === 'messages' && (
          <div className="space-y-4">
            {messages.length === 0 ? (
              <div className="rounded-xl border border-white/10 bg-[#0E0E14] p-10 text-center text-sm text-zinc-400">
                {t(lang, 'لا توجد رسائل تواصل حالياً.', 'No contact messages yet.')}
              </div>
            ) : (
              messages.map((m) => (
                <div key={m.id} className="rounded-xl border border-white/10 bg-[#0E0E14] p-5 space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="text-sm font-semibold text-white">
                      {m.name} · <span className="text-violet-300 font-normal">{m.contact}</span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-zinc-500">
                      <span className="font-mono-tabular">{m.created_at}</span>
                      {!m.is_read && (
                        <button
                          type="button"
                          onClick={() => markMessageRead(m.id)}
                          className="rounded border border-violet-500/40 px-2 py-0.5 text-violet-300 cursor-pointer"
                        >
                          {t(lang, 'تحديد كمقروء', 'Mark Read')}
                        </button>
                      )}
                    </div>
                  </div>
                  <div className="text-xs font-medium text-zinc-300">{m.subject}</div>
                  <p className="text-sm text-zinc-400 leading-relaxed">{m.message}</p>
                </div>
              ))
            )}
          </div>
        )}

        {/* TAB 8: SECURITY & ZIP EXPORT */}
        {activeTab === 'security' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <form
              onSubmit={handleChangePassword}
              className="rounded-xl border border-white/10 bg-[#0E0E14] p-6 space-y-4"
            >
              <h2 className="text-base font-semibold text-white">
                {t(lang, 'تغيير كلمة مرور الإدارة', 'Change Admin Password')}
              </h2>
              <div>
                <label className="block text-xs text-zinc-400 mb-1.5">
                  {t(lang, 'كلمة المرور الحالية', 'Current Password')}
                </label>
                <input
                  type="password"
                  required
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3.5 py-2 text-sm text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-zinc-400 mb-1.5">
                  {t(lang, 'كلمة المرور الجديدة (8 أحرف على الأقل)', 'New Password (min 8 chars)')}
                </label>
                <input
                  type="password"
                  required
                  minLength={8}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3.5 py-2 text-sm text-white"
                />
              </div>
              <button
                type="submit"
                className="rounded-lg bg-[#7C3AED] px-5 py-2.5 text-xs font-medium text-white hover:bg-[#6D28D9] cursor-pointer"
              >
                {t(lang, 'تحديث كلمة المرور', 'Update Password')}
              </button>
            </form>

            <div className="rounded-xl border border-violet-500/35 bg-[#12101C] p-6 flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center gap-2 text-violet-300 mb-2">
                  <Archive className="h-5 w-5" />
                  <h2 className="text-base font-semibold text-white">
                    {t(lang, 'تنزيل ملفات المشروع كاملة (ZIP)', 'Download Full Project Source (ZIP)')}
                  </h2>
                </div>
                <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed">
                  {t(
                    lang,
                    'احصل على نسخة مضغوطة كاملة تحتوي على جميع ملفات الواجهة، الخادم، مخطط Supabase SQL، ودليل التشغيل والنشر من هاتف Android.',
                    'Download a clean ZIP archive containing all frontend, backend, Supabase SQL schema, and Android deployment docs.'
                  )}
                </p>
              </div>
              <a
                href="/api/admin/export-zip"
                className="inline-flex items-center justify-center gap-2 rounded-lg bg-[#7C3AED] px-5 py-3 text-sm font-medium text-white hover:bg-[#6D28D9]"
              >
                <Download className="h-4 w-4" />
                <span>{t(lang, 'تحميل vortex-digital-project.zip', 'Download Project ZIP')}</span>
              </a>
            </div>
          </div>
        )}
      </main>

      {/* Order Detail Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-xl border border-white/15 bg-[#0E0E14] p-6 space-y-5">
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-white/10">
              <div>
                <div className="font-mono-tabular text-xs text-violet-300">{selectedOrder.order_code}</div>
                <h3 className="text-lg font-semibold text-white mt-1">
                  {selectedOrder.client_name} — {selectedOrder.service_title_snapshot}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedOrder(null)}
                className="text-zinc-400 hover:text-white cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <span className="text-zinc-500 block">{t(lang, 'التواصل', 'Contact')}</span>
                <span className="text-zinc-200">{selectedOrder.contact_method}: {selectedOrder.contact_value}</span>
              </div>
              <div>
                <span className="text-zinc-500 block">{t(lang, 'الميزانية', 'Budget')}</span>
                <span className="text-zinc-200 font-mono-tabular">{selectedOrder.budget}</span>
              </div>
              <div>
                <span className="text-zinc-500 block">{t(lang, 'الموعد المطلوب', 'Deadline')}</span>
                <span className="text-zinc-200 font-mono-tabular">{selectedOrder.deadline}</span>
              </div>
            </div>

            <div>
              <h4 className="text-xs font-semibold text-zinc-400 mb-1.5">
                {t(lang, 'وصف المشروع', 'Project Description')}
              </h4>
              <p className="rounded-lg border border-white/10 bg-[#07070A] p-3.5 text-sm text-zinc-200 leading-relaxed whitespace-pre-wrap">
                {selectedOrder.project_description}
              </p>
            </div>

            {selectedOrder.attachments?.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold text-zinc-400 mb-2">
                  {t(lang, 'المرفقات', 'Attachments')}
                </h4>
                <div className="flex flex-wrap gap-2">
                  {selectedOrder.attachments.map((att) => (
                    <a
                      key={att.id}
                      href={`/api/admin/attachments/${att.id}/download`}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-[#07070A] px-3 py-1.5 text-xs text-violet-300 hover:border-violet-400"
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>{att.original_name}</span>
                    </a>
                  ))}
                </div>
              </div>
            )}

            <div className="space-y-4 pt-3 border-t border-white/10">
              <div>
                <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                  {t(lang, 'تحديث حالة الطلب', 'Update Order Status')}
                </label>
                <select
                  value={editOrderStatus}
                  onChange={(e) => setEditOrderStatus(e.target.value as OrderStatus)}
                  className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-sm text-white"
                >
                  {ALL_STATUSES.map((st) => (
                    <option key={st} value={st}>
                      {lang === 'ar' ? STATUS_META[st].ar : STATUS_META[st].en}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                  {t(lang, 'ملاحظة تظهر للعميل في صفحة المتابعة', 'Client-Visible Note')}
                </label>
                <textarea
                  rows={2}
                  value={editClientNote}
                  onChange={(e) => setEditClientNote(e.target.value)}
                  className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                  {t(lang, 'ملاحظات إدارية داخلية (خاصة بالإدارة فقط)', 'Internal Admin Notes')}
                </label>
                <textarea
                  rows={2}
                  value={editAdminNotes}
                  onChange={(e) => setEditAdminNotes(e.target.value)}
                  className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setSelectedOrder(null)}
                className="rounded-lg border border-white/15 px-4 py-2 text-xs text-zinc-300 cursor-pointer"
              >
                {t(lang, 'إلغاء', 'Cancel')}
              </button>
              <button
                type="button"
                onClick={saveOrderChanges}
                className="rounded-lg bg-[#7C3AED] px-5 py-2 text-xs font-medium text-white hover:bg-[#6D28D9] cursor-pointer"
              >
                {t(lang, 'حفظ التحديث', 'Save Update')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId !== null && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="w-full max-w-sm rounded-xl border border-rose-500/40 bg-[#0E0E14] p-6 space-y-4">
            <h3 className="text-base font-semibold text-white">
              {t(lang, 'تأكيد حذف الطلب', 'Confirm Order Deletion')}
            </h3>
            <p className="text-xs text-zinc-300 leading-relaxed">
              {t(
                lang,
                'سيتم حذف الطلب ومرفقاته نهائياً من قاعدة البيانات ولا يمكن التراجع عن هذا الإجراء.',
                'This order and its uploaded attachments will be permanently removed.'
              )}
            </p>
            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setDeleteConfirmId(null)}
                className="rounded-lg border border-white/15 px-4 py-2 text-xs text-zinc-300 cursor-pointer"
              >
                {t(lang, 'إلغاء', 'Cancel')}
              </button>
              <button
                type="button"
                onClick={() => confirmDeleteOrder(deleteConfirmId)}
                className="rounded-lg bg-rose-600 px-4 py-2 text-xs font-medium text-white hover:bg-rose-700 cursor-pointer"
              >
                {t(lang, 'تأكيد الحذف', 'Delete Permanently')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Service Modal */}
      {editingService && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-xl border border-white/15 bg-[#0E0E14] p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-base font-semibold text-white">
                {t(lang, 'تعديل الخدمة والسعر', 'Edit Service & Price')}
              </h3>
              <button type="button" onClick={() => setEditingService(null)} className="text-zinc-400 cursor-pointer">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-zinc-400 mb-1">{t(lang, 'العنوان (عربي)', 'Title (AR)')}</label>
                <input
                  value={editingService.title_ar}
                  onChange={(e) => setEditingService({ ...editingService, title_ar: e.target.value })}
                  className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-zinc-400 mb-1">{t(lang, 'العنوان (إنجليزي)', 'Title (EN)')}</label>
                <input
                  value={editingService.title_en}
                  onChange={(e) => setEditingService({ ...editingService, title_en: e.target.value })}
                  className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-zinc-400 mb-1">{t(lang, 'سعر البداية USD', 'Starting Price USD')}</label>
                <input
                  type="number"
                  min="0"
                  value={editingService.starting_price ?? ''}
                  onChange={(e) =>
                    setEditingService({
                      ...editingService,
                      starting_price: e.target.value === '' ? null : Number(e.target.value),
                    })
                  }
                  className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-zinc-400 mb-1">{t(lang, 'نص السعر (عربي)', 'Price Label (AR)')}</label>
                <input
                  value={editingService.price_label_ar}
                  onChange={(e) => setEditingService({ ...editingService, price_label_ar: e.target.value })}
                  className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-zinc-400 mb-1">{t(lang, 'نص السعر (إنجليزي)', 'Price Label (EN)')}</label>
                <input
                  value={editingService.price_label_en}
                  onChange={(e) => setEditingService({ ...editingService, price_label_en: e.target.value })}
                  className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-xs text-zinc-400 mb-1">{t(lang, 'الوصف المختصر (عربي)', 'Short Description (AR)')}</label>
                <input
                  value={editingService.short_desc_ar}
                  onChange={(e) => setEditingService({ ...editingService, short_desc_ar: e.target.value })}
                  className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-xs text-zinc-400 mb-1">{t(lang, 'الوصف المختصر (إنجليزي)', 'Short Description (EN)')}</label>
                <input
                  value={editingService.short_desc_en}
                  onChange={(e) => setEditingService({ ...editingService, short_desc_en: e.target.value })}
                  className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                />
              </div>
            </div>

            <div className="flex flex-wrap gap-5 pt-2 text-xs text-zinc-300">
              <label className="inline-flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={editingService.show_in_pricelist}
                  onChange={(e) => setEditingService({ ...editingService, show_in_pricelist: e.target.checked })}
                />
                <span>{t(lang, 'ظاهر في قائمة الأسعار', 'Show in Price List')}</span>
              </label>
              <label className="inline-flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={editingService.is_active}
                  onChange={(e) => setEditingService({ ...editingService, is_active: e.target.checked })}
                />
                <span>{t(lang, 'مفعّل بالموقع', 'Active')}</span>
              </label>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setEditingService(null)}
                className="rounded-lg border border-white/15 px-4 py-2 text-xs text-zinc-300 cursor-pointer"
              >
                {t(lang, 'إلغاء', 'Cancel')}
              </button>
              <button
                type="button"
                onClick={saveServiceEdit}
                className="rounded-lg bg-[#7C3AED] px-5 py-2 text-xs font-medium text-white cursor-pointer"
              >
                {t(lang, 'حفظ التعديلات', 'Save')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Package Modal */}
      {editingPackage && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-xl border border-white/15 bg-[#0E0E14] p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-base font-semibold text-white">
                {t(lang, 'تعديل الباقة', 'Edit Package')}
              </h3>
              <button type="button" onClick={() => setEditingPackage(null)} className="text-zinc-400 cursor-pointer">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-zinc-400 mb-1">{t(lang, 'الاسم (عربي)', 'Name (AR)')}</label>
                <input
                  value={editingPackage.name_ar}
                  onChange={(e) => setEditingPackage({ ...editingPackage, name_ar: e.target.value })}
                  className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-zinc-400 mb-1">{t(lang, 'الاسم (إنجليزي)', 'Name (EN)')}</label>
                <input
                  value={editingPackage.name_en}
                  onChange={(e) => setEditingPackage({ ...editingPackage, name_en: e.target.value })}
                  className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-zinc-400 mb-1">{t(lang, 'السعر المعروض (عربي)', 'Price Text (AR)')}</label>
                <input
                  value={editingPackage.price_display_ar}
                  onChange={(e) => setEditingPackage({ ...editingPackage, price_display_ar: e.target.value })}
                  className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-zinc-400 mb-1">{t(lang, 'السعر المعروض (إنجليزي)', 'Price Text (EN)')}</label>
                <input
                  value={editingPackage.price_display_en}
                  onChange={(e) => setEditingPackage({ ...editingPackage, price_display_en: e.target.value })}
                  className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-zinc-400 mb-1">{t(lang, 'المزايا بالعربية (سطر لكل ميزة)', 'Features AR (one per line)')}</label>
              <textarea
                rows={4}
                value={editingPackage.features_ar.join('\n')}
                onChange={(e) =>
                  setEditingPackage({
                    ...editingPackage,
                    features_ar: e.target.value.split('\n').map((s) => s.trim()).filter(Boolean),
                  })
                }
                className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs text-zinc-400 mb-1">{t(lang, 'المزايا بالإنجليزية (سطر لكل ميزة)', 'Features EN (one per line)')}</label>
              <textarea
                rows={4}
                value={editingPackage.features_en.join('\n')}
                onChange={(e) =>
                  setEditingPackage({
                    ...editingPackage,
                    features_en: e.target.value.split('\n').map((s) => s.trim()).filter(Boolean),
                  })
                }
                className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3 py-2 text-xs text-white"
              />
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setEditingPackage(null)}
                className="rounded-lg border border-white/15 px-4 py-2 text-xs text-zinc-300 cursor-pointer"
              >
                {t(lang, 'إلغاء', 'Cancel')}
              </button>
              <button
                type="button"
                onClick={savePackageEdit}
                className="rounded-lg bg-[#7C3AED] px-5 py-2 text-xs font-medium text-white cursor-pointer"
              >
                {t(lang, 'حفظ الباقة', 'Save Package')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
