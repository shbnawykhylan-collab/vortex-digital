import { ArrowLeft, ArrowRight, ExternalLink, Shield, Sparkles, Terminal } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { t } from '../i18n';
import { SafeImage } from '../components/SafeImage';

export function AboutPage() {
  const { lang, settings, navigate, discordUrl } = useApp();
  const ArrowIcon = lang === 'ar' ? ArrowLeft : ArrowRight;

  const pillars = [
    {
      num: '01',
      icon: Sparkles,
      title: t(lang, 'هوية بصرية ذات حضور ملموس', 'Distinctive Visual Authority'),
      desc: t(
        lang,
        'لا نستخدم قوالب مكررة. كل شعار وهوية وموقع يبدأ من دراسة نشاطك وجمهورك وبناء لغة بصرية خاصة.',
        'Zero recycled templates. Every brand system and interface is constructed from first principles.'
      ),
    },
    {
      num: '02',
      icon: Terminal,
      title: t(lang, 'برمجة منظمة قابلة للتطوير', 'Maintainable Full-Stack Engineering'),
      desc: t(
        lang,
        'نكتب شيفرة نظيفة ومنظمة بقاعدة بيانات حقيقية وواجهات برمجة واضحة تسهل إضافة المزايا مستقبلاً.',
        'Clean TypeScript architecture, real databases, and structured APIs designed to scale cleanly.'
      ),
    },
    {
      num: '03',
      icon: Shield,
      title: t(lang, 'التزام بالأمان والسرية', 'Security & Confidentiality First'),
      desc: t(
        lang,
        'تُحفظ ملفات العملاء وبيانات الطلبات بصلاحيات صارمة ولا يمكن لأي طرف غير مخول الاطلاع عليها.',
        'Client files and project records are isolated with strict server-side access verification.'
      ),
    },
  ];

  return (
    <div className="py-12 sm:py-20">
      <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
        <div className="grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12">
          <div className="lg:col-span-6 flex flex-col justify-center">
            <p className="text-xs font-medium text-violet-400 mb-2">
              {t(lang, 'عن وكالة VORTEX DIGITAL', 'About VORTEX DIGITAL')}
            </p>
            <h1 className="text-3xl sm:text-5xl font-bold leading-tight text-white text-balance">
              {lang === 'ar' ? settings.about_title?.ar : settings.about_title?.en}
            </h1>
            <p className="mt-5 text-base leading-relaxed text-zinc-300">
              {lang === 'ar' ? settings.about_description?.ar : settings.about_description?.en}
            </p>
            <p className="mt-4 text-sm leading-relaxed text-zinc-400">
              {t(
                lang,
                'تجمع وكالتنا بين التصميم الجرافيكي والهويات التجارية، تصميم المواقع المتجاوبة، البرمجة المتقدمة للأنظمة، وصناعة المحتوى الرقمي لتوفير تجربة متكاملة للعميل دون تعقيد.',
                'Our studio unites brand identity craftsmanship, responsive web design, custom software engineering, and content strategy under one roof.'
              )}
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => navigate('/order')}
                className="inline-flex items-center gap-2 rounded-lg bg-[#7C3AED] px-5 py-2.5 text-sm font-medium text-white hover:bg-[#6D28D9] cursor-pointer"
              >
                <span>{t(lang, 'ابدأ مشروعك معنا', 'Start Your Project')}</span>
                <ArrowIcon className="h-4 w-4" />
              </button>
              <a
                href={discordUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-[#0E0E14] px-5 py-2.5 text-sm font-medium text-zinc-200 hover:border-white/30"
              >
                <span>{t(lang, 'تواصل عبر Discord', 'Connect on Discord')}</span>
                <ExternalLink className="h-4 w-4" />
              </a>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="h-full min-h-[280px] overflow-hidden rounded-xl border border-white/10 bg-[#0E0E14]">
              <SafeImage
                src="/src/assets/images/service_web_engineering_1794765377359.jpg"
                alt={t(lang, 'بيئة عمل VORTEX DIGITAL', 'VORTEX DIGITAL Engineering Studio')}
                className="h-full w-full object-cover"
              />
            </div>
          </div>
        </div>

        <div className="mt-16 pt-14 border-t border-white/10 grid grid-cols-1 gap-6 md:grid-cols-3">
          {pillars.map((p) => {
            const Icon = p.icon;
            return (
              <div key={p.num} className="rounded-xl border border-white/10 bg-[#0E0E14] p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className="font-mono-tabular text-xs text-zinc-500">{p.num}</span>
                  <Icon className="h-5 w-5 text-violet-400" />
                </div>
                <h2 className="text-lg font-semibold text-white">{p.title}</h2>
                <p className="mt-2.5 text-sm leading-relaxed text-zinc-400">{p.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
