import React, { useEffect, useState } from 'react';
import { Check, Paperclip, Search, ShieldCheck, XCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { STATUS_META, t } from '../i18n';
import type { OrderStatus, TrackedOrder } from '../types';

const PROGRESS_STAGES: OrderStatus[] = [
  'received',
  'reviewing',
  'awaiting_approval',
  'in_progress',
  'completed',
];

export function TrackOrderPage() {
  const { lang, searchParams } = useApp();
  const [orderCode, setOrderCode] = useState(searchParams.get('code') || '');
  const [contactValue, setContactValue] = useState(searchParams.get('contact') || '');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [trackedOrder, setTrackedOrder] = useState<TrackedOrder | null>(null);

  const performLookup = async (code: string, contact: string) => {
    setErrorMsg('');
    setTrackedOrder(null);
    if (!code.trim() || !contact.trim()) {
      setErrorMsg(
        t(
          lang,
          'يرجى إدخال رقم الطلب وبيانات التواصل المستخدمة عند الطلب للتحقق.',
          'Please enter both your Order ID and the contact handle used when submitting.'
        )
      );
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/orders/track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderCode: code.trim(), contactValue: contact.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(lang === 'ar' ? data.messageAr || data.error : data.error || 'Order not found');
        return;
      }
      setTrackedOrder(data);
    } catch {
      setErrorMsg(t(lang, 'تعذر الاتصال بالخادم حالياً.', 'Unable to connect to server.'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const c = searchParams.get('code');
    const v = searchParams.get('contact');
    if (c && v) {
      setOrderCode(c);
      setContactValue(v);
      performLookup(c, v);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    performLookup(orderCode, contactValue);
  };

  const currentStageMeta = trackedOrder ? STATUS_META[trackedOrder.status] : null;

  return (
    <div className="py-12 sm:py-16">
      <div className="mx-auto max-w-3xl px-4 sm:px-6">
        <div className="mb-8">
          <p className="text-xs font-medium text-violet-400 mb-2">
            {t(lang, 'بوابة متابعة العملاء', 'Private Client Tracking')}
          </p>
          <h1 className="text-3xl sm:text-4xl font-bold text-white">
            {t(lang, 'متابعة حالة الطلب', 'Track Your Order Status')}
          </h1>
          <p className="mt-2.5 text-sm sm:text-base text-zinc-400 leading-relaxed">
            {t(
              lang,
              'لحماية خصوصية عملائنا، يتطلب عرض تفاصيل الطلب مطابقة رقم الطلب مع بيانات التواصل المسجلة.',
              'To protect client privacy, viewing an order requires matching both the unique Order ID and your registered contact handle.'
            )}
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="rounded-xl border border-white/10 bg-[#0E0E14] p-5 sm:p-6 space-y-4"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                {t(lang, 'رقم الطلب *', 'Order ID *')}
              </label>
              <input
                type="text"
                required
                value={orderCode}
                onChange={(e) => setOrderCode(e.target.value.toUpperCase())}
                placeholder="VTX-XXXXXXXX"
                className="font-mono-tabular w-full rounded-lg border border-white/15 bg-[#07070A] px-3.5 py-2.5 text-sm text-white placeholder-zinc-600 focus:border-violet-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                {t(lang, 'بيانات التواصل المسجلة بالطلب *', 'Registered Contact Handle *')}
              </label>
              <input
                type="text"
                required
                value={contactValue}
                onChange={(e) => setContactValue(e.target.value)}
                placeholder={t(lang, 'يوزر Discord أو البريد أو الرقم', 'Discord, Email, or Phone')}
                className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3.5 py-2.5 text-sm text-white placeholder-zinc-600 focus:border-violet-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
            <span className="inline-flex items-center gap-1.5 text-xs text-zinc-500">
              <ShieldCheck className="h-3.5 w-3.5 text-violet-400" />
              <span>{t(lang, 'تحقق آمن يمنع عرض طلبات الآخرين', 'Verified lookup isolates each client record')}</span>
            </span>
            <button
              type="submit"
              disabled={loading}
              className="inline-flex items-center justify-center gap-2 rounded-lg bg-[#7C3AED] px-5 py-2.5 text-sm font-medium text-white hover:bg-[#6D28D9] disabled:opacity-50 cursor-pointer"
            >
              <Search className="h-4 w-4" />
              <span>{loading ? t(lang, 'جاري البحث...', 'Searching...') : t(lang, 'عرض حالة الطلب', 'Track Order')}</span>
            </button>
          </div>
        </form>

        {errorMsg && (
          <div
            role="alert"
            className="mt-6 rounded-xl border border-rose-500/40 bg-rose-950/30 p-4 text-sm text-rose-200"
          >
            {errorMsg}
          </div>
        )}

        {trackedOrder && currentStageMeta && (
          <div className="mt-8 space-y-6">
            <div className="rounded-xl border border-white/10 bg-[#0E0E14] p-6">
              <div className="flex flex-wrap items-start justify-between gap-4 pb-5 border-b border-white/10">
                <div>
                  <span className="font-mono-tabular text-xs text-zinc-400">
                    {trackedOrder.orderCode}
                  </span>
                  <h2 className="mt-1 text-xl font-semibold text-white">
                    {trackedOrder.serviceTitle}
                  </h2>
                  {trackedOrder.packageTitle && (
                    <p className="mt-0.5 text-xs text-zinc-400">{trackedOrder.packageTitle}</p>
                  )}
                </div>

                <div
                  className={`inline-flex items-center gap-2 rounded-lg border px-3.5 py-1.5 text-xs font-semibold ${currentStageMeta.colorClass}`}
                >
                  {trackedOrder.status === 'rejected' && <XCircle className="h-3.5 w-3.5" />}
                  <span>{lang === 'ar' ? currentStageMeta.ar : currentStageMeta.en}</span>
                </div>
              </div>

              {/* 6-Stage Progress Visualization */}
              {trackedOrder.status === 'rejected' ? (
                <div className="mt-6 rounded-lg border border-rose-500/35 bg-rose-950/25 p-4 text-sm text-rose-200">
                  {t(
                    lang,
                    'حالة الطلب الحالية: مرفوض. راجع ملاحظة الإدارة أدناه أو تواصل معنا على Discord لمزيد من التوضيح.',
                    'Order status: Rejected. Please check the agency note below or reach out on Discord.'
                  )}
                </div>
              ) : (
                <div className="mt-6 grid grid-cols-1 sm:grid-cols-5 gap-3">
                  {PROGRESS_STAGES.map((st, idx) => {
                    const meta = STATUS_META[st];
                    const activeIndex = currentStageMeta.stepIndex;
                    const done = idx <= activeIndex;
                    const isCurrent = idx === activeIndex;
                    return (
                      <div
                        key={st}
                        className={`rounded-lg border p-3 transition-colors ${
                          isCurrent
                            ? 'border-violet-500 bg-violet-950/35'
                            : done
                              ? 'border-emerald-500/35 bg-emerald-950/20'
                              : 'border-white/10 bg-[#07070A]'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="font-mono-tabular text-[11px] text-zinc-500">
                            0{idx + 1}
                          </span>
                          {done && <Check className="h-3.5 w-3.5 text-emerald-400" />}
                        </div>
                        <div className="text-xs font-medium text-zinc-100">
                          {lang === 'ar' ? meta.ar : meta.en}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              <div className="mt-6 pt-5 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
                <div>
                  <span className="text-zinc-500 block">{t(lang, 'العميل', 'Client')}</span>
                  <span className="mt-1 block font-medium text-zinc-200">{trackedOrder.clientName}</span>
                </div>
                <div>
                  <span className="text-zinc-500 block">{t(lang, 'الميزانية', 'Budget')}</span>
                  <span className="mt-1 block font-medium text-zinc-200 font-mono-tabular">
                    {trackedOrder.budget}
                  </span>
                </div>
                <div>
                  <span className="text-zinc-500 block">{t(lang, 'التسليم المطلوب', 'Target Deadline')}</span>
                  <span className="mt-1 block font-medium text-zinc-200 font-mono-tabular">
                    {trackedOrder.deadline}
                  </span>
                </div>
                <div>
                  <span className="text-zinc-500 block">{t(lang, 'آخر تحديث', 'Last Updated')}</span>
                  <span className="mt-1 block font-medium text-zinc-200 font-mono-tabular">
                    {trackedOrder.updatedAt.slice(0, 10)}
                  </span>
                </div>
              </div>

              {trackedOrder.clientNote && (
                <div className="mt-6 rounded-lg border border-violet-500/30 bg-violet-950/25 p-4">
                  <h3 className="text-xs font-semibold text-violet-300 mb-1">
                    {t(lang, 'ملاحظة الإدارة للعميل', 'Agency Update Note')}
                  </h3>
                  <p className="text-sm text-zinc-200 leading-relaxed">{trackedOrder.clientNote}</p>
                </div>
              )}

              {trackedOrder.attachments.length > 0 && (
                <div className="mt-6 pt-5 border-t border-white/10">
                  <h3 className="text-xs font-semibold text-zinc-400 mb-2.5">
                    {t(lang, 'المرفقات المرسلة', 'Submitted Attachments')}
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {trackedOrder.attachments.map((att, i) => (
                      <span
                        key={i}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-[#07070A] px-3 py-1.5 text-xs text-zinc-300"
                      >
                        <Paperclip className="h-3 w-3 text-violet-400" />
                        <span>{att.original_name}</span>
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {trackedOrder.history.length > 0 && (
              <div className="rounded-xl border border-white/10 bg-[#0E0E14] p-6">
                <h3 className="text-sm font-semibold text-white mb-4">
                  {t(lang, 'سجل التحديثات', 'Status History')}
                </h3>
                <div className="space-y-3">
                  {trackedOrder.history.map((h, i) => {
                    const meta = STATUS_META[h.status];
                    return (
                      <div
                        key={i}
                        className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-white/[0.06] last:border-0 last:pb-0 text-xs"
                      >
                        <div>
                          <span className="font-semibold text-zinc-100">
                            {meta ? (lang === 'ar' ? meta.ar : meta.en) : h.status}
                          </span>
                          {h.note && <p className="mt-0.5 text-zinc-400">{h.note}</p>}
                        </div>
                        <span className="font-mono-tabular text-zinc-500 shrink-0">
                          {h.created_at}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
