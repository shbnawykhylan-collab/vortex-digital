import { useEffect, useState } from 'react';
import { ArrowLeft, ArrowRight, Check, ExternalLink } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { SERVICE_CATEGORIES, t } from '../i18n';
import type { ServiceItem } from '../types';
import { SafeImage } from '../components/SafeImage';

export function ServiceDetailPage({ slug }: { slug: string }) {
  const { lang, services, navigate, discordUrl } = useApp();
  const [service, setService] = useState<ServiceItem | null>(
    () => services.find((s) => s.slug === slug) || null
  );
  const [loading, setLoading] = useState(!service);

  const ArrowIcon = lang === 'ar' ? ArrowLeft : ArrowRight;

  useEffect(() => {
    const cached = services.find((s) => s.slug === slug);
    if (cached) {
      setService(cached);
      setLoading(false);
      return;
    }

    let cancelled = false;
    setLoading(true);
    fetch(`/api/services/${encodeURIComponent(slug)}`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!cancelled) setService(data);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [slug, services]);

  if (loading) {
    return (
      <div className="mx-auto max-w-[1200px] px-4 py-16 sm:px-6">
        <div className="h-72 rounded-xl border border-white/10 bg-[#0E0E14] animate-pulse" />
      </div>
    );
  }

  if (!service) {
    return (
      <div className="mx-auto max-w-[1200px] px-4 py-20 sm:px-6 text-center">
        <h1 className="text-2xl font-semibold text-white">
          {t(lang, 'الخدمة غير موجودة', 'Service Not Found')}
        </h1>
        <p className="mt-2 text-sm text-zinc-400">
          {t(lang, 'قد يكون الرابط غير صحيح أو تم إيقاف الخدمة مؤقتاً.', 'This service may be unavailable or moved.')}
        </p>
        <button
          type="button"
          onClick={() => navigate('/services')}
          className="mt-6 rounded-lg bg-[#7C3AED] px-5 py-2.5 text-sm font-medium text-white hover:bg-[#6D28D9] cursor-pointer"
        >
          {t(lang, 'العودة إلى الخدمات', 'Back to Services')}
        </button>
      </div>
    );
  }

  const category = SERVICE_CATEGORIES[service.category_key];
  const features = lang === 'ar' ? service.features_ar : service.features_en;

  return (
    <div className="py-12 sm:py-16">
      <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
        <div className="mb-8 flex items-center gap-2 text-xs text-zinc-400">
          <button type="button" onClick={() => navigate('/services')} className="hover:text-white cursor-pointer">
            {t(lang, 'الخدمات', 'Services')}
          </button>
          <span aria-hidden="true">/</span>
          <span>{category ? (lang === 'ar' ? category.titleAr : category.titleEn) : service.category_key}</span>
          <span aria-hidden="true">/</span>
          <span className="text-zinc-200">{lang === 'ar' ? service.title_ar : service.title_en}</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          <div className="lg:col-span-7 flex flex-col justify-between">
            <div>
              <div className="flex flex-wrap items-center gap-3 mb-3">
                <span className="font-mono-tabular text-sm font-semibold text-violet-300">
                  {lang === 'ar' ? service.price_label_ar : service.price_label_en}
                </span>
                <span aria-hidden="true" className="text-zinc-600">·</span>
                <span className="text-xs text-zinc-400">
                  {t(lang, 'السعر النهائي يتحدد حسب تفاصيل المشروع', 'Final price confirmed after scope review')}
                </span>
              </div>

              <h1 className="text-3xl sm:text-5xl font-bold text-white leading-tight text-balance">
                {lang === 'ar' ? service.title_ar : service.title_en}
              </h1>

              <p className="mt-5 text-base leading-relaxed text-zinc-300">
                {lang === 'ar' ? service.full_desc_ar : service.full_desc_en}
              </p>

              <div className="mt-8 pt-8 border-t border-white/10">
                <h2 className="text-base font-semibold text-white mb-4">
                  {t(lang, 'ما الذي ستحصل عليه', 'Included Deliverables')}
                </h2>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm text-zinc-300">
                  {features.map((feat) => (
                    <li key={feat} className="flex items-start gap-2.5">
                      <Check className="h-4 w-4 text-violet-400 mt-0.5 shrink-0" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="mt-10 flex flex-wrap items-center gap-3.5">
              <button
                type="button"
                onClick={() => navigate(`/order?service=${service.id}`)}
                className="inline-flex items-center gap-2 rounded-lg bg-[#7C3AED] px-6 py-3 text-sm font-medium text-white hover:bg-[#6D28D9] cursor-pointer"
              >
                <span>{t(lang, 'اطلب هذه الخدمة الآن', 'Order This Service')}</span>
                <ArrowIcon className="h-4 w-4" />
              </button>

              <a
                href={discordUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-[#0E0E14] px-5 py-3 text-sm font-medium text-zinc-200 hover:border-white/30"
              >
                <span>{t(lang, 'استفسر عبر Discord', 'Ask on Discord')}</span>
                <ExternalLink className="h-4 w-4" />
              </a>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="h-full min-h-[260px] overflow-hidden rounded-xl border border-white/10 bg-[#0E0E14]">
              <SafeImage
                src={service.image_url || category?.image || ''}
                alt={lang === 'ar' ? service.title_ar : service.title_en}
                className="h-full w-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
