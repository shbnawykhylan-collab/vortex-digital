import React, { useState } from 'react';
import { CheckCircle2, ExternalLink, Mail, MessageSquare } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { t } from '../i18n';

export function ContactPage() {
  const { lang, settings, discordUrl, navigate } = useApp();
  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSending(true);
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, contact, subject, message }),
      });
      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(lang === 'ar' ? data.messageAr || data.error : data.error);
        return;
      }
      setSent(true);
      setName('');
      setContact('');
      setSubject('');
      setMessage('');
    } catch {
      setErrorMsg(t(lang, 'تعذر إرسال الرسالة حالياً.', 'Failed to send message.'));
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="py-12 sm:py-16">
      <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
        <div className="max-w-2xl mb-12">
          <p className="text-xs font-medium text-violet-400 mb-2">
            {t(lang, 'قنوات التواصل المباشر', 'Direct Communication')}
          </p>
          <h1 className="text-3xl sm:text-5xl font-bold text-white">
            {t(lang, 'تواصل مع VORTEX DIGITAL', 'Contact VORTEX DIGITAL')}
          </h1>
          <p className="mt-3 text-base text-zinc-400 leading-relaxed">
            {t(
              lang,
              'اختر التواصل الفوري عبر مجتمعنا على Discord أو أرسل استفسارك مباشرة عبر النموذج.',
              'Connect instantly on our official Discord server or send an inquiry using the form below.'
            )}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-5 space-y-5">
            <div className="rounded-xl border border-violet-500/35 bg-[#12101C] p-6">
              <div className="flex items-center gap-2.5 text-violet-300 mb-3">
                <MessageSquare className="h-5 w-5" />
                <h2 className="text-lg font-semibold text-white">
                  {t(lang, 'مجتمع Discord الرسمي', 'Official Discord Community')}
                </h2>
              </div>
              <p className="text-sm text-zinc-300 leading-relaxed mb-5">
                {t(
                  lang,
                  'انضم إلى سيرفر Discord الرسمي للتحدث مع فريقنا، مناقشة تفاصيل المشاريع، ومتابعة العروض.',
                  'Join our official Discord server to chat directly with our studio team and discuss project details.'
                )}
              </p>
              <a
                href={discordUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[#7C3AED] px-5 py-3 text-sm font-medium text-white hover:bg-[#6D28D9] transition-colors"
              >
                <span>{t(lang, 'انضم إلى مجتمعنا على Discord', 'Join Our Discord Community')}</span>
                <ExternalLink className="h-4 w-4" />
              </a>
            </div>

            <div className="rounded-xl border border-white/10 bg-[#0E0E14] p-6 space-y-4">
              <div className="flex items-center gap-2.5 text-zinc-200">
                <Mail className="h-4 w-4 text-violet-400" />
                <span className="text-sm font-medium">
                  {settings.contact_email?.ar || 'contact@vortexdigital.agency'}
                </span>
              </div>
              <p className="text-xs text-zinc-400 leading-relaxed">
                {t(
                  lang,
                  'إذا كنت جاهزاً لتنفيذ مشروع محدد وإرفاق ملفاته، يمكنك استخدام نموذج الطلب المباشر للحصول على رقم متابعة.',
                  'Ready to start a specific project with file attachments? Use our service request form for instant order tracking.'
                )}
              </p>
              <button
                type="button"
                onClick={() => navigate('/order')}
                className="w-full rounded-lg border border-white/15 bg-white/[0.03] px-4 py-2.5 text-xs font-medium text-white hover:bg-white/[0.08] cursor-pointer"
              >
                {t(lang, 'الانتقال إلى نموذج طلب الخدمة', 'Go to Service Request Form')}
              </button>
            </div>
          </div>

          <div className="lg:col-span-7">
            <form
              onSubmit={handleSubmit}
              className="rounded-xl border border-white/10 bg-[#0E0E14] p-6 sm:p-8 space-y-5"
            >
              <h2 className="text-xl font-semibold text-white">
                {t(lang, 'أرسل رسالة سريعة', 'Send an Inquiry')}
              </h2>

              {sent && (
                <div className="flex items-center gap-2.5 rounded-lg border border-emerald-500/40 bg-emerald-950/35 px-4 py-3 text-sm text-emerald-200">
                  <CheckCircle2 className="h-4 w-4 shrink-0" />
                  <span>{t(lang, 'تم استلام رسالتك بنجاح وسيتواصل معك فريقنا قريباً.', 'Your message has been received. Our team will respond shortly.')}</span>
                </div>
              )}

              {errorMsg && (
                <div className="rounded-lg border border-rose-500/40 bg-rose-950/40 px-4 py-3 text-sm text-rose-200">
                  {errorMsg}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                    {t(lang, 'الاسم *', 'Name *')}
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3.5 py-2.5 text-sm text-white focus:border-violet-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                    {t(lang, 'وسيلة التواصل *', 'Contact (Email / Discord / Phone) *')}
                  </label>
                  <input
                    type="text"
                    required
                    value={contact}
                    onChange={(e) => setContact(e.target.value)}
                    className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3.5 py-2.5 text-sm text-white focus:border-violet-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                  {t(lang, 'الموضوع', 'Subject')}
                </label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3.5 py-2.5 text-sm text-white focus:border-violet-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                  {t(lang, 'الرسالة *', 'Message *')}
                </label>
                <textarea
                  required
                  rows={5}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full rounded-lg border border-white/15 bg-[#07070A] px-3.5 py-2.5 text-sm text-white focus:border-violet-500 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={sending}
                className="rounded-lg bg-[#7C3AED] px-6 py-2.5 text-sm font-medium text-white hover:bg-[#6D28D9] disabled:opacity-50 cursor-pointer"
              >
                {sending ? t(lang, 'جاري الإرسال...', 'Sending...') : t(lang, 'إرسال الرسالة', 'Send Message')}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
