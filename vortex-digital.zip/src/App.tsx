import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { PageUtilityBar } from './components/PageUtilityBar';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { AboutPage } from './pages/AboutPage';
import { ServicesPage } from './pages/ServicesPage';
import { ServiceDetailPage } from './pages/ServiceDetailPage';
import { PackagesPage } from './pages/PackagesPage';
import { OrderPage } from './pages/OrderPage';
import { TrackOrderPage } from './pages/TrackOrderPage';
import { ContactPage } from './pages/ContactPage';
import { AdminLoginPage } from './pages/AdminLoginPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';

function AppRouter() {
  const { route } = useApp();

  if (route === '/admin' || route.startsWith('/admin/dashboard')) {
    return <AdminDashboardPage />;
  }

  let content = <HomePage />;
  if (route === '/about') {
    content = <AboutPage />;
  } else if (route === '/services') {
    content = <ServicesPage />;
  } else if (route.startsWith('/services/')) {
    const slug = decodeURIComponent(route.replace('/services/', '').split('/')[0] || '');
    content = <ServiceDetailPage slug={slug} />;
  } else if (route === '/packages' || route === '/pricing') {
    content = <PackagesPage />;
  } else if (route === '/order') {
    content = <OrderPage />;
  } else if (route === '/track') {
    content = <TrackOrderPage />;
  } else if (route === '/contact') {
    content = <ContactPage />;
  } else if (route === '/admin/login') {
    content = <AdminLoginPage />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#07070A] text-[#F4F4F6]">
      <Navbar />
      <PageUtilityBar />
      <main className="flex-1">{content}</main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppRouter />
    </AppProvider>
  );
}
