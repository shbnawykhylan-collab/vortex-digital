export type Lang = 'ar' | 'en';

export type OrderStatus =
  | 'received'
  | 'reviewing'
  | 'awaiting_approval'
  | 'in_progress'
  | 'completed'
  | 'rejected';

export type LocalizedText = {
  ar: string;
  en: string;
};

export type SiteSettings = Record<string, LocalizedText>;

export type ServiceCategoryKey =
  | 'design-identity'
  | 'web-design'
  | 'programming-solutions'
  | 'content-social';

export type ServiceItem = {
  id: number;
  slug: string;
  category_key: ServiceCategoryKey;
  title_ar: string;
  title_en: string;
  short_desc_ar: string;
  short_desc_en: string;
  full_desc_ar: string;
  full_desc_en: string;
  features_ar: string[];
  features_en: string[];
  starting_price: number | null;
  price_label_ar: string;
  price_label_en: string;
  show_in_pricelist: boolean;
  is_active: boolean;
  sort_order: number;
  image_url: string;
};

export type PackageItem = {
  id: number;
  slug: string;
  name_ar: string;
  name_en: string;
  subtitle_ar: string;
  subtitle_en: string;
  price_display_ar: string;
  price_display_en: string;
  features_ar: string[];
  features_en: string[];
  is_featured: boolean;
  is_active: boolean;
  sort_order: number;
};

export type OrderAttachment = {
  id?: number;
  original_name: string;
  mime_type?: string;
  size_bytes: number;
  created_at?: string;
};

export type OrderHistoryItem = {
  status: OrderStatus;
  note: string;
  changed_by?: string;
  created_at: string;
};

export type TrackedOrder = {
  orderCode: string;
  clientName: string;
  contactMethod: string;
  serviceTitle: string;
  packageTitle: string;
  budget: string;
  deadline: string;
  status: OrderStatus;
  clientNote: string;
  createdAt: string;
  updatedAt: string;
  history: OrderHistoryItem[];
  attachments: OrderAttachment[];
};

export type AdminOrder = {
  id: number;
  order_code: string;
  client_id: number | null;
  client_name: string;
  contact_method: string;
  contact_value: string;
  service_id: number | null;
  service_title_snapshot: string;
  package_id: number | null;
  package_title_snapshot: string;
  project_description: string;
  budget: string;
  deadline: string;
  status: OrderStatus;
  admin_notes: string;
  client_visible_note: string;
  created_at: string;
  updated_at: string;
  attachments: OrderAttachment[];
};

export type AdminStats = {
  totalClients: number;
  totalOrders: number;
  newOrders: number;
  reviewingOrders: number;
  awaitingApprovalOrders: number;
  inProgressOrders: number;
  completedOrders: number;
  rejectedOrders: number;
  unreadMessages: number;
};

export type ClientRecord = {
  id: number;
  name: string;
  contact_method: string;
  contact_value: string;
  notes: string;
  orders_count: number;
  last_order_at: string | null;
  created_at: string;
};

export type ContactMessage = {
  id: number;
  name: string;
  contact: string;
  subject: string;
  message: string;
  is_read: number;
  created_at: string;
};
