import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type { Lang, PackageItem, ServiceItem, SiteSettings } from '../types';

type AppContextValue = {
  lang: Lang;
  setLang: (lang: Lang) => void;
  toggleLang: () => void;
  route: string;
  searchParams: URLSearchParams;
  navigate: (to: string) => void;
  settings: SiteSettings;
  services: ServiceItem[];
  packages: PackageItem[];
  loadingBootstrap: boolean;
  refreshBootstrap: () => Promise<void>;
  discordUrl: string;
};

const defaultSettings: SiteSettings = {
  agency_name: { ar: 'VORTEX DIGITAL', en: 'VORTEX DIGITAL' },
  hero_tagline: {
    ar: 'نحوّل أفكارك إلى واقع رقمي',
    en: 'Transforming Your Ideas Into Digital Reality',
  },
  hero_description: {
    ar: 'وكالة رقمية متخصصة في صياغة الهويات البصرية الفاخرة، تصميم وتطوير المواقع الحديثة، وبناء الأنظمة الرقمية المبتكرة بأعلى معايير الدقة والأمان.',
    en: 'A modern digital agency engineering luxury brand identities, responsive websites, and bespoke software systems with precision and security.',
  },
  about_title: {
    ar: 'شريكك التقني والإبداعي لبناء حضور رقمي متكامل',
    en: 'Your Creative & Engineering Partner for Modern Digital Presence',
  },
  about_description: {
    ar: 'في VORTEX DIGITAL نجمع بين الهندسة البرمجية المتقنة والتصميم البصري الفاخر لنقدّم حلولاً رقمية عملية قابلة للتوسع.',
    en: 'At VORTEX DIGITAL we unite disciplined software engineering with refined visual design to deliver scalable digital products.',
  },
  discord_url: {
    ar: 'https://discord.gg/AMuVG7fM4',
    en: 'https://discord.gg/AMuVG7fM4',
  },
  contact_email: {
    ar: 'contact@vortexdigital.agency',
    en: 'contact@vortexdigital.agency',
  },
  pricelist_note: {
    ar: 'الأسعار المعروضة هي أسعار البداية بالدولار الأمريكي؛ ويتم تحديد التكلفة النهائية بدقة بعد مراجعة تفاصيل ومتطلبات المشروع.',
    en: 'Listed rates represent starting prices in USD. Final pricing is confirmed after reviewing your project scope and deliverables.',
  },
};

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => {
    try {
      const saved = localStorage.getItem('vortex_lang');
      return saved === 'en' ? 'en' : 'ar';
    } catch {
      return 'ar';
    }
  });

  const [locationUrl, setLocationUrl] = useState<string>(
    () => `${window.location.pathname}${window.location.search}`
  );
  const [settings, setSettings] = useState<SiteSettings>(defaultSettings);
  const [services, setServices] = useState<ServiceItem[]>([]);
  const [packages, setPackages] = useState<PackageItem[]>([]);
  const [loadingBootstrap, setLoadingBootstrap] = useState<boolean>(true);

  const setLang = useCallback((nextLang: Lang) => {
    setLangState(nextLang);
    try {
      localStorage.setItem('vortex_lang', nextLang);
    } catch {
      // ignore storage failure
    }
  }, []);

  const toggleLang = useCallback(() => {
    setLang(lang === 'ar' ? 'en' : 'ar');
  }, [lang, setLang]);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  useEffect(() => {
    const onPopState = () => {
      setLocationUrl(`${window.location.pathname}${window.location.search}`);
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  const navigate = useCallback((to: string) => {
    const target = to.startsWith('/') ? to : `/${to}`;
    window.history.pushState({}, '', target);
    setLocationUrl(target);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const refreshBootstrap = useCallback(async () => {
    try {
      const res = await fetch('/api/bootstrap');
      if (!res.ok) return;
      const data = await res.json();
      if (data.settings) setSettings((prev) => ({ ...prev, ...data.settings }));
      if (Array.isArray(data.services)) setServices(data.services);
      if (Array.isArray(data.packages)) setPackages(data.packages);
    } catch {
      // keep fallback state
    } finally {
      setLoadingBootstrap(false);
    }
  }, []);

  useEffect(() => {
    refreshBootstrap();
  }, [refreshBootstrap]);

  const [pathname, searchStr = ''] = locationUrl.split('?');
  const searchParams = new URLSearchParams(searchStr);
  const discordUrl = settings.discord_url?.ar || 'https://discord.gg/AMuVG7fM4';

  return (
    <AppContext.Provider
      value={{
        lang,
        setLang,
        toggleLang,
        route: pathname || '/',
        searchParams,
        navigate,
        settings,
        services,
        packages,
        loadingBootstrap,
        refreshBootstrap,
        discordUrl,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
