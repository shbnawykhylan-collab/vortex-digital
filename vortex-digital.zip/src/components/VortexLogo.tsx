export function VortexLogoMark({ size = 32 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      className="shrink-0"
    >
      <defs>
        <linearGradient id="vortexSilver" x1="4" y1="4" x2="36" y2="36" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="55%" stopColor="#D4D4DC" />
          <stop offset="100%" stopColor="#7C3AED" />
        </linearGradient>
        <linearGradient id="vortexInner" x1="20" y1="8" x2="20" y2="35" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#A78BFA" />
          <stop offset="100%" stopColor="#6D28D9" />
        </linearGradient>
      </defs>
      <rect
        x="1.5"
        y="1.5"
        width="37"
        height="37"
        rx="8"
        fill="#0E0E14"
        stroke="rgba(212, 212, 220, 0.22)"
        strokeWidth="1.2"
      />
      <path
        d="M9.5 10.5L20 31.5L30.5 10.5H25.2L20 21.4L14.8 10.5H9.5Z"
        fill="url(#vortexSilver)"
      />
      <path
        d="M16.2 10.5L20 18.2L23.8 10.5H16.2Z"
        fill="url(#vortexInner)"
      />
    </svg>
  );
}
