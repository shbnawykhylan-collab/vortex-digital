import { useState } from 'react';
import { VortexLogoMark } from './VortexLogo';
import { resolveMediaUrl } from '../assets/media';

type SafeImageProps = {
  src: string;
  alt: string;
  className?: string;
};

export function SafeImage({ src, alt, className = '' }: SafeImageProps) {
  const [failed, setFailed] = useState(false);
  const resolvedSrc = resolveMediaUrl(src);

  if (!resolvedSrc || failed) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-[#12121A] via-[#0B0B10] to-[#1A132B] border border-white/10 p-6 text-center ${className}`}
      >
        <VortexLogoMark size={38} />
        <span className="mt-3 text-xs text-zinc-400">{alt}</span>
      </div>
    );
  }

  return (
    <img
      src={resolvedSrc}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
}
