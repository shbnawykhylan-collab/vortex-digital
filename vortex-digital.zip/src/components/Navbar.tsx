import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { t } from '../i18n';
import { VortexLogoMark } from './VortexLogo';

export function Navbar() {
  const { lang, toggleLang, route, navigate, discordUrl } = useApp();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems = [
    { path: '/', label: t(lang, 'الرئيسية', 'Home') },
    { path: '/about', label: t(lang, 'من نحن', 'About') },
    { path: '/services', label: t(lang, 'الخدمات', 'Services') },
    { path: '/packages', label: t(lang, 'الباقات والأسعار', 'Packages') },
    { path: '/track', label: t(lang, 'متابعة الطلب', 'Track Order') },
  ];

  const handleNav = (path: string) => {
    setMobileOpen(false);
    navigate(path);
  };

  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-[#07070A]/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-[1200px] items-center justify-between gap-8 px-4 sm:px-6">
        {/* Zone 1: Single-line Brand Wordmark */}
        <button
          type="button"
          onClick={() => handleNav('/')}
          className="flex items-center gap-2.5 text-start focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 rounded-md whitespace-nowrap shrink-0 cursor-pointer"
        >
          <VortexLogoMark size={30} />
          <span className="font-display text-base sm:text-lg font-semibold tracking-tight text-white whitespace-nowrap shrink-0">
            VORTEX DIGITAL
          </span>
        </button>

        {/* Zone 2: 5 concise single-line nav links */}
        <nav
          aria-label={t(lang, 'التنقل الرئيسي', 'Main Navigation')}
          className="hidden lg:flex items-center gap-7 text-sm font-medium"
        >
          {navItems.map((item) => {
            const active =
              item.path === '/'
                ? route === '/'
                : route === item.path || route.startsWith(`${item.path}/`);
            return (
              <button
                key={item.path}
                type="button"
                onClick={() => handleNav(item.path)}
                className={`relative py-1 transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 rounded ${
                  active
                    ? 'text-white'
                    : 'text-zinc-400 hover:text-zinc-100'
                }`}
              >
                {item.label}
                {active && (
                  <span
                    aria-hidden="true"
                    className="absolute inset-x-0 -bottom-0.5 h-px bg-violet-500"
                  />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 primary action on desktop + mobile toggle */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => handleNav('/order')}
            className="hidden lg:inline-flex items-center justify-center rounded-lg bg-[#7C3AED] px-4 py-2 text-sm font-medium text-white transition-colors duration-150 hover:bg-[#6D28D9] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-400 whitespace-nowrap shrink-0 cursor-pointer"
          >
            {t(lang, 'اطلب خدمتك', 'Request Service')}
          </button>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-label={t(lang, 'فتح القائمة', 'Toggle menu')}
            aria-expanded={mobileOpen}
            className="lg:hidden inline-flex h-10 w-10 items-center justify-center rounded-lg border border-white/10 bg-[#0E0E14] text-zinc-200 hover:border-white/25 cursor-pointer"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="lg:hidden border-t border-white/10 bg-[#0B0B10] px-4 py-4">
          <div className="flex flex-col gap-1">
            {navItems.map((item) => {
              const active = route === item.path;
              return (
                <button
                  key={item.path}
                  type="button"
                  onClick={() => handleNav(item.path)}
                  className={`flex items-center justify-between rounded-lg px-3 py-2.5 text-sm font-medium text-start cursor-pointer ${
                    active ? 'bg-violet-600/15 text-white' : 'text-zinc-300 hover:bg-white/5'
                  }`}
                >
                  <span>{item.label}</span>
                </button>
              );
            })}
            <button
              type="button"
              onClick={() => handleNav('/contact')}
              className="flex items-center justify-between rounded-lg px-3 py-2.5 text-sm font-medium text-zinc-300 hover:bg-white/5 text-start cursor-pointer"
            >
              <span>{t(lang, 'التواصل', 'Contact')}</span>
            </button>
          </div>

          <div className="mt-4 pt-4 border-t border-white/10 flex flex-col gap-2.5">
            <button
              type="button"
              onClick={() => handleNav('/order')}
              className="w-full rounded-lg bg-[#7C3AED] px-4 py-2.5 text-sm font-medium text-white hover:bg-[#6D28D9] cursor-pointer"
            >
              {t(lang, 'اطلب خدمتك الآن', 'Request a Service')}
            </button>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  toggleLang();
                  setMobileOpen(false);
                }}
                className="rounded-lg border border-white/10 bg-[#0E0E14] px-3 py-2 text-xs font-medium text-zinc-200 hover:border-white/25 cursor-pointer"
              >
                {lang === 'ar' ? 'English (LTR)' : 'العربية (RTL)'}
              </button>
              <a
                href={discordUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center rounded-lg border border-violet-500/30 bg-violet-950/30 px-3 py-2 text-xs font-medium text-violet-200 hover:bg-violet-900/40"
              >
                Discord
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
