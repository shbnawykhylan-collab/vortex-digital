import { ArrowLeft, ArrowRight, ExternalLink } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { t } from '../i18n';

export function PriceListSection() {
  const { lang, services, settings, navigate, discordUrl, loadingBootstrap } = useApp();
  const ArrowIcon = lang === 'ar' ? ArrowLeft : ArrowRight;

  const pricelistServices = services.filter((s) => s.show_in_pricelist);

  return (
    <section id="pricelist" className="py-16 sm:py-24 border-t border-white/10 bg-[#08080C]">
      <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10">
          <div className="max-w-2xl">
            <p className="text-xs font-medium text-violet-400 mb-2">
              {t(lang, 'أسعار واضحة ومرنة', 'Transparent Starting Rates')}
            </p>
            <h2 className="text-2xl sm:text-4xl font-semibold tracking-tight text-white text-balance">
              {t(lang, 'قائمة الأسعار', 'Price List')}
            </h2>
            <p className="mt-3 text-sm sm:text-base text-zinc-400 leading-relaxed">
              {lang === 'ar' ? settings.pricelist_note?.ar : settings.pricelist_note?.en}
            </p>
          </div>

          <a
            href={discordUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 rounded-lg border border-violet-500/40 bg-violet-950/35 px-5 py-2.5 text-sm font-medium text-violet-100 transition-colors hover:bg-violet-900/50 whitespace-nowrap shrink-0"
          >
            <span>{t(lang, 'انضم إلى مجتمعنا على Discord', 'Join Our Discord Community')}</span>
            <ExternalLink className="h-4 w-4 text-violet-300" />
          </a>
        </div>

        {loadingBootstrap && pricelistServices.length === 0 ? (
          <div className="grid gap-3">
            {[1, 2, 3, 4].map((n) => (
              <div
                key={n}
                className="h-16 rounded-xl border border-white/10 bg-[#0E0E14] animate-pulse"
              />
            ))}
          </div>
        ) : (
          <div className="overflow-hidden rounded-xl border border-white/10 bg-[#0E0E14]">
            <div className="divide-y divide-white/[0.07]">
              {pricelistServices.map((item, idx) => (
                <div
                  key={item.id}
                  className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 px-5 py-4 sm:px-6 transition-colors hover:bg-white/[0.02]"
                >
                  <div className="flex items-start sm:items-center gap-4 min-w-0">
                    <span className="font-mono-tabular text-xs text-zinc-500 pt-1 sm:pt-0 shrink-0">
                      {String(idx + 1).padStart(2, '0')}
                    </span>
                    <div className="min-w-0">
                      <button
                        type="button"
                        onClick={() => navigate(`/services/${item.slug}`)}
                        className="text-base font-semibold text-white hover:text-violet-300 transition-colors text-start cursor-pointer"
                      >
                        {lang === 'ar' ? item.title_ar : item.title_en}
                      </button>
                      <p className="mt-0.5 text-xs sm:text-sm text-zinc-400 line-clamp-1">
                        {lang === 'ar' ? item.short_desc_ar : item.short_desc_en}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-4 shrink-0">
                    <div className="text-start sm:text-end">
                      <span className="font-mono-tabular text-sm sm:text-base font-semibold text-zinc-100">
                        {lang === 'ar' ? item.price_label_ar : item.price_label_en}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => navigate(`/order?service=${item.id}`)}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-[#7C3AED] px-4 py-2 text-xs sm:text-sm font-medium text-white transition-colors hover:bg-[#6D28D9] whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <span>{t(lang, 'اطلب هذه الخدمة', 'Order This Service')}</span>
                      <ArrowIcon className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
