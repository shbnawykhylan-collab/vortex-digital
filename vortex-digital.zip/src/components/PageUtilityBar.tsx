import { Globe, MessageSquare, ShieldCheck } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { t } from '../i18n';

export function PageUtilityBar() {
  const { lang, toggleLang, navigate, discordUrl } = useApp();

  return (
    <div className="border-b border-white/[0.06] bg-[#0A0A0F]">
      <div className="mx-auto flex max-w-[1200px] flex-wrap items-center justify-between gap-3 px-4 py-2 text-xs text-zinc-400 sm:px-6">
        <div className="flex items-center gap-4">
          <button
            type="button"
            onClick={() => navigate('/contact')}
            className="inline-flex items-center gap-1.5 hover:text-zinc-100 transition-colors cursor-pointer whitespace-nowrap"
          >
            <MessageSquare className="h-3.5 w-3.5 text-zinc-400" />
            <span>{t(lang, 'تواصل معنا', 'Contact Us')}</span>
          </button>
          <span aria-hidden="true" className="text-zinc-700">·</span>
          <a
            href={discordUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-violet-300 transition-colors whitespace-nowrap"
          >
            {t(lang, 'مجتمع Discord الرسمي', 'Official Discord')}
          </a>
        </div>

        <div className="flex items-center gap-4">
          <button
            type="button"
            onClick={() => navigate('/admin/login')}
            className="inline-flex items-center gap-1.5 hover:text-zinc-200 transition-colors cursor-pointer whitespace-nowrap"
          >
            <ShieldCheck className="h-3.5 w-3.5 text-zinc-500" />
            <span>{t(lang, 'الإدارة', 'Admin')}</span>
          </button>
          <span aria-hidden="true" className="text-zinc-700">·</span>
          <button
            type="button"
            onClick={toggleLang}
            className="inline-flex items-center gap-1.5 font-medium text-zinc-200 hover:text-violet-300 transition-colors cursor-pointer whitespace-nowrap"
          >
            <Globe className="h-3.5 w-3.5 text-violet-400" />
            <span>{lang === 'ar' ? 'English' : 'العربية'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
