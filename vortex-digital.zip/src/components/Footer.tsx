import { ExternalLink } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { t } from '../i18n';
import { VortexLogoMark } from './VortexLogo';

export function Footer() {
  const { lang, toggleLang, navigate, settings, discordUrl } = useApp();

  return (
    <footer className="border-t border-white/10 bg-[#050508]">
      <div className="mx-auto max-w-[1200px] px-4 py-12 sm:px-6">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-12">
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-2.5">
              <VortexLogoMark size={28} />
              <span className="font-display text-base font-semibold text-white">
                VORTEX DIGITAL
              </span>
            </div>
            <p className="text-sm text-zinc-400 leading-relaxed max-w-sm">
              {lang === 'ar' ? settings.hero_tagline?.ar : settings.hero_tagline?.en}
              {' — '}
              {t(
                lang,
                'نبتكر هويات بصرية، مواقع إلكترونية، وأنظمة رقمية مبنية بدقة وأمان.',
                'Crafting brand identities, modern websites, and secure digital systems.'
              )}
            </p>
            <div className="pt-1">
              <a
                href={discordUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-lg border border-violet-500/35 bg-violet-950/30 px-4 py-2 text-xs font-medium text-violet-200 hover:bg-violet-900/45 transition-colors"
              >
                <span>{t(lang, 'انضم إلى مجتمعنا على Discord', 'Join Our Discord Community')}</span>
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </div>
          </div>

          <div className="md:col-span-3 space-y-3">
            <h3 className="text-xs font-semibold text-zinc-300">
              {t(lang, 'روابط سريعة', 'Navigation')}
            </h3>
            <ul className="space-y-2 text-sm text-zinc-400">
              <li>
                <button type="button" onClick={() => navigate('/')} className="hover:text-white cursor-pointer">
                  {t(lang, 'الرئيسية', 'Home')}
                </button>
              </li>
              <li>
                <button type="button" onClick={() => navigate('/about')} className="hover:text-white cursor-pointer">
                  {t(lang, 'من نحن', 'About Us')}
                </button>
              </li>
              <li>
                <button type="button" onClick={() => navigate('/services')} className="hover:text-white cursor-pointer">
                  {t(lang, 'الخدمات', 'Services')}
                </button>
              </li>
              <li>
                <button type="button" onClick={() => navigate('/packages')} className="hover:text-white cursor-pointer">
                  {t(lang, 'الباقات والأسعار', 'Packages & Pricing')}
                </button>
              </li>
            </ul>
          </div>

          <div className="md:col-span-4 space-y-3">
            <h3 className="text-xs font-semibold text-zinc-300">
              {t(lang, 'الطلبات والدعم', 'Orders & Portal')}
            </h3>
            <ul className="space-y-2 text-sm text-zinc-400">
              <li>
                <button type="button" onClick={() => navigate('/order')} className="hover:text-white cursor-pointer">
                  {t(lang, 'طلب خدمة جديدة', 'Request a Service')}
                </button>
              </li>
              <li>
                <button type="button" onClick={() => navigate('/track')} className="hover:text-white cursor-pointer">
                  {t(lang, 'متابعة حالة الطلب', 'Track Order Status')}
                </button>
              </li>
              <li>
                <button type="button" onClick={() => navigate('/contact')} className="hover:text-white cursor-pointer">
                  {t(lang, 'تواصل معنا', 'Contact Us')}
                </button>
              </li>
              <li>
                <button type="button" onClick={() => navigate('/admin/login')} className="hover:text-violet-300 cursor-pointer">
                  {t(lang, 'بوابة الإدارة', 'Admin Portal')}
                </button>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-500">
          <p>
            © <span className="tabular-nums">{new Date().getFullYear()}</span> VORTEX DIGITAL.{' '}
            {t(lang, 'جميع الحقوق محفوظة.', 'All rights reserved.')}
          </p>
          <button
            type="button"
            onClick={toggleLang}
            className="text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            {lang === 'ar' ? 'Switch to English (LTR)' : 'التبديل إلى العربية (RTL)'}
          </button>
        </div>
      </div>
    </footer>
  );
}
