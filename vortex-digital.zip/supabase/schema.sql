-- VORTEX DIGITAL PostgreSQL / Supabase Migration Schema
-- Optional schema if migrating from the built-in SQLite database to Supabase Postgres.
-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 1. Clients Table
CREATE TABLE IF NOT EXISTS public.clients (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name TEXT NOT NULL,
  contact_method TEXT NOT NULL CHECK (contact_method IN ('Discord', 'WhatsApp', 'Email', 'Telegram')),
  contact_value TEXT NOT NULL UNIQUE,
  notes TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. Services & Price List Table
CREATE TABLE IF NOT EXISTS public.services (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  category_key TEXT NOT NULL,
  title_ar TEXT NOT NULL,
  title_en TEXT NOT NULL,
  short_desc_ar TEXT NOT NULL,
  short_desc_en TEXT NOT NULL,
  full_desc_ar TEXT NOT NULL,
  full_desc_en TEXT NOT NULL,
  features_ar JSONB NOT NULL DEFAULT '[]'::jsonb,
  features_en JSONB NOT NULL DEFAULT '[]'::jsonb,
  starting_price NUMERIC(10, 2),
  price_label_ar TEXT NOT NULL,
  price_label_en TEXT NOT NULL,
  show_in_pricelist BOOLEAN NOT NULL DEFAULT TRUE,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  image_url TEXT NOT NULL DEFAULT ''
);

-- 3. Packages Table
CREATE TABLE IF NOT EXISTS public.packages (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name_ar TEXT NOT NULL,
  name_en TEXT NOT NULL,
  subtitle_ar TEXT NOT NULL,
  subtitle_en TEXT NOT NULL,
  price_display_ar TEXT NOT NULL,
  price_display_en TEXT NOT NULL,
  features_ar JSONB NOT NULL DEFAULT '[]'::jsonb,
  features_en JSONB NOT NULL DEFAULT '[]'::jsonb,
  is_featured BOOLEAN NOT NULL DEFAULT FALSE,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order INTEGER NOT NULL DEFAULT 0
);

-- 4. Orders Table
CREATE TABLE IF NOT EXISTS public.orders (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  order_code TEXT NOT NULL UNIQUE,
  client_id BIGINT REFERENCES public.clients(id) ON DELETE SET NULL,
  client_name TEXT NOT NULL,
  contact_method TEXT NOT NULL,
  contact_value TEXT NOT NULL,
  service_id BIGINT REFERENCES public.services(id) ON DELETE SET NULL,
  service_title_snapshot TEXT NOT NULL,
  package_id BIGINT REFERENCES public.packages(id) ON DELETE SET NULL,
  package_title_snapshot TEXT NOT NULL DEFAULT '',
  project_description TEXT NOT NULL,
  budget TEXT NOT NULL,
  deadline TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'received'
    CHECK (status IN ('received', 'reviewing', 'awaiting_approval', 'in_progress', 'completed', 'rejected')),
  admin_notes TEXT NOT NULL DEFAULT '',
  client_visible_note TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. Order Attachments & History
CREATE TABLE IF NOT EXISTS public.order_attachments (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  order_id BIGINT NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  original_name TEXT NOT NULL,
  stored_name TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.order_status_history (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  order_id BIGINT NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  changed_by TEXT NOT NULL DEFAULT 'system',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. Contact Messages & Site Settings
CREATE TABLE IF NOT EXISTS public.contact_messages (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name TEXT NOT NULL,
  contact TEXT NOT NULL,
  subject TEXT NOT NULL,
  message TEXT NOT NULL,
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.site_settings (
  key TEXT PRIMARY KEY,
  value_ar TEXT NOT NULL,
  value_en TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_attachments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_status_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contact_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;

-- Public Read Policies (Catalog & Settings only)
CREATE POLICY "Public read active services" ON public.services
  FOR SELECT USING (is_active = TRUE);

CREATE POLICY "Public read active packages" ON public.packages
  FOR SELECT USING (is_active = TRUE);

CREATE POLICY "Public read site settings" ON public.site_settings
  FOR SELECT USING (TRUE);

-- All orders, clients, attachments, and admin mutations are performed via Server / Service Role
-- or verified RPC functions to prevent unauthorized client data exposure.
