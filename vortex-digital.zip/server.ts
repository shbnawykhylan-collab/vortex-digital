import 'dotenv/config';
import express, { type NextFunction, type Request, type Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import multer from 'multer';
import JSZip from 'jszip';
import { initDatabase, queryAll, queryOne, runExec } from './server/db.ts';
import {
  createRateLimiter,
  generateOrderCode,
  hashPassword,
  parseCookies,
  sanitizeText,
  signSessionToken,
  verifyPassword,
  verifySessionToken,
  type AdminTokenPayload,
} from './server/security.ts';

const ALLOWED_STATUSES = [
  'received',
  'reviewing',
  'awaiting_approval',
  'in_progress',
  'completed',
  'rejected',
] as const;

type OrderStatus = (typeof ALLOWED_STATUSES)[number];

const ALLOWED_CONTACT_METHODS = ['Discord', 'WhatsApp', 'Email', 'Telegram'] as const;

type AuthedRequest = Request & { admin?: AdminTokenPayload };

const uploadsDir = path.resolve(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const allowedExtensions = new Set([
  '.png',
  '.jpg',
  '.jpeg',
  '.webp',
  '.gif',
  '.svg',
  '.pdf',
  '.zip',
  '.txt',
  '.doc',
  '.docx',
]);

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadsDir),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      const safeExt = allowedExtensions.has(ext) ? ext : '.bin';
      const unique = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}${safeExt}`;
      cb(null, unique);
    },
  }),
  limits: {
    fileSize: 5 * 1024 * 1024,
    files: 5,
  },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (!allowedExtensions.has(ext)) {
      cb(new Error('Unsupported file extension'));
      return;
    }
    cb(null, true);
  },
});

const loginLimiter = createRateLimiter(15 * 60 * 1000, 12);
const trackLimiter = createRateLimiter(5 * 60 * 1000, 40);
const orderLimiter = createRateLimiter(10 * 60 * 1000, 15);

function getClientIp(req: Request): string {
  const fwd = req.headers['x-forwarded-for'];
  if (typeof fwd === 'string' && fwd.length > 0) {
    return fwd.split(',')[0].trim();
  }
  return req.ip || 'unknown';
}

function requireAdmin(req: AuthedRequest, res: Response, next: NextFunction): void {
  const cookies = parseCookies(req.headers.cookie);
  const token = cookies['vortex_admin_session'];
  const payload = verifySessionToken(token);
  if (!payload) {
    res.status(401).json({ error: 'Unauthorized', messageAr: 'يرجى تسجيل الدخول للإدارة أولاً.' });
    return;
  }
  req.admin = payload;
  next();
}

function parseJsonArray(raw: unknown): string[] {
  if (typeof raw !== 'string') return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.map(String) : [];
  } catch {
    return [];
  }
}

async function startServer() {
  await initDatabase();

  const app = express();
  const PORT = Number(process.env.PORT || 3000);
  const isProd = process.env.NODE_ENV === 'production';

  app.set('trust proxy', 1);
  app.disable('x-powered-by');
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  app.use(express.json({ limit: '2mb' }));
  app.use(express.urlencoded({ extended: true, limit: '2mb' }));

  // Public bootstrap data (settings, active services, active packages)
  app.get('/api/bootstrap', (_req, res) => {
    try {
      const settingsRows = queryAll<{ key: string; value_ar: string; value_en: string }>(
        'SELECT key, value_ar, value_en FROM site_settings'
      );
      const settings: Record<string, { ar: string; en: string }> = {};
      for (const row of settingsRows) {
        settings[row.key] = { ar: row.value_ar, en: row.value_en };
      }

      const servicesRaw = queryAll<Record<string, unknown>>(
        'SELECT * FROM services WHERE is_active = 1 ORDER BY sort_order ASC, id ASC'
      );
      const services = servicesRaw.map((s) => ({
        ...s,
        features_ar: parseJsonArray(s.features_ar),
        features_en: parseJsonArray(s.features_en),
        show_in_pricelist: Boolean(s.show_in_pricelist),
        is_active: Boolean(s.is_active),
      }));

      const packagesRaw = queryAll<Record<string, unknown>>(
        'SELECT * FROM packages WHERE is_active = 1 ORDER BY sort_order ASC, id ASC'
      );
      const packages = packagesRaw.map((p) => ({
        ...p,
        features_ar: parseJsonArray(p.features_ar),
        features_en: parseJsonArray(p.features_en),
        is_featured: Boolean(p.is_featured),
        is_active: Boolean(p.is_active),
      }));

      res.json({ settings, services, packages });
    } catch {
      res.status(500).json({ error: 'Failed to load agency data' });
    }
  });

  // Public single service detail
  app.get('/api/services/:slug', (req, res) => {
    const slug = sanitizeText(req.params.slug, 100);
    const service = queryOne<Record<string, unknown>>(
      'SELECT * FROM services WHERE slug = ? AND is_active = 1',
      [slug]
    );
    if (!service) {
      res.status(404).json({ error: 'Service not found' });
      return;
    }
    res.json({
      ...service,
      features_ar: parseJsonArray(service.features_ar),
      features_en: parseJsonArray(service.features_en),
      show_in_pricelist: Boolean(service.show_in_pricelist),
      is_active: Boolean(service.is_active),
    });
  });

  // Public order submission with real DB persistence and file attachments
  app.post('/api/orders', (req, res) => {
    if (!orderLimiter(getClientIp(req))) {
      res.status(429).json({
        error: 'Too many requests',
        messageAr: 'تم إرسال عدد كبير من الطلبات مؤقتاً، يرجى المحاولة بعد قليل.',
      });
      return;
    }

    upload.array('attachments', 5)(req, res, (uploadErr) => {
      if (uploadErr) {
        res.status(400).json({
          error: uploadErr.message || 'Invalid attachment',
          messageAr: 'تعذر رفع المرفق: تأكد أن حجم الملف أقل من 5MB وبصيغة مسموحة.',
        });
        return;
      }

      try {
        const clientName = sanitizeText(req.body.clientName, 120);
        const contactMethod = sanitizeText(req.body.contactMethod, 40);
        const contactValue = sanitizeText(req.body.contactValue, 160);
        const serviceIdRaw = req.body.serviceId ? Number(req.body.serviceId) : null;
        const packageIdRaw = req.body.packageId ? Number(req.body.packageId) : null;
        const projectDescription = sanitizeText(req.body.projectDescription, 4000);
        const budget = sanitizeText(req.body.budget, 100);
        const deadline = sanitizeText(req.body.deadline, 80);

        if (!clientName || clientName.length < 2) {
          res.status(400).json({
            error: 'Invalid client name',
            messageAr: 'يرجى إدخال اسم العميل بشكل صحيح.',
          });
          return;
        }

        if (!ALLOWED_CONTACT_METHODS.includes(contactMethod as (typeof ALLOWED_CONTACT_METHODS)[number])) {
          res.status(400).json({
            error: 'Invalid contact method',
            messageAr: 'يرجى اختيار وسيلة تواصل صحيحة.',
          });
          return;
        }

        if (!contactValue || contactValue.length < 3) {
          res.status(400).json({
            error: 'Invalid contact value',
            messageAr: 'يرجى إدخال بيانات التواصل (حساب ديسكورد أو رقم واتساب أو البريد الإلكتروني).',
          });
          return;
        }

        if (!projectDescription || projectDescription.length < 10) {
          res.status(400).json({
            error: 'Project description too short',
            messageAr: 'يرجى كتابة وصف واضح للمشروع (10 أحرف على الأقل).',
          });
          return;
        }

        let serviceTitleSnapshot = sanitizeText(req.body.customServiceTitle, 160);
        let validServiceId: number | null = null;
        if (serviceIdRaw && Number.isFinite(serviceIdRaw)) {
          const svc = queryOne<{ id: number; title_ar: string; title_en: string }>(
            'SELECT id, title_ar, title_en FROM services WHERE id = ?',
            [serviceIdRaw]
          );
          if (svc) {
            validServiceId = svc.id;
            serviceTitleSnapshot = `${svc.title_ar} (${svc.title_en})`;
          }
        }
        if (!serviceTitleSnapshot) {
          res.status(400).json({
            error: 'Service required',
            messageAr: 'يرجى اختيار الخدمة المطلوبة.',
          });
          return;
        }

        let packageTitleSnapshot = '';
        let validPackageId: number | null = null;
        if (packageIdRaw && Number.isFinite(packageIdRaw)) {
          const pkg = queryOne<{ id: number; name_ar: string; name_en: string }>(
            'SELECT id, name_ar, name_en FROM packages WHERE id = ?',
            [packageIdRaw]
          );
          if (pkg) {
            validPackageId = pkg.id;
            packageTitleSnapshot = `${pkg.name_ar} (${pkg.name_en})`;
          }
        }

        // Upsert client record keyed by normalized contact_value
        const normalizedContact = contactValue.toLowerCase();
        let existingClient = queryOne<{ id: number }>(
          'SELECT id FROM clients WHERE lower(contact_value) = ?',
          [normalizedContact]
        );
        let clientId: number;
        if (existingClient) {
          clientId = existingClient.id;
          runExec('UPDATE clients SET name = ?, contact_method = ? WHERE id = ?', [
            clientName,
            contactMethod,
            clientId,
          ]);
        } else {
          clientId = runExec(
            'INSERT INTO clients (name, contact_method, contact_value) VALUES (?, ?, ?)',
            [clientName, contactMethod, contactValue]
          );
        }

        let orderCode = generateOrderCode();
        while (queryOne('SELECT id FROM orders WHERE order_code = ?', [orderCode])) {
          orderCode = generateOrderCode();
        }

        const orderId = runExec(
          `INSERT INTO orders (
            order_code, client_id, client_name, contact_method, contact_value,
            service_id, service_title_snapshot, package_id, package_title_snapshot,
            project_description, budget, deadline, status
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'received')`,
          [
            orderCode,
            clientId,
            clientName,
            contactMethod,
            contactValue,
            validServiceId,
            serviceTitleSnapshot,
            validPackageId,
            packageTitleSnapshot,
            projectDescription,
            budget || 'يحدد بعد المراجعة',
            deadline || 'مرن',
          ]
        );

        runExec(
          'INSERT INTO order_status_history (order_id, status, note, changed_by) VALUES (?, ?, ?, ?)',
          [orderId, 'received', 'تم استلام الطلب بنجاح وجاري إدراجه للمراجعة.', 'system']
        );

        const files = (req.files as Express.Multer.File[] | undefined) || [];
        for (const f of files) {
          runExec(
            `INSERT INTO order_attachments (order_id, original_name, stored_name, mime_type, size_bytes)
             VALUES (?, ?, ?, ?, ?)`,
            [orderId, sanitizeText(f.originalname, 200), f.filename, f.mimetype, f.size]
          );
        }

        res.status(201).json({
          orderCode,
          status: 'received',
          serviceTitle: serviceTitleSnapshot,
          attachmentsCount: files.length,
        });
      } catch {
        res.status(500).json({
          error: 'Order creation failed',
          messageAr: 'حدث خطأ أثناء حفظ الطلب، يرجى المحاولة مرة أخرى.',
        });
      }
    });
  });

  // Public private-verified order tracking (requires BOTH orderCode and matching contactValue)
  app.post('/api/orders/track', (req, res) => {
    if (!trackLimiter(getClientIp(req))) {
      res.status(429).json({
        error: 'Too many tracking requests',
        messageAr: 'محاولات متابعة كثيرة، يرجى الانتظار بضع دقائق.',
      });
      return;
    }

    const orderCode = sanitizeText(req.body.orderCode, 40).toUpperCase();
    const contactValue = sanitizeText(req.body.contactValue, 160).toLowerCase();

    if (!orderCode || !contactValue) {
      res.status(400).json({
        error: 'Missing fields',
        messageAr: 'يرجى إدخال رقم الطلب وبيانات التواصل المستخدمة عند تقديم الطلب للتحقق من هويتك.',
      });
      return;
    }

    const order = queryOne<Record<string, unknown>>(
      `SELECT id, order_code, client_name, contact_method, service_title_snapshot,
              package_title_snapshot, budget, deadline, status, client_visible_note,
              created_at, updated_at, contact_value
       FROM orders
       WHERE upper(order_code) = ?`,
      [orderCode]
    );

    if (!order || String(order.contact_value).trim().toLowerCase() !== contactValue) {
      res.status(404).json({
        error: 'Order not found or contact mismatch',
        messageAr: 'لم يتم العثور على طلب مطابق لرقم الطلب وبيانات التواصل المدخلة.',
      });
      return;
    }

    const history = queryAll<{ status: string; note: string; created_at: string }>(
      'SELECT status, note, created_at FROM order_status_history WHERE order_id = ? ORDER BY id ASC',
      [Number(order.id)]
    );

    const attachments = queryAll<{ original_name: string; size_bytes: number }>(
      'SELECT original_name, size_bytes FROM order_attachments WHERE order_id = ?',
      [Number(order.id)]
    );

    res.json({
      orderCode: order.order_code,
      clientName: order.client_name,
      contactMethod: order.contact_method,
      serviceTitle: order.service_title_snapshot,
      packageTitle: order.package_title_snapshot,
      budget: order.budget,
      deadline: order.deadline,
      status: order.status,
      clientNote: order.client_visible_note,
      createdAt: order.created_at,
      updatedAt: order.updated_at,
      history,
      attachments,
    });
  });

  // Public contact message submission
  app.post('/api/contact', (req, res) => {
    const name = sanitizeText(req.body.name, 120);
    const contact = sanitizeText(req.body.contact, 160);
    const subject = sanitizeText(req.body.subject, 160);
    const message = sanitizeText(req.body.message, 3000);

    if (!name || !contact || !message || message.length < 5) {
      res.status(400).json({
        error: 'Invalid contact payload',
        messageAr: 'يرجى تعبئة الاسم ووسيلة التواصل والرسالة بشكل صحيح.',
      });
      return;
    }

    runExec(
      'INSERT INTO contact_messages (name, contact, subject, message) VALUES (?, ?, ?, ?)',
      [name, contact, subject || 'استفسار عام', message]
    );

    res.status(201).json({ ok: true });
  });

  // ================= ADMIN AUTH =================
  app.post('/api/admin/login', (req, res) => {
    if (!loginLimiter(getClientIp(req))) {
      res.status(429).json({
        error: 'Too many login attempts',
        messageAr: 'تم تجاوز عدد محاولات تسجيل الدخول المسموحة. يرجى الانتظار 15 دقيقة.',
      });
      return;
    }

    const emailOrUser = sanitizeText(req.body.email, 160).toLowerCase();
    const password = typeof req.body.password === 'string' ? req.body.password : '';

    if (!emailOrUser || !password) {
      res.status(400).json({
        error: 'Credentials required',
        messageAr: 'يرجى إدخال البريد الإلكتروني وكلمة المرور.',
      });
      return;
    }

    const admin = queryOne<{
      id: number;
      username: string;
      email: string;
      password_hash: string;
      salt: string;
      role: string;
    }>(
      'SELECT id, username, email, password_hash, salt, role FROM admins WHERE lower(email) = ? OR lower(username) = ?',
      [emailOrUser, emailOrUser]
    );

    if (!admin || !verifyPassword(password, admin.password_hash, admin.salt)) {
      res.status(401).json({
        error: 'Invalid credentials',
        messageAr: 'بيانات الدخول غير صحيحة.',
      });
      return;
    }

    const token = signSessionToken({
      adminId: admin.id,
      email: admin.email,
      username: admin.username,
      role: admin.role,
      exp: Date.now() + 24 * 60 * 60 * 1000,
    });

    res.cookie('vortex_admin_session', token, {
      httpOnly: true,
      sameSite: 'lax',
      secure: isProd && req.protocol === 'https',
      maxAge: 24 * 60 * 60 * 1000,
      path: '/',
    });

    res.json({
      admin: {
        id: admin.id,
        username: admin.username,
        email: admin.email,
        role: admin.role,
      },
    });
  });

  app.post('/api/admin/logout', (req, res) => {
    res.clearCookie('vortex_admin_session', {
      path: '/',
      httpOnly: true,
      sameSite: 'lax',
      secure: isProd && req.protocol === 'https',
    });
    res.json({ ok: true });
  });

  app.get('/api/admin/me', requireAdmin, (req: AuthedRequest, res) => {
    res.json({ admin: req.admin });
  });

  app.post('/api/admin/change-password', requireAdmin, (req: AuthedRequest, res) => {
    const currentPassword = typeof req.body.currentPassword === 'string' ? req.body.currentPassword : '';
    const newPassword = typeof req.body.newPassword === 'string' ? req.body.newPassword : '';
    if (newPassword.length < 8) {
      res.status(400).json({
        error: 'Weak password',
        messageAr: 'كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل.',
      });
      return;
    }

    const admin = queryOne<{ id: number; password_hash: string; salt: string }>(
      'SELECT id, password_hash, salt FROM admins WHERE id = ?',
      [req.admin!.adminId]
    );
    if (!admin || !verifyPassword(currentPassword, admin.password_hash, admin.salt)) {
      res.status(400).json({
        error: 'Incorrect current password',
        messageAr: 'كلمة المرور الحالية غير صحيحة.',
      });
      return;
    }

    const { hash, salt } = hashPassword(newPassword);
    runExec('UPDATE admins SET password_hash = ?, salt = ? WHERE id = ?', [hash, salt, admin.id]);
    runExec(
      `INSERT INTO site_settings (key, value_ar, value_en, updated_at)
       VALUES ('admin_password_overridden', '1', '1', datetime('now'))
       ON CONFLICT(key) DO UPDATE SET value_ar = '1', value_en = '1', updated_at = datetime('now')`
    );
    res.json({ ok: true });
  });

  // ================= ADMIN DASHBOARD API =================
  app.get('/api/admin/stats', requireAdmin, (_req, res) => {
    const totalClients = queryOne<{ c: number }>('SELECT COUNT(*) AS c FROM clients')?.c ?? 0;
    const totalOrders = queryOne<{ c: number }>('SELECT COUNT(*) AS c FROM orders')?.c ?? 0;
    const newOrders = queryOne<{ c: number }>("SELECT COUNT(*) AS c FROM orders WHERE status = 'received'")?.c ?? 0;
    const reviewingOrders = queryOne<{ c: number }>("SELECT COUNT(*) AS c FROM orders WHERE status = 'reviewing'")?.c ?? 0;
    const awaitingApprovalOrders = queryOne<{ c: number }>("SELECT COUNT(*) AS c FROM orders WHERE status = 'awaiting_approval'")?.c ?? 0;
    const inProgressOrders = queryOne<{ c: number }>("SELECT COUNT(*) AS c FROM orders WHERE status = 'in_progress'")?.c ?? 0;
    const completedOrders = queryOne<{ c: number }>("SELECT COUNT(*) AS c FROM orders WHERE status = 'completed'")?.c ?? 0;
    const rejectedOrders = queryOne<{ c: number }>("SELECT COUNT(*) AS c FROM orders WHERE status = 'rejected'")?.c ?? 0;
    const unreadMessages = queryOne<{ c: number }>('SELECT COUNT(*) AS c FROM contact_messages WHERE is_read = 0')?.c ?? 0;

    res.json({
      totalClients,
      totalOrders,
      newOrders,
      reviewingOrders,
      awaitingApprovalOrders,
      inProgressOrders,
      completedOrders,
      rejectedOrders,
      unreadMessages,
    });
  });

  app.get('/api/admin/orders', requireAdmin, (req, res) => {
    const search = sanitizeText(req.query.search, 120).toLowerCase();
    const status = sanitizeText(req.query.status, 40);

    let sql = 'SELECT * FROM orders WHERE 1=1';
    const params: (string | number)[] = [];

    if (status && status !== 'all' && ALLOWED_STATUSES.includes(status as OrderStatus)) {
      sql += ' AND status = ?';
      params.push(status);
    }
    if (search) {
      sql += ' AND (lower(order_code) LIKE ? OR lower(client_name) LIKE ? OR lower(contact_value) LIKE ? OR lower(service_title_snapshot) LIKE ?)';
      const like = `%${search}%`;
      params.push(like, like, like, like);
    }
    sql += ' ORDER BY id DESC';

    const orders = queryAll<Record<string, unknown>>(sql, params);
    const enriched = orders.map((o) => {
      const attachments = queryAll(
        'SELECT id, original_name, mime_type, size_bytes, created_at FROM order_attachments WHERE order_id = ?',
        [Number(o.id)]
      );
      return { ...o, attachments };
    });

    res.json({ orders: enriched });
  });

  app.get('/api/admin/orders/:id', requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) {
      res.status(400).json({ error: 'Invalid ID' });
      return;
    }
    const order = queryOne<Record<string, unknown>>('SELECT * FROM orders WHERE id = ?', [id]);
    if (!order) {
      res.status(404).json({ error: 'Order not found' });
      return;
    }
    const attachments = queryAll(
      'SELECT id, original_name, mime_type, size_bytes, created_at FROM order_attachments WHERE order_id = ?',
      [id]
    );
    const history = queryAll(
      'SELECT * FROM order_status_history WHERE order_id = ? ORDER BY id ASC',
      [id]
    );
    res.json({ order, attachments, history });
  });

  app.patch('/api/admin/orders/:id', requireAdmin, (req: AuthedRequest, res) => {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) {
      res.status(400).json({ error: 'Invalid ID' });
      return;
    }
    const existing = queryOne<{ id: number; status: string }>('SELECT id, status FROM orders WHERE id = ?', [id]);
    if (!existing) {
      res.status(404).json({ error: 'Order not found' });
      return;
    }

    const nextStatus = sanitizeText(req.body.status, 40) as OrderStatus;
    if (!ALLOWED_STATUSES.includes(nextStatus)) {
      res.status(400).json({ error: 'Invalid status' });
      return;
    }

    const adminNotes = sanitizeText(req.body.adminNotes, 4000);
    const clientVisibleNote = sanitizeText(req.body.clientVisibleNote, 2000);

    runExec(
      `UPDATE orders
       SET status = ?, admin_notes = ?, client_visible_note = ?, updated_at = datetime('now')
       WHERE id = ?`,
      [nextStatus, adminNotes, clientVisibleNote, id]
    );

    if (existing.status !== nextStatus || clientVisibleNote) {
      runExec(
        'INSERT INTO order_status_history (order_id, status, note, changed_by) VALUES (?, ?, ?, ?)',
        [id, nextStatus, clientVisibleNote || `تم تحديث حالة الطلب إلى: ${nextStatus}`, req.admin!.email]
      );
    }

    res.json({ ok: true });
  });

  app.delete('/api/admin/orders/:id', requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) {
      res.status(400).json({ error: 'Invalid ID' });
      return;
    }
    const attachments = queryAll<{ stored_name: string }>(
      'SELECT stored_name FROM order_attachments WHERE order_id = ?',
      [id]
    );
    for (const att of attachments) {
      const target = path.join(uploadsDir, path.basename(att.stored_name));
      if (fs.existsSync(target)) {
        try {
          fs.unlinkSync(target);
        } catch {
          // ignore cleanup failure
        }
      }
    }
    runExec('DELETE FROM orders WHERE id = ?', [id]);
    res.json({ ok: true });
  });

  app.get('/api/admin/attachments/:id/download', requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) {
      res.status(400).json({ error: 'Invalid attachment ID' });
      return;
    }
    const att = queryOne<{ original_name: string; stored_name: string }>(
      'SELECT original_name, stored_name FROM order_attachments WHERE id = ?',
      [id]
    );
    if (!att) {
      res.status(404).json({ error: 'Attachment not found' });
      return;
    }
    const safeFile = path.basename(att.stored_name);
    const fullPath = path.join(uploadsDir, safeFile);
    if (!fs.existsSync(fullPath)) {
      res.status(404).json({ error: 'File missing on disk' });
      return;
    }
    res.download(fullPath, att.original_name);
  });

  // Clients management
  app.get('/api/admin/clients', requireAdmin, (_req, res) => {
    const clients = queryAll(
      `SELECT c.*,
              COUNT(o.id) AS orders_count,
              MAX(o.created_at) AS last_order_at
       FROM clients c
       LEFT JOIN orders o ON o.client_id = c.id
       GROUP BY c.id
       ORDER BY c.id DESC`
    );
    res.json({ clients });
  });

  app.patch('/api/admin/clients/:id', requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) {
      res.status(400).json({ error: 'Invalid client ID' });
      return;
    }
    const notes = sanitizeText(req.body.notes, 2000);
    runExec('UPDATE clients SET notes = ? WHERE id = ?', [notes, id]);
    res.json({ ok: true });
  });

  // Services & Price List management
  app.get('/api/admin/services', requireAdmin, (_req, res) => {
    const rows = queryAll<Record<string, unknown>>(
      'SELECT * FROM services ORDER BY sort_order ASC, id ASC'
    );
    const services = rows.map((s) => ({
      ...s,
      features_ar: parseJsonArray(s.features_ar),
      features_en: parseJsonArray(s.features_en),
      show_in_pricelist: Boolean(s.show_in_pricelist),
      is_active: Boolean(s.is_active),
    }));
    res.json({ services });
  });

  app.post('/api/admin/services', requireAdmin, (req, res) => {
    const titleAr = sanitizeText(req.body.title_ar, 160);
    const titleEn = sanitizeText(req.body.title_en, 160);
    const categoryKey = sanitizeText(req.body.category_key, 60) || 'design-identity';
    const slugRaw = sanitizeText(req.body.slug, 100) || `service-${Date.now()}`;
    const slug = slugRaw.toLowerCase().replace(/[^a-z0-9-]+/g, '-');
    const startingPrice =
      req.body.starting_price === '' || req.body.starting_price === null || req.body.starting_price === undefined
        ? null
        : Number(req.body.starting_price);

    if (!titleAr || !titleEn) {
      res.status(400).json({ error: 'Titles required' });
      return;
    }

    const priceLabelAr = sanitizeText(req.body.price_label_ar, 80) || (startingPrice !== null ? `يبدأ من $${startingPrice}` : 'حسب المشروع');
    const priceLabelEn = sanitizeText(req.body.price_label_en, 80) || (startingPrice !== null ? `Starts at $${startingPrice}` : 'Custom Quote');

    const id = runExec(
      `INSERT INTO services (
        slug, category_key, title_ar, title_en, short_desc_ar, short_desc_en,
        full_desc_ar, full_desc_en, features_ar, features_en,
        starting_price, price_label_ar, price_label_en, show_in_pricelist, is_active, sort_order, image_url
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        slug,
        categoryKey,
        titleAr,
        titleEn,
        sanitizeText(req.body.short_desc_ar, 400),
        sanitizeText(req.body.short_desc_en, 400),
        sanitizeText(req.body.full_desc_ar, 2000),
        sanitizeText(req.body.full_desc_en, 2000),
        JSON.stringify(Array.isArray(req.body.features_ar) ? req.body.features_ar : []),
        JSON.stringify(Array.isArray(req.body.features_en) ? req.body.features_en : []),
        Number.isFinite(startingPrice as number) ? startingPrice : null,
        priceLabelAr,
        priceLabelEn,
        req.body.show_in_pricelist ? 1 : 0,
        req.body.is_active === false ? 0 : 1,
        Number(req.body.sort_order || 99),
        sanitizeText(req.body.image_url, 300) || '/src/assets/images/service_web_engineering_1794765377359.jpg',
      ]
    );
    res.status(201).json({ id });
  });

  app.put('/api/admin/services/:id', requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) {
      res.status(400).json({ error: 'Invalid service ID' });
      return;
    }

    const startingPrice =
      req.body.starting_price === '' || req.body.starting_price === null || req.body.starting_price === undefined
        ? null
        : Number(req.body.starting_price);

    runExec(
      `UPDATE services SET
        category_key = ?,
        title_ar = ?,
        title_en = ?,
        short_desc_ar = ?,
        short_desc_en = ?,
        full_desc_ar = ?,
        full_desc_en = ?,
        features_ar = ?,
        features_en = ?,
        starting_price = ?,
        price_label_ar = ?,
        price_label_en = ?,
        show_in_pricelist = ?,
        is_active = ?,
        sort_order = ?
      WHERE id = ?`,
      [
        sanitizeText(req.body.category_key, 60),
        sanitizeText(req.body.title_ar, 160),
        sanitizeText(req.body.title_en, 160),
        sanitizeText(req.body.short_desc_ar, 400),
        sanitizeText(req.body.short_desc_en, 400),
        sanitizeText(req.body.full_desc_ar, 2000),
        sanitizeText(req.body.full_desc_en, 2000),
        JSON.stringify(Array.isArray(req.body.features_ar) ? req.body.features_ar : []),
        JSON.stringify(Array.isArray(req.body.features_en) ? req.body.features_en : []),
        Number.isFinite(startingPrice as number) ? startingPrice : null,
        sanitizeText(req.body.price_label_ar, 80),
        sanitizeText(req.body.price_label_en, 80),
        req.body.show_in_pricelist ? 1 : 0,
        req.body.is_active ? 1 : 0,
        Number(req.body.sort_order || 0),
        id,
      ]
    );
    res.json({ ok: true });
  });

  app.delete('/api/admin/services/:id', requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) {
      res.status(400).json({ error: 'Invalid ID' });
      return;
    }
    runExec('DELETE FROM services WHERE id = ?', [id]);
    res.json({ ok: true });
  });

  // Packages management
  app.get('/api/admin/packages', requireAdmin, (_req, res) => {
    const rows = queryAll<Record<string, unknown>>(
      'SELECT * FROM packages ORDER BY sort_order ASC, id ASC'
    );
    const packages = rows.map((p) => ({
      ...p,
      features_ar: parseJsonArray(p.features_ar),
      features_en: parseJsonArray(p.features_en),
      is_featured: Boolean(p.is_featured),
      is_active: Boolean(p.is_active),
    }));
    res.json({ packages });
  });

  app.put('/api/admin/packages/:id', requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) {
      res.status(400).json({ error: 'Invalid package ID' });
      return;
    }
    runExec(
      `UPDATE packages SET
        name_ar = ?,
        name_en = ?,
        subtitle_ar = ?,
        subtitle_en = ?,
        price_display_ar = ?,
        price_display_en = ?,
        features_ar = ?,
        features_en = ?,
        is_featured = ?,
        is_active = ?
      WHERE id = ?`,
      [
        sanitizeText(req.body.name_ar, 120),
        sanitizeText(req.body.name_en, 120),
        sanitizeText(req.body.subtitle_ar, 300),
        sanitizeText(req.body.subtitle_en, 300),
        sanitizeText(req.body.price_display_ar, 120),
        sanitizeText(req.body.price_display_en, 120),
        JSON.stringify(Array.isArray(req.body.features_ar) ? req.body.features_ar : []),
        JSON.stringify(Array.isArray(req.body.features_en) ? req.body.features_en : []),
        req.body.is_featured ? 1 : 0,
        req.body.is_active ? 1 : 0,
        id,
      ]
    );
    res.json({ ok: true });
  });

  // Site CMS settings management
  app.put('/api/admin/settings', requireAdmin, (req, res) => {
    const entries = req.body.settings as Record<string, { ar: string; en: string }> | undefined;
    if (!entries || typeof entries !== 'object') {
      res.status(400).json({ error: 'Invalid settings payload' });
      return;
    }
    for (const [key, val] of Object.entries(entries)) {
      const safeKey = sanitizeText(key, 80);
      if (!safeKey || !val) continue;
      runExec(
        `INSERT INTO site_settings (key, value_ar, value_en, updated_at)
         VALUES (?, ?, ?, datetime('now'))
         ON CONFLICT(key) DO UPDATE SET
           value_ar = excluded.value_ar,
           value_en = excluded.value_en,
           updated_at = datetime('now')`,
        [safeKey, sanitizeText(val.ar, 2000), sanitizeText(val.en, 2000)]
      );
    }
    res.json({ ok: true });
  });

  // Contact messages management
  app.get('/api/admin/messages', requireAdmin, (_req, res) => {
    const messages = queryAll('SELECT * FROM contact_messages ORDER BY id DESC');
    res.json({ messages });
  });

  app.patch('/api/admin/messages/:id/read', requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) {
      res.status(400).json({ error: 'Invalid message ID' });
      return;
    }
    runExec('UPDATE contact_messages SET is_read = 1 WHERE id = ?', [id]);
    res.json({ ok: true });
  });

  // Export clean downloadable ZIP archive of the project source files (Admin only)
  app.get('/api/admin/export-zip', requireAdmin, async (_req, res) => {
    try {
      const zip = new JSZip();
      const rootDir = process.cwd();
      const ignoreSet = new Set([
        'node_modules',
        'dist',
        'data',
        'uploads',
        '.git',
        '.env',
        '.vortex-secret',
      ]);

      function addDirToZip(currentDir: string, zipFolder: JSZip) {
        const items = fs.readdirSync(currentDir, { withFileTypes: true });
        for (const item of items) {
          if (ignoreSet.has(item.name) || item.name.endsWith('.db')) continue;
          const fullPath = path.join(currentDir, item.name);
          if (item.isDirectory()) {
            const sub = zipFolder.folder(item.name);
            if (sub) addDirToZip(fullPath, sub);
          } else {
            zipFolder.file(item.name, fs.readFileSync(fullPath));
          }
        }
      }

      addDirToZip(rootDir, zip);
      const buffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="vortex-digital-project.zip"');
      res.send(buffer);
    } catch {
      res.status(500).json({ error: 'Failed to export project archive' });
    }
  });

  // Serve Vite or production static files
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[VORTEX DIGITAL] Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start VORTEX DIGITAL server:', err);
  process.exit(1);
});
