import fs from 'node:fs';
import path from 'node:path';
import initSqlJs, { type Database, type SqlValue } from 'sql.js';
import { hashPassword } from './security.ts';

let dbInstance: Database | null = null;
let dbFilePath = '';

function resolveDbPath(): string {
  const configured = process.env.DATABASE_PATH?.trim();
  if (configured) {
    return path.resolve(process.cwd(), configured);
  }
  return path.resolve(process.cwd(), 'data', 'vortex.db');
}

export function saveDatabase(): void {
  if (!dbInstance || !dbFilePath) return;
  const dir = path.dirname(dbFilePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  const binary = dbInstance.export();
  fs.writeFileSync(dbFilePath, Buffer.from(binary));
}

export function queryAll<T = Record<string, unknown>>(sql: string, params: SqlValue[] = []): T[] {
  if (!dbInstance) throw new Error('Database not initialized');
  const stmt = dbInstance.prepare(sql);
  stmt.bind(params);
  const rows: T[] = [];
  while (stmt.step()) {
    rows.push(stmt.getAsObject() as T);
  }
  stmt.free();
  return rows;
}

export function queryOne<T = Record<string, unknown>>(sql: string, params: SqlValue[] = []): T | null {
  const rows = queryAll<T>(sql, params);
  return rows.length > 0 ? rows[0] : null;
}

export function runExec(sql: string, params: SqlValue[] = []): number {
  if (!dbInstance) throw new Error('Database not initialized');
  const stmt = dbInstance.prepare(sql);
  stmt.bind(params);
  stmt.step();
  stmt.free();
  const idRow = queryOne<{ id: number }>('SELECT last_insert_rowid() AS id');
  saveDatabase();
  return idRow?.id ?? 0;
}

export async function initDatabase(): Promise<Database> {
  if (dbInstance) return dbInstance;

  dbFilePath = resolveDbPath();
  const dir = path.dirname(dbFilePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  const SQL = await initSqlJs({
    locateFile: (file: string) => path.resolve(process.cwd(), 'node_modules/sql.js/dist', file),
  });

  if (fs.existsSync(dbFilePath)) {
    const fileBuffer = fs.readFileSync(dbFilePath);
    dbInstance = new SQL.Database(fileBuffer);
  } else {
    dbInstance = new SQL.Database();
  }

  dbInstance.run('PRAGMA foreign_keys = ON;');

  dbInstance.run(`
    CREATE TABLE IF NOT EXISTS admins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      salt TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'super_admin',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS clients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      contact_method TEXT NOT NULL,
      contact_value TEXT NOT NULL UNIQUE,
      notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS services (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      slug TEXT NOT NULL UNIQUE,
      category_key TEXT NOT NULL,
      title_ar TEXT NOT NULL,
      title_en TEXT NOT NULL,
      short_desc_ar TEXT NOT NULL,
      short_desc_en TEXT NOT NULL,
      full_desc_ar TEXT NOT NULL,
      full_desc_en TEXT NOT NULL,
      features_ar TEXT NOT NULL DEFAULT '[]',
      features_en TEXT NOT NULL DEFAULT '[]',
      starting_price REAL,
      price_label_ar TEXT NOT NULL,
      price_label_en TEXT NOT NULL,
      show_in_pricelist INTEGER NOT NULL DEFAULT 1,
      is_active INTEGER NOT NULL DEFAULT 1,
      sort_order INTEGER NOT NULL DEFAULT 0,
      image_url TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS packages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      slug TEXT NOT NULL UNIQUE,
      name_ar TEXT NOT NULL,
      name_en TEXT NOT NULL,
      subtitle_ar TEXT NOT NULL,
      subtitle_en TEXT NOT NULL,
      price_display_ar TEXT NOT NULL,
      price_display_en TEXT NOT NULL,
      features_ar TEXT NOT NULL DEFAULT '[]',
      features_en TEXT NOT NULL DEFAULT '[]',
      is_featured INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      sort_order INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_code TEXT NOT NULL UNIQUE,
      client_id INTEGER REFERENCES clients(id) ON DELETE SET NULL,
      client_name TEXT NOT NULL,
      contact_method TEXT NOT NULL,
      contact_value TEXT NOT NULL,
      service_id INTEGER REFERENCES services(id) ON DELETE SET NULL,
      service_title_snapshot TEXT NOT NULL,
      package_id INTEGER REFERENCES packages(id) ON DELETE SET NULL,
      package_title_snapshot TEXT NOT NULL DEFAULT '',
      project_description TEXT NOT NULL,
      budget TEXT NOT NULL,
      deadline TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'received',
      admin_notes TEXT NOT NULL DEFAULT '',
      client_visible_note TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS order_attachments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      original_name TEXT NOT NULL,
      stored_name TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      size_bytes INTEGER NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS order_status_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      status TEXT NOT NULL,
      note TEXT NOT NULL DEFAULT '',
      changed_by TEXT NOT NULL DEFAULT 'system',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS contact_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      contact TEXT NOT NULL,
      subject TEXT NOT NULL,
      message TEXT NOT NULL,
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS site_settings (
      key TEXT PRIMARY KEY,
      value_ar TEXT NOT NULL,
      value_en TEXT NOT NULL,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  seedInitialData();
  saveDatabase();
  return dbInstance;
}

function seedInitialData(): void {
  const envAdminEmail = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  const envAdminPass = process.env.ADMIN_PASSWORD?.trim();
  const adminCount = queryOne<{ c: number }>('SELECT COUNT(*) AS c FROM admins');
  const overridden = queryOne<{ value_ar: string }>(
    "SELECT value_ar FROM site_settings WHERE key = 'admin_password_overridden'"
  );

  if (!adminCount || adminCount.c === 0) {
    const adminEmail = envAdminEmail || 'admin@vortexdigital.agency';
    const adminPass = envAdminPass || 'VortexAdmin#2026';
    const { hash, salt } = hashPassword(adminPass);
    runExec(
      'INSERT INTO admins (username, email, password_hash, salt, role) VALUES (?, ?, ?, ?, ?)',
      ['vortex_admin', adminEmail, hash, salt, 'super_admin']
    );
    console.log(`[VORTEX DB] Seeded admin account: ${adminEmail}`);
  } else if (
    (envAdminEmail || envAdminPass) &&
    overridden?.value_ar !== '1'
  ) {
    const existingAdmin = queryOne<{ id: number; email: string }>(
      'SELECT id, email FROM admins ORDER BY id ASC LIMIT 1'
    );
    if (existingAdmin) {
      const targetEmail = envAdminEmail || existingAdmin.email;
      if (envAdminPass) {
        const { hash, salt } = hashPassword(envAdminPass);
        runExec('UPDATE admins SET email = ?, password_hash = ?, salt = ? WHERE id = ?', [
          targetEmail,
          hash,
          salt,
          existingAdmin.id,
        ]);
      } else if (envAdminEmail && envAdminEmail !== existingAdmin.email) {
        runExec('UPDATE admins SET email = ? WHERE id = ?', [targetEmail, existingAdmin.id]);
      }
    }
  }

  const serviceCount = queryOne<{ c: number }>('SELECT COUNT(*) AS c FROM services');
  if (!serviceCount || serviceCount.c === 0) {
    const initialServices = [
      {
        slug: 'logo-design',
        category_key: 'design-identity',
        title_ar: 'تصميم شعار احترافي',
        title_en: 'Professional Logo Design',
        short_desc_ar: 'شعارات هندسية مبتكرة تعكس قوة وهوية علامتك التجارية بدقة عالية.',
        short_desc_en: 'Geometric, memorable logos engineered to represent your brand identity with precision.',
        full_desc_ar: 'نصمم شعارات أصلية مدروسة هندسياً لتناسب المنصات الرقمية والمطبوعات، مع تسليم الملفات المصدرية كاملة بجودة فائقة وتدرجات احترافية.',
        full_desc_en: 'We craft bespoke, geometrically balanced logos ready for digital and print use, delivered with full vector source files and brand usage guidance.',
        features_ar: JSON.stringify(['تصميم مخصص 100% بدون قوالب جاهزة', 'تسليم ملفات PNG شفافة و SVG و PDF', 'مقترحات أولية وتعديلات مرنة', 'نسخ فاتحة وداكنة للشعار']),
        features_en: JSON.stringify(['100% custom vector craftsmanship', 'Transparent PNG, SVG, and PDF files', 'Initial concepts with flexible revisions', 'Light and dark monochrome variants']),
        starting_price: 5,
        price_label_ar: 'يبدأ من $5',
        price_label_en: 'Starts at $5',
        show_in_pricelist: 1,
        sort_order: 1,
        image_url: '/src/assets/images/service_brand_identity_1794765376372.jpg',
      },
      {
        slug: 'brand-identity',
        category_key: 'design-identity',
        title_ar: 'هوية بصرية متكاملة',
        title_en: 'Complete Visual Brand Identity',
        short_desc_ar: 'بناء هوية تجارية متسقة تشمل الألوان والخطوط والقرطاسية ودليل الاستخدام.',
        short_desc_en: 'Cohesive brand systems covering typography, color architecture, stationery, and guidelines.',
        full_desc_ar: 'نحوّل فكرتك إلى علامة تجارية متكاملة لها حضور بصري مميز، بدءاً من الشعار ونظام الألوان المعدنية والخطوط، وصولاً إلى قوالب العرض والملفات التجارية.',
        full_desc_en: 'We build a unified brand system from logo geometry and color palette to typography rules, social kits, and brand guidelines.',
        features_ar: JSON.stringify(['الشعار الرئيسي والفرعي', 'لوحة الألوان والخطوط المعتمدة', 'تصميم البطاقات والملفات التعريفية', 'دليل الهوية البصرية الكامل PDF']),
        features_en: JSON.stringify(['Primary & secondary logo lockups', 'Curated color & typography system', 'Business cards & brand stationery', 'Comprehensive PDF brand guidelines']),
        starting_price: 15,
        price_label_ar: 'تبدأ من $15',
        price_label_en: 'Starts at $15',
        show_in_pricelist: 1,
        sort_order: 2,
        image_url: '/src/assets/images/service_brand_identity_1794765376372.jpg',
      },
      {
        slug: 'banner-cover-design',
        category_key: 'design-identity',
        title_ar: 'تصميم بنر أو غلاف',
        title_en: 'Banner & Cover Design',
        short_desc_ar: 'أغلفة احترافية لمنصات Discord ويوتيوب وتويتر والمنصات التجارية.',
        short_desc_en: 'High-impact banners and covers for Discord, YouTube, X, and commercial storefronts.',
        full_desc_ar: 'تصاميم أغلفة وبنرات إعلانية بمقاسات دقيقة ومظهر تقني فاخر يجذب الانتباه فوراً ويعزز احترافية حسابك أو خادمك.',
        full_desc_en: 'Precision-sized banners and headers crafted with clean contrast, sharp composition, and dark-luxury aesthetics.',
        features_ar: JSON.stringify(['مقاسات متوافقة مع جميع الشاشات', 'تصاميم Discord و X و YouTube', 'تباين لوني وإضاءة سينمائية', 'تسليم فوري بجودة عالية']),
        features_en: JSON.stringify(['Exact platform-ready dimensions', 'Discord, X, YouTube & Storefront banners', 'Balanced contrast and studio lighting', 'High-resolution final export']),
        starting_price: 3,
        price_label_ar: 'يبدأ من $3',
        price_label_en: 'Starts at $3',
        show_in_pricelist: 1,
        sort_order: 3,
        image_url: '/src/assets/images/service_brand_identity_1794765376372.jpg',
      },
      {
        slug: 'social-posts-design',
        category_key: 'content-social',
        title_ar: 'تصاميم منشورات السوشيال ميديا',
        title_en: 'Social Media Post Designs',
        short_desc_ar: 'تصاميم إعلانية ومنشورات متسقة بصرياً لزيادة التفاعل وبناء الثقة.',
        short_desc_en: 'Cohesive social graphics and ad creatives engineered for clarity and engagement.',
        full_desc_ar: 'نصمم منشورات احترافية وإعلانات رقمية متوافقة مع هوية علامتك التجارية، مع صياغة بصرية تبرز الرسالة التسويقية بوضوح.',
        full_desc_en: 'We produce crisp social media campaigns, carousel posts, and ad banners tailored to your brand system.',
        features_ar: JSON.stringify(['تصاميم إعلانات ومنشورات تفاعلية', 'توافق تام مع مقاسات إنستغرام وإكس', 'خطوط عربية واضحة وتنسيق متوازن', 'إمكانية طلب باقات شهرية']),
        features_en: JSON.stringify(['Interactive carousels & ad creatives', 'Instagram, X & LinkedIn aspect ratios', 'Clean bilingual typographic hierarchy', 'Flexible batch & monthly packages']),
        starting_price: 5,
        price_label_ar: 'يبدأ من $5',
        price_label_en: 'Starts at $5',
        show_in_pricelist: 1,
        sort_order: 4,
        image_url: '/src/assets/images/service_brand_identity_1794765376372.jpg',
      },
      {
        slug: 'discord-server-design',
        category_key: 'design-identity',
        title_ar: 'تصميم وتجهيز سيرفر Discord',
        title_en: 'Discord Server Design & Setup',
        short_desc_ar: 'هيكلة القنوات والرتب والبوتات والأغلفة بأسلوب احترافي ومنظم.',
        short_desc_en: 'Complete Discord architecture with roles, permissions, bots, and custom visual assets.',
        full_desc_ar: 'نجهز سيرفر Discord متكاملاً من الصفر: تصميم الهيكلة، إعداد الصلاحيات والأمان، تنظيم الرومز والتذاكر، وإضافة البنرات والأيقونات الخاصة بالسيرفر.',
        full_desc_en: 'End-to-end Discord community engineering: channel taxonomy, role permission matrices, ticket/moderation bots, and matching visual assets.',
        features_ar: JSON.stringify(['تنظيم القنوات والأقسام باحترافية', 'إعداد الرتب والصلاحيات الآمنة', 'تكوين البوتات ونظام التذاكر', 'بنرات وأيقونات مخصصة للسيرفر']),
        features_en: JSON.stringify(['Structured channels and category hierarchy', 'Secure role & permission configuration', 'Automated moderation & ticket workflows', 'Matching server banners and icons']),
        starting_price: 10,
        price_label_ar: 'يبدأ من $10',
        price_label_en: 'Starts at $10',
        show_in_pricelist: 1,
        sort_order: 5,
        image_url: '/src/assets/images/service_digital_systems_1794765376079.jpg',
      },
      {
        slug: 'portfolio-website',
        category_key: 'web-design',
        title_ar: 'موقع تعريفي أو شركة',
        title_en: 'Portfolio & Corporate Website',
        short_desc_ar: 'مواقع تعريفية فاخرة للشركات والأفراد تعكس الثقة وتعمل بسرعة على كل الأجهزة.',
        short_desc_en: 'Refined corporate and portfolio websites built for clarity, speed, and mobile responsiveness.',
        full_desc_ar: 'تصميم وتنفيذ موقع تعريفي احترافي يعرض خدماتك وأعمالك بأسلوب عصري متجاوب مع الهواتف والأجهزة اللوحية والحواسيب مع تهيئة لمحركات البحث.',
        full_desc_en: 'Modern responsive corporate or portfolio websites featuring clean navigation, fast load performance, and search-ready structure.',
        features_ar: JSON.stringify(['تصميم متجاوب مع Android و iPhone والكمبيوتر', 'دعم اللغة العربية RTL والإنجليزية', 'نموذج تواصل وربط مباشر بالديسكورد', 'سرعة عالية وأداء محسن']),
        features_en: JSON.stringify(['Responsive on Android, iOS & Desktop', 'Arabic RTL & English LTR ready', 'Lead capture forms & Discord links', 'Fast performance & clean SEO markup']),
        starting_price: 25,
        price_label_ar: 'يبدأ من $25',
        price_label_en: 'Starts at $25',
        show_in_pricelist: 1,
        sort_order: 6,
        image_url: '/src/assets/images/service_web_engineering_1794765377359.jpg',
      },
      {
        slug: 'landing-page',
        category_key: 'web-design',
        title_ar: 'صفحة هبوط تحويلية',
        title_en: 'High-Converting Landing Page',
        short_desc_ar: 'صفحات هبوط مصممة لإطلاق المنتجات والخدمات وتحويل الزوار إلى عملاء.',
        short_desc_en: 'Focused landing pages designed for product launches and direct client conversion.',
        full_desc_ar: 'صفحة هبوط مركزة بتسلسل بصري مدروس يبرز قيمة العرض التجاري ويوجه الزائر مباشرة لاتخاذ قرار الشراء أو طلب الخدمة.',
        full_desc_en: 'Precision-structured landing pages designed to communicate value clearly and convert visitors into qualified inquiries.',
        features_ar: JSON.stringify(['هيكلة إقناعية تركز على التحويل', 'أزرار دعوة لاتخاذ إجراء واضحة', 'حركات وانتقالات خفيفة وسريعة', 'متوافقة تماماً مع الجوال']),
        features_en: JSON.stringify(['Conversion-focused visual hierarchy', 'Clear primary call-to-action flows', 'Smooth, lightweight motion', 'Mobile-first responsive layout']),
        starting_price: 15,
        price_label_ar: 'يبدأ من $15',
        price_label_en: 'Starts at $15',
        show_in_pricelist: 1,
        sort_order: 7,
        image_url: '/src/assets/images/service_web_engineering_1794765377359.jpg',
      },
      {
        slug: 'custom-web-dev',
        category_key: 'programming-solutions',
        title_ar: 'برمجة موقع مخصص أو متجر',
        title_en: 'Custom Web & E-Commerce Development',
        short_desc_ar: 'تطوير مواقع وتطبيقات ويب مخصصة بقاعدة بيانات ولوحة تحكم حقيقية.',
        short_desc_en: 'Full-stack custom web platforms and stores with real databases and admin dashboards.',
        full_desc_ar: 'برمجة مواقع ومتاجر إلكترونية متكاملة من الصفر باستخدام أحدث التقنيات، شاملة الواجهة الأمامية، الخادم، قاعدة البيانات، ونظام الحماية والصلاحيات.',
        full_desc_en: 'Full-stack custom websites and e-commerce platforms built with clean APIs, relational databases, and role-based admin consoles.',
        features_ar: JSON.stringify(['واجهة أمامية حديثة ولوحة تحكم كاملة', 'قاعدة بيانات حقيقية وحماية للمدخلات', 'دعم اللغتين العربية والإنجليزية', 'قابلية التوسع وإضافة المزايا']),
        features_en: JSON.stringify(['Modern frontend & full admin console', 'Real relational database & security', 'Bilingual RTL/LTR architecture', 'Scalable modular codebase']),
        starting_price: 50,
        price_label_ar: 'يبدأ من $50',
        price_label_en: 'Starts at $50',
        show_in_pricelist: 1,
        sort_order: 8,
        image_url: '/src/assets/images/service_web_engineering_1794765377359.jpg',
      },
      {
        slug: 'digital-systems',
        category_key: 'programming-solutions',
        title_ar: 'الحلول والأنظمة الرقمية',
        title_en: 'Custom Digital Systems & Tools',
        short_desc_ar: 'تطوير أنظمة إدارة المشاريع والأدوات الداخلية والأتمتة المخصصة.',
        short_desc_en: 'Bespoke operational systems, project management tools, and workflow automation.',
        full_desc_ar: 'نبني أنظمة رقمية مخصصة لإدارة العمليات، تتبع الطلبات، تنظيم المشاريع، وأدوات الأتمتة المصممة خصيصاً لاحتياجات مشروعك أو فريقك.',
        full_desc_en: 'We engineer tailored operational software, internal portals, project management tools, and automation pipelines built for your exact workflow.',
        features_ar: JSON.stringify(['تحليل المتطلبات وتصميم البنية البرمجية', 'لوحات تحكم وتقارير وإدارة صلاحيات', 'تطوير أنظمة متابعة وإدارة مشاريع', 'توثيق كامل ودعم فني مستمر']),
        features_en: JSON.stringify(['Architecture planning & technical specs', 'Role-based dashboards & reporting', 'Order, client & workflow management tools', 'Full documentation & handover']),
        starting_price: null,
        price_label_ar: 'حسب المشروع',
        price_label_en: 'Custom Quote',
        show_in_pricelist: 1,
        sort_order: 9,
        image_url: '/src/assets/images/service_digital_systems_1794765376079.jpg',
      },
      {
        slug: 'content-management',
        category_key: 'content-social',
        title_ar: 'صناعة وإدارة المحتوى الرقمي',
        title_en: 'Content Creation & Digital Presence',
        short_desc_ar: 'تجهيز الهوية الرقمية وصناعة وإدارة المحتوى الاحترافي لعلامتك.',
        short_desc_en: 'Strategic content production, publishing calendars, and digital identity setup.',
        full_desc_ar: 'نساعدك على بناء حضور رقمي متواصل عبر كتابة المحتوى التسويقي، جدولة المنشورات، وتنسيق الواجهة الرقمية لحساباتك.',
        full_desc_en: 'We strengthen your digital presence with structured content creation, editorial calendars, and unified channel branding.',
        features_ar: JSON.stringify(['تجهيز الهوية الرقمية للحسابات', 'كتابة نصوص إعلانية واضحة ومقنعة', 'تخطيط وجدولة المحتوى', 'توحيد النبرة والأسلوب البصري']),
        features_en: JSON.stringify(['Complete digital channel setup', 'Clear, persuasive copywriting', 'Structured content planning', 'Consistent brand tone & visuals']),
        starting_price: null,
        price_label_ar: 'حسب المشروع',
        price_label_en: 'Custom Quote',
        show_in_pricelist: 0,
        sort_order: 10,
        image_url: '/src/assets/images/service_brand_identity_1794765376372.jpg',
      },
    ];

    for (const s of initialServices) {
      runExec(
        `INSERT INTO services (
          slug, category_key, title_ar, title_en, short_desc_ar, short_desc_en,
          full_desc_ar, full_desc_en, features_ar, features_en,
          starting_price, price_label_ar, price_label_en, show_in_pricelist, is_active, sort_order, image_url
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`,
        [
          s.slug,
          s.category_key,
          s.title_ar,
          s.title_en,
          s.short_desc_ar,
          s.short_desc_en,
          s.full_desc_ar,
          s.full_desc_en,
          s.features_ar,
          s.features_en,
          s.starting_price,
          s.price_label_ar,
          s.price_label_en,
          s.show_in_pricelist,
          s.sort_order,
          s.image_url,
        ]
      );
    }
  }

  const pkgCount = queryOne<{ c: number }>('SELECT COUNT(*) AS c FROM packages');
  if (!pkgCount || pkgCount.c === 0) {
    const initialPackages = [
      {
        slug: 'starter-package',
        name_ar: 'باقة البداية',
        name_en: 'Starter Package',
        subtitle_ar: 'للمشاريع الناشئة والأفراد الباحثين عن انطلاقة رقمية أنيقة',
        subtitle_en: 'For emerging creators and startups launching a clean digital footprint',
        price_display_ar: 'يحدد السعر بعد مراجعة الطلب',
        price_display_en: 'Price determined after order review',
        features_ar: JSON.stringify([
          'تصميم شعار احترافي أو صفحة هبوط تعريفية',
          'لوحة ألوان وخطوط متناسقة',
          'تصميم متجاوب مع الهواتف',
          'دعم وتعديلات أولية مرنة',
        ]),
        features_en: JSON.stringify([
          'Custom logo or responsive landing page',
          'Cohesive color and typography system',
          'Mobile-optimized layout',
          'Flexible initial revision cycle',
        ]),
        is_featured: 0,
        sort_order: 1,
      },
      {
        slug: 'growth-package',
        name_ar: 'باقة التطوير',
        name_en: 'Development Package',
        subtitle_ar: 'للشركات والمشاريع الطموحة لتأسيس حضور وموقع متكامل',
        subtitle_en: 'For growing brands needing a complete website and visual identity',
        price_display_ar: 'يحدد السعر بعد مراجعة الطلب',
        price_display_en: 'Price determined after order review',
        features_ar: JSON.stringify([
          'هوية بصرية متكاملة مع ملفات المصدر',
          'موقع تعريفي أو تجاري متعدد الصفحات',
          'دعم اللغتين العربية والإنجليزية',
          'ربط نماذج الطلبات والتواصل المباشر',
        ]),
        features_en: JSON.stringify([
          'Complete visual identity with source files',
          'Multi-page corporate or product website',
          'Full Arabic RTL & English LTR support',
          'Lead capture and Discord integration',
        ]),
        is_featured: 1,
        sort_order: 2,
      },
      {
        slug: 'business-package',
        name_ar: 'باقة الأعمال',
        name_en: 'Business Package',
        subtitle_ar: 'للمتاجر والمؤسسات التي تحتاج أنظمة متقدمة ولوحات تحكم',
        subtitle_en: 'For organizations requiring full-stack systems, databases, and portals',
        price_display_ar: 'يحدد السعر بعد مراجعة الطلب',
        price_display_en: 'Price determined after order review',
        features_ar: JSON.stringify([
          'تطوير منصة أو متجر إلكتروني مخصص',
          'قاعدة بيانات حقيقية ولوحة إدارة محمية',
          'نظام متابعة طلبات وصلاحيات متقدمة',
          'تجهيز سيرفر Discord وحزمة محتوى إعلامي',
        ]),
        features_en: JSON.stringify([
          'Custom web platform or e-commerce architecture',
          'Real database & role-protected admin panel',
          'Order tracking & client management system',
          'Discord community setup & social launch kit',
        ]),
        is_featured: 0,
        sort_order: 3,
      },
      {
        slug: 'custom-package',
        name_ar: 'باقة مخصصة',
        name_en: 'Custom Package',
        subtitle_ar: 'مصممة حسب متطلبات مشروعك التقنية والإبداعية بالكامل',
        subtitle_en: 'Tailored around your exact technical, design, and operational scope',
        price_display_ar: 'يحدد السعر بعد مراجعة الطلب',
        price_display_en: 'Price determined after order review',
        features_ar: JSON.stringify([
          'تحديد نطاق العمل والميزانية حسب المشروع',
          'دمج التصميم والبرمجة والأنظمة في مسار واحد',
          'أولوية في التنفيذ ومتابعة مرحلية مستمرة',
          'تسليم كامل مع توثيق وشرح التشغيل',
        ]),
        features_en: JSON.stringify([
          'Scope and budget tailored to your goals',
          'Unified branding, engineering & systems delivery',
          'Priority milestones and direct collaboration',
          'Full source handover & deployment guide',
        ]),
        is_featured: 0,
        sort_order: 4,
      },
    ];

    for (const p of initialPackages) {
      runExec(
        `INSERT INTO packages (
          slug, name_ar, name_en, subtitle_ar, subtitle_en,
          price_display_ar, price_display_en, features_ar, features_en,
          is_featured, is_active, sort_order
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`,
        [
          p.slug,
          p.name_ar,
          p.name_en,
          p.subtitle_ar,
          p.subtitle_en,
          p.price_display_ar,
          p.price_display_en,
          p.features_ar,
          p.features_en,
          p.is_featured,
          p.sort_order,
        ]
      );
    }
  }

  const settingsCount = queryOne<{ c: number }>('SELECT COUNT(*) AS c FROM site_settings');
  if (!settingsCount || settingsCount.c === 0) {
    const defaults: Array<[string, string, string]> = [
      ['agency_name', 'VORTEX DIGITAL', 'VORTEX DIGITAL'],
      ['hero_tagline', 'نحوّل أفكارك إلى واقع رقمي', 'Transforming Your Ideas Into Digital Reality'],
      [
        'hero_description',
        'وكالة رقمية متخصصة في صياغة الهويات البصرية الفاخرة، تصميم وتطوير المواقع الحديثة، وبناء الأنظمة الرقمية المبتكرة بأعلى معايير الدقة والأمان.',
        'A modern digital agency engineering luxury brand identities, responsive websites, and bespoke software systems with precision and security.',
      ],
      [
        'about_title',
        'شريكك التقني والإبداعي لبناء حضور رقمي متكامل',
        'Your Creative & Engineering Partner for Modern Digital Presence',
      ],
      [
        'about_description',
        'في VORTEX DIGITAL نجمع بين الهندسة البرمجية المتقنة والتصميم البصري الفاخر لنقدّم حلولاً رقمية عملية قابلة للتوسع، بدءاً من الشعار والهوية وحتى الأنظمة الكاملة.',
        'At VORTEX DIGITAL we unite disciplined software engineering with refined visual design to deliver scalable digital products—from brand marks to full operational platforms.',
      ],
      ['discord_url', 'https://discord.gg/AMuVG7fM4', 'https://discord.gg/AMuVG7fM4'],
      ['contact_email', 'contact@vortexdigital.agency', 'contact@vortexdigital.agency'],
      [
        'pricelist_note',
        'الأسعار المعروضة هي أسعار البداية بالدولار الأمريكي؛ ويتم تحديد التكلفة النهائية بدقة بعد مراجعة تفاصيل ومتطلبات المشروع.',
        'Listed rates represent starting prices in USD. Final pricing is confirmed after reviewing your project scope and deliverables.',
      ],
    ];

    for (const [k, ar, en] of defaults) {
      runExec(
        'INSERT INTO site_settings (key, value_ar, value_en) VALUES (?, ?, ?)',
        [k, ar, en]
      );
    }
  }
}
